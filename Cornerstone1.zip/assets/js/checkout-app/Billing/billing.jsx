import React, { Fragment } from 'react';
import Address from '../components/Address/address';
import RadioContainer from '../components/RadioContainer/radio-container';
import RadioInput from '../components/RadioInput/radio-input';
import Section from '../components/Section/section';
import Button from '../components/Button/button';

export default class Billing extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            address: {},
            sameAsShippingAddress: true,
            billing_ship_country_err : '',
            billing_ship_firstname_err : '',
            billing_ship_lastname_err : '',
            billing_ship_addressline1_err : '',
            billing_ship_city_err : '',
            billing_ship_state_err : '',
            billing_ship_postalcode_err : '',
            billing_ship_phone_err : '',
            billing_ship_landmark_err : ''
        };
        this.handleBillingValidation = this.handleBillingValidation.bind(this);
    }

    componentDidMount() {
        this.setState({ address: this.props.address || {} });
        this.setState({ sameAsShippingAddress: this.props.sameAsShippingAddress });

        if(this.props.multishipping  || !this.props.physical_products_length){
			this.setState({ sameAsShippingAddress: false });
		}
    }

    componentDidUpdate() {
        this.props.onChange(this.state.address);
        this.props.onSelect(this.state.sameAsShippingAddress);
    }

    render() {
        return (
            <Section
                header={ 'Billing' }
                count={this.props.physical_products_length?'3':'2'}
                data_show={this.props.data_show} 
                data_billing ={'true'}
                edit_button_show = {this.props.edit_button_billing}
                edit_checkout_section = {this.props.edit_billing_section}
                populate_billing_address = { this.state.address }
                is_address_same_as_shipping = { this.state.sameAsShippingAddress }
                shipping_adderess = { this.props.shipping_address }
                billing_countries = { this.props.countries }
                header_container = { 'billing'}
                body={
                    <div className="checkout-form">
                        <div className="form-legend-container">
                            <legend className="form-legend optimizedCheckout-headingSecondary" data-test="billing-address-heading">Billing Address</legend>
                        </div>
                        <div>
                            <div>
                                <form onSubmit={this.handleBillingValidation}  autoComplete="on" noValidate="">
                                    <fieldset id="checkoutBillingAddress" className="form-fieldset">
                                        <div className="form-body">
                                            <div className="loadingOverlay-container">
                                                {this.props.physical_products_length != 0 && !this.props.multishipping &&
                                                    <RadioContainer
                                                        body={
                                                            <Fragment>
                                                                <RadioInput
                                                                    name={ 'sameAsShippingAddress' }
                                                                    label={ 'Same as shipping address' }
                                                                    value={ 'true' }
                                                                    checked={ this.state.sameAsShippingAddress }
                                                                    onChange={ ({ target }) => this._onSelect(target.value) } />

                                                                <RadioInput
                                                                    name={ 'sameAsShippingAddress' }
                                                                    label={ 'Use a different billing address' }
                                                                    value={ 'false' }
                                                                    checked={ !this.state.sameAsShippingAddress }
                                                                    onChange={ ({ target }) => this._onSelect(target.value) } />
                                                            </Fragment>
                                                        }
                                                    />
                                                }
                                                { (
                                                    this.state.sameAsShippingAddress === false ||
                                                    this.props.multishipping
                                                ) &&
                                                    <Address
                                                        name={ 'billing' }
                                                        address={ this.state.address }
                                                        countries={ this.props.countries }
                                                        onChange={ (fieldName, address) => this._onChange(fieldName, address) }
                                                        country_err = { this.state.billing_ship_country_err }
                                                        firstname_err = { this.state.billing_ship_firstname_err }
                                                        lastname_err = { this.state.billing_ship_lastname_err }
                                                        addressline1_err = { this.state.billing_ship_addressline1_err }
                                                        city_err  = { this.state.billing_ship_city_err }
                                                        state_err  = { this.state.billing_ship_state_err }
                                                        postalcode_err = { this.state.billing_ship_postalcode_err }
                                                        phone_err  = { this.state.billing_ship_phone_err }
                                                    />
                                                }
                                                {/* <Button 
                                                    label='CONTINUE'
                                                    type = 'submit'
                                                /> */}
                                                <div className="form-actions">
                                                    <button id="checkout-billing-continue" className="button button--primary optimizedCheckout-buttonPrimary" type="submit">Continue</button>
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>
                } />
        );
    }

    //Handles Validation for Billing Address
    handleBillingValidation(e) {
        event.preventDefault();
        //Check if Same asShipping Address is Selected
        let is_address_same_as_shipping = this.state.sameAsShippingAddress;
        let is_validated = false;

        if(is_address_same_as_shipping == true &&this.props.multishipping == false){
            is_validated = true;
        }
        
        if(is_address_same_as_shipping == false || this.props.multishipping == true){
            const billing_ship_country = document.getElementById('billingCountry').value.trim() ? '' : 'Please select a country';
            const billing_ship_first_name = document.getElementById('billingFirstName').value.trim() ? '' : 'Please enter First Name';
            const billing_ship_last_name = document.getElementById('billingLastName').value.trim() ? '' : 'Please enter Last Name';
            const billing_ship_address_line1 = document.getElementById('billingAddressLine1').value.trim() ? '': 'Please enter Address Line 1';
            const billing_ship_city = document.getElementById('billingCity').value.trim() ? '' : 'Please enter City';
            const billing_ship_state = document.getElementById('billingState').value.trim() ? '' : 'Please enter State' ;
            const billing_ship_postal_code = document.getElementById('billingPostalCode').value.trim() ? '' : 'Please enter Postal Code';
            const billing_ship_phone = document.getElementById('billingPhone').value.trim() ? '' : 'Please enter Phone';
            //const billing_ship_landmark = document.getElementById('billingLandmark').value.trim() ? '' : 'Please  enter Landmark';
            
            this.setState ( () =>  {
                return {
                    billing_ship_country_err : billing_ship_country,
                    billing_ship_firstname_err : billing_ship_first_name,
                    billing_ship_lastname_err : billing_ship_last_name,
                    billing_ship_addressline1_err : billing_ship_address_line1,
                    billing_ship_city_err : billing_ship_city,
                    billing_ship_state_err : billing_ship_state,
                    billing_ship_postalcode_err : billing_ship_postal_code,
                    billing_ship_phone_err : billing_ship_phone,
                    //billing_ship_landmark_err : billing_ship_landmark
                }
            });
            if(billing_ship_country == '' && billing_ship_first_name == '' && billing_ship_last_name == '' && billing_ship_address_line1 == '' && billing_ship_city == '' && billing_ship_state == '' && billing_ship_postal_code == '' &&billing_ship_phone == ''){
                is_validated = true;
            }
        }
        if(is_validated){
            this.props.onChange_toggle_billing();
        }
    }
    _onChange(fieldName, value) {
        const address = Object.assign(
            {},
            this.state.address,
            { [fieldName]: value }
        );
        this.setState({ address: address });
    }

    _onSelect(value) {
        const actualValue = (value === 'true');
        this.setState({ sameAsShippingAddress: actualValue });
    }
}
