import React, { Fragment } from 'react';
import { formatMoney } from 'accounting';
import { createCheckoutService } from '@bigcommerce/checkout-sdk';
import Panel from '../components/Panel/panel';
import SubmitButton from '../components/SubmitButton/submit-button';
import Billing from '../Billing/billing';
import Cart from '../Cart/cart';
import Customer from '../Customer/customer';
import LoginPanel from '../LoginPanel/login-panel';
import Payment from '../Payment/payment';
import Shipping from '../Shipping/shipping';
import Layout from './Layout/layout';
import LoadingState from './LoadingState/loading-state';
import styles from './checkout.scss';
import Modal from 'react-modal';

export default class Checkout extends React.PureComponent {
    constructor(props) {
        super(props);

        this.service = createCheckoutService();
        this.check_terms_and_condition = this.check_terms_and_condition.bind(this);
        this.closeModel = this.closeModel.bind(this);
        this.openModel = this.openModel.bind(this);

        this.state = {
            isPlacingOrder: false,
            showSignInPanel: false,
            termsandcondition : false,
            termsandcondition_error : '',
            has_error:'',
            checkout_cart:[],
            customer_section:true,
            shipping_section:false,
            billing_section:false,
            payment_section:false,
            edit_button_cutomer:false,
            edit_button_shipping:false,
            edit_button_billing:false,
            open_model:false,
            cart_item:0,
            billing_address_same_as_shipping_check : true,
            is_multi_shipping : ''
        };
        this.toggle_login = this.toggle_login.bind(this);
        this.setCartitemCount = this.setCartitemCount.bind(this);
        this.isBillingSameAsShipping = this.isBillingSameAsShipping.bind(this);
    }

    componentDidMount() {
        Promise.all([
            this.service.loadCheckout(),
            this.service.loadShippingCountries(),
            this.service.loadShippingOptions(),
            this.service.loadBillingCountries(),
            this.service.loadPaymentMethods(),
        ]).then(() => {
            this.unsubscribe = this.service.subscribe((state) => {
                this.setState(state);
            });
        });
    }

    componentDidUpdate() {
        if(this.state.termsandcondition){
            this.setState( ()=> ({termsandcondition_error : ''}));
        }
    }

    componentWillUnmount() {
        this.unsubscribe();
    }

    render() {
        const { data, errors, statuses } = this.state;
        
        if (!data) {
            return (
                <Layout body={
                    <LoadingState />
                } />
            );
        }

        /*
        if (this.state.showSignInPanel) {
            return (
                <Layout body={
                    <LoginPanel
                        errors={ errors.getSignInError() }
                        isSigningIn={ statuses.isSigningIn() }
                        onClick={ (customer) => this.service.signInCustomer(customer)
                            .then(() => this.service.loadShippingOptions())
                        }
                        onClose={ () => this.setState({ showSignInPanel: false }) } />
                } />
            );
        }*/
        
		//////console.log(this.service);
		//.log("this.service");
		//////console.log(statuses);
		//////console.log("this.statuses");
		//////console.log(this.state);
		//////console.log("this.state");
		//////console.log(data.getInstruments());
		//////console.log(data.getConfig());
        //////console.log("this.state");
        let store_checkout_settings = data.getConfig();
        //////console.log('--------------------');
        this.state.checkout_cart = data.getCheckout();
        //////console.log(this.state.checkout_cart);
        //////console.log(data.getConsignments());
        //////console.log('Services DatA');
        //////console.log(this.service);

        this.setCartitemCount();

        return (
            <Layout  body={
                <Fragment>
                    <div className= {`${ styles.body } layout-main`}>
                        <Panel body={
                            <ol className="checkout-steps">
                                {   //Check if the Guest User Setting is Enabled in Store
                                    store_checkout_settings.checkoutSettings.guestCheckoutEnabled == false || this.state.showSignInPanel ?
                                    <LoginPanel
                                        errors={ errors.getSignInError() }
                                        check_out_settings={ store_checkout_settings.checkoutSettings.guestCheckoutEnabled }
                                        isSigningIn={ statuses.isSigningIn() }
                                        onClick={ (customer) => this.service.signInCustomer(customer)
                                            .then(() => this.service.loadShippingOptions())
                                            .then(() => this.onChange_toggle_customer())
                                        }
                                        onClose={ () => this.setState({ showSignInPanel: false }) }
                                        data_show={this.state.customer_section}
                                        onChange_toggle_customer={ ()=> this.onChange_toggle_customer()}
                                    /> :
                                    <Customer
                                        customer={ data.getCustomer() }
                                        billingAddress={ data.getBillingAddress() }
                                        isSigningOut={ statuses.isSigningOut() }
                                        onClick={ () => this.service.signOutCustomer()
                                            .then(() => this.service.loadShippingOptions()) }
                                        onChange={ (customer) => this.setState({ customer }) }
                                        onSignIn={ () => this.setState({ showSignInPanel: true }) } 
                                        data_show={ data.getCustomer().isGuest==false || this.state.customer_section}
                                        onChange_toggle_customer={ ()=> this.onChange_toggle_customer()}
                                        onChangeSign_out={ ()=> this.onChangeSign_out()}
                                        edit_button_cutomer={this.state.edit_button_cutomer}
                                        edit_customer_section = { ()=> this.edit_customer_section() }
                                    />
                                }

								{this.state.checkout_cart.cart.lineItems.physicalItems.length!=0 &&
                                    <Shipping
                                        overall_checkout_data = { data }
                                        customer={ data.getCustomer() }
                                        multiple_shipping_store_setting = { store_checkout_settings.checkoutSettings.hasMultiShippingEnabled }
                                        enableOrderComments = { store_checkout_settings.checkoutSettings.enableOrderComments }
										consignments={ data.getConsignments() }
                                        cart={ data.getCart() }
                                        login_toggle= {this.toggle_login}
                                        onchange = { (order_comments)=>this.applyOrderComments(order_comments,this.service)}
                                        sameAsShipping = { (is_checked)=>this.isBillingSameAsShipping(is_checked)}
										isUpdatingConsignment={ statuses.isUpdatingConsignment }
										isCreatingConsignments={ statuses.isCreatingConsignments }
										isUpdatingShippingAddress={ statuses.isUpdatingShippingAddress }
										address={ data.getShippingAddress() }
										countries={ data.getShippingCountries() }
										options={ data.getShippingOptions() }
										selectedOptionId={ data.getSelectedShippingOption() ? data.getSelectedShippingOption().id : '' }
										isSelectingShippingOption ={ statuses.isSelectingShippingOption }
										onShippingOptionChange={ (optionId) => this.service.selectShippingOption(optionId) }
										onConsignmentUpdate={ (consignment) => (
											consignment.id ?
												this.service.updateConsignment(consignment) :
												this.service.createConsignments([consignment])
											)
										}
										onAddressChange={ (shippingAddress) => {
											this.setState({ shippingAddress })
											this.service.updateShippingAddress(shippingAddress)
                                        }} 
                                        data_show={this.state.shipping_section}
                                        onChange_toggle_shipping={ ()=> this.onChange_toggle_shipping(this.state.billing_address_same_as_shipping_check)}
                                        edit_button_shipping={this.state.edit_button_shipping}
                                        edit_shipping_section = { ()=> this.edit_shipping_section() }
                                    />
                                }

									<Billing
										multishipping={ (data.getConsignments() || []).length > 1 }
                                        address={ data.getBillingAddress() }
                                        shipping_address={ data.getShippingAddress() }
										countries={ data.getBillingCountries() }
										sameAsShippingAddress={
											(this.state.billingAddressSameAsShippingAddress === undefined) ||
											this.state.billingAddressSameAsShippingAddress
										}
                                        onChange ={ (billingAddress) => this.setState({ billingAddress }) }
                                        physical_products_length = {this.state.checkout_cart.cart.lineItems.physicalItems.length}
                                        onSelect ={ (billingAddressSameAsShippingAddress) => this.setState({ billingAddressSameAsShippingAddress })  } 
                                        data_show={this.state.billing_section}
                                        onChange_toggle_billing={ ()=> this.onChange_toggle_billing()}
                                        edit_button_billing={this.state.edit_button_billing}
                                        edit_billing_section = { ()=> this.edit_billing_section() }
                                    />
								    <form onSubmit={ (event) => this._submitOrder(event, data.getCustomer().isGuest, store_checkout_settings) }>
                                        <Payment
                                            errors={ errors.getSubmitOrderError() }
                                            methods={ data.getPaymentMethods() }
                                            check_terms_and_condition = { this.check_terms_and_condition }
                                            termsandcondition = {this.state.termsandcondition}
                                            termsandcondition_error = { this.state.termsandcondition_error }
                                            enableTermsAndConditions = { store_checkout_settings.checkoutSettings.enableTermsAndConditions }
                                            orderTermsAndConditions = { store_checkout_settings.checkoutSettings.orderTermsAndConditions }
                                            orderTermsAndConditionsLink = { store_checkout_settings.checkoutSettings.orderTermsAndConditionsLink }
                                            orderTermsAndConditionsType = { store_checkout_settings.checkoutSettings.orderTermsAndConditionsType }
                                            onClick={ (name, gateway) => this.service.initializePayment({ methodId: name, gatewayId: gateway }) }
                                            onChange={ (payment) => this.setState({ payment }) } 
                                            data_show={this.state.payment_section}
                                            physical_products_length = {this.state.checkout_cart.cart.lineItems.physicalItems.length}
                                        />

                                        {this.state.payment_section &&  
                                            <div className={ styles.actionContainer }>
                                                <SubmitButton
                                                    label={ this._isPlacingOrder() ?
                                                        'Placing your order...' :
                                                        `Pay ${ formatMoney((data.getCheckout()).grandTotal) }`
                                                    }
                                                    isLoading={ this._isPlacingOrder() } />
                                            </div>
                                        }
								    </form>
							</ol>
                        } />
                    </div>
                    <aside className={`${ styles.side } layout-cart`}> 
                        <Cart
                            checkout={ data.getCheckout() }
                            cartLink={ (data.getConfig()).links.cartLink } 
                            onchange = { (coupon_code)=>this.applycoupon(coupon_code,this.service)}
                            ondelete = { (coupon_code)=>this.removeCoupon(coupon_code,this.service)}
                            error = {this.state.has_error}
                            cart_item_count = {this.state.cart_item}
                            isCouponCodeCollapsed = { store_checkout_settings.checkoutSettings.isCouponCodeCollapsed }
                        />
                    </aside>
                    <div className="cartDrawer optimizedCheckout-orderSummary">
                        <figure className="cartDrawer-figure cartDrawer-figure--stack">
                            <div className="cartDrawer-imageWrapper">
                                { ['physicalItems', 'digitalItems', 'giftCertificates'].map((keyType) => (
                                    (data.getCheckout().cart.lineItems[keyType] || []).map((item) => (
                                        <img data-test="cart-item-image" src={ item.imageUrl } />
                                    ))
                                )) }                                    
                            </div>
                        </figure>
                        <div className="cartDrawer-body">
                            <h3 className="cartDrawer-items optimizedCheckout-headingPrimary">{this.state.cart_item} Items</h3><a onClick={this.openModel}>Show Details</a></div>
                        <div className="cartDrawer-actions">
                            <h3 className="cartDrawer-total optimizedCheckout-headingPrimary">{ formatMoney(data.getCheckout().grandTotal) }</h3></div>
                    </div>
                    {this.state.open_model && 
                        <Modal 
                            isOpen={this.state.open_model}
                            contentLabel="cart poup"
                            onRequestClose={this.closeModel}
                        >
                            <Cart
                                checkout={ data.getCheckout() }
                                model_popup = "true"
                                cart_item_count = {this.state.cart_item}
                                closeModel={()=> this.closeModel()}
                                cartLink={ (data.getConfig()).links.cartLink } 
                                onchange = { (coupon_code)=>this.applycoupon(coupon_code,this.service)}
                                ondelete = { (coupon_code)=>this.removeCoupon(coupon_code,this.service)}
                                error = {this.state.has_error}
                                isCouponCodeCollapsed = { store_checkout_settings.checkoutSettings.isCouponCodeCollapsed }
                            />
                        </Modal>
                    }
                    {/* <div className="mobile_cart_popup">
                        { ['physicalItems', 'digitalItems', 'giftCertificates'].map((keyType) => (
                            (data.getCheckout().cart.lineItems[keyType] || []).map((item) => (
                                <div className="imge_path_mobile">
                                    <img src={ item.imageUrl } />
                                </div>
                            ))
                        )) }	
                        <div className="center_mobile_view">
                            <div className="cart_quantity">
                                {this.state.cart_item} items
                            </div>
                            <button className="cart_model_opener" onClick={this.openModel}>
                                Show Details
                            </button>
                        </div>
                        <div className="right_mobile_view">
                            <div className="subtotal_container">
                                { formatMoney(data.getCheckout().grandTotal) }
                            </div>
                        </div>
                        <Modal 
                            isOpen={this.state.open_model}
                            contentLabel="cart poup"
                            onRequestClose={this.closeModel}
                        >
                            <Cart
                                checkout={ data.getCheckout() }
                                model_popup = "true"
                                cart_item_count = {this.state.cart_item}
                                closeModel={()=> this.closeModel()}
                                cartLink={ (data.getConfig()).links.cartLink } 
                                onchange = { (coupon_code)=>this.applycoupon(coupon_code,this.service)}
                                ondelete = { (coupon_code)=>this.removeCoupon(coupon_code,this.service)}
                                error = {this.state.has_error}
                                isCouponCodeCollapsed = { store_checkout_settings.checkoutSettings.isCouponCodeCollapsed }
                            />
                        </Modal>
                    </div> */}
                </Fragment>
            } />
        );
    }

    //Handles the is_checked for Shipping Address same as Billing Address Checkbox  from Shipping Section
    isBillingSameAsShipping(is_checked){
        ////console.log(is_checked);
        this.setState( () => ({billing_address_same_as_shipping_check : is_checked}));
    }

    //Get Cart item Count
    setCartitemCount(){
        this.setState({cart_item: (this.state.checkout_cart.cart.lineItems.physicalItems.length + this.state.checkout_cart.cart.lineItems.giftCertificates.length + this.state.checkout_cart.cart.lineItems.digitalItems.length)});
    }
    //Cart model popup Close functionality
     closeModel(){
        //////console.log("close_model");
        this.setState ({open_model:false});
    }

    //Cart model popup Open functionality
    openModel(){
       // ////console.log("openModel");
        this.setState ({open_model:true});
    }

    //Function to apply Coupon CodeOrder Comments
    async applyOrderComments (order_comments,service){
        try{
            let ordercomments = await service.updateCheckout({ customerMessage: order_comments });		 
        }catch(e){
            //Do Nothing
        }
	}

    //Function to apply Coupon Code
    async applycoupon (coupon_code,service){
		this.setState({has_error:''});
		if(coupon_code){
			try{
                let applycoupon = await service.applyCoupon(coupon_code);
                //let ordercomments = await service.updateCheckout({ customerMessage: "abc" });	
                //////console.log("**************Order Comments**************");
                //////console.log(ordercomments);		 
			}catch(e){
				try{
					let applycoupon = await service.applyGiftCertificate(coupon_code);
				}catch(e){
					this.setState({has_error:'Coupon code / Gift Certificate `'+coupon_code+'` is invalid'});
				}
			}
		}else{
            this.setState( ()=>  ({has_error:'Please enter a gift certificate or coupon code'}));
        }
	}

    //Function to Remove Coupon Code
	removeCoupon (coupon_code,service){
		this.setState({has_error:''});
		if(coupon_code){
			try{
				 let removecoupon =  service.removeCoupon(coupon_code);
				 let removecoupon_1 = service.removeGiftCertificate(coupon_code);
			}catch(e){
				//////////////console.log(e);
			}
			                                           
		}
    }

    //Toggle the Signin Section When Guset User Clicks Multi Shipping
    toggle_login(){
        this.setState( ()=> ({showSignInPanel:true}));
        window.scrollTo(0, 0);
        this.setState ({customer_section:true,shipping_section:false,billing_section:false,payment_section:false,edit_button_cutomer:false,edit_button_shipping:false,edit_button_billing:false});
	}
    
    //Toggle components
    //edit button customer component
    edit_customer_section(){
        //.log("edit_customer_section");
        this.setState ({edit_button_cutomer:false,edit_button_shipping:false,edit_button_billing:false,customer_section:true,shipping_section:false,billing_section:false,payment_section:false});
    }

    //edit button shipping component
    edit_shipping_section(){
        //////console.log("edit_shipping_section");
        this.setState ({edit_button_shipping:false,edit_button_billing:false,customer_section:false,shipping_section:true,billing_section:false,payment_section:false});
    }

    //edit button billing component
    edit_billing_section(){
        //////console.log("edit_billing_section");
        this.setState ({edit_button_shipping:true,edit_button_billing:false,customer_section:false,shipping_section:false,billing_section:true,payment_section:false});
    }

    //When click sign out button, hidden all edit button and components otherthan customer component
    onChangeSign_out(){
        //////console.log("onChangeSign_out");
        this.setState ({customer_section:true,shipping_section:false,billing_section:false,payment_section:false,edit_button_cutomer:false,edit_button_shipping:false,edit_button_billing:false});
    }
    
    //customer section continue to open shipping section (its also use in after login user directly open vshipping section)
    onChange_toggle_customer(){
        //.log("onChange_toggle_customer");
        this.setState ({edit_button_cutomer:true,edit_button_shipping:false,edit_button_billing:false,customer_section:false,shipping_section:true,billing_section:false,payment_section:false});
    }

    //shipping section continue to open billing section
    onChange_toggle_shipping(is_checked){
        if(!is_checked){
            this.setState ({edit_button_cutomer:true,edit_button_shipping:true,edit_button_billing:false,customer_section:false,shipping_section:false,billing_section:true,payment_section:false});
        }else{
            this.setState ({edit_button_cutomer:true,edit_button_shipping:true,edit_button_billing:true,customer_section:false,shipping_section:false,billing_section:false,payment_section:true});
        }
    }

    //billing section continue to open payment section
    onChange_toggle_billing(){
       // ////console.log("onChange_toggle_billing");
        this.setState ({edit_button_cutomer:true,edit_button_shipping:true,edit_button_billing:true,customer_section:false,shipping_section:false,billing_section:false,payment_section:true});
    }
    //Toggle components

    
    //Toggle Terms and Condition Checkbox
    check_terms_and_condition() {
        this.setState ( (prevState) => {
            return {
                termsandcondition : !prevState.termsandcondition
            }
        });
    }

    _isPlacingOrder() {
        const { statuses } = this.state;
        
        return this.state.isPlacingOrder && (
            statuses.isSigningIn() ||
            statuses.isUpdatingShippingAddress() ||
            statuses.isUpdatingBillingAddress() ||
            statuses.isSubmittingOrder()
        );
    }

    _submitOrder(event, isGuest, store_checkout_settings) {
        //Check if the Terms and Conditions Checkbox is checked or not
        const is_terms_and_conditions_checked = this.state.termsandcondition;
        if(is_terms_and_conditions_checked == false && store_checkout_settings.checkoutSettings.enableTermsAndConditions == true){
            event.preventDefault();
            this.setState ( (prevState) => ({termsandcondition_error : 'Please agree to the terms and conditions'}));
        }else{
            let billingAddressPayload = this.state.billingAddressSameAsShippingAddress ?
                this.state.shippingAddress :
                this.state.billingAddress;

                //////console.log("this.state.billingAddressSameAsShippingAddress");
                //////console.log(this.state.billingAddressSameAsShippingAddress);
                //////console.log("billingAddressPayload");
                //////console.log(billingAddressPayload);

            let { payment } = this.state;

            this.setState({ isPlacingOrder: true });
            event.preventDefault();

            Promise.all([
                isGuest ? this.service.continueAsGuest(this.state.customer) : Promise.resolve(),
                this.service.updateBillingAddress(billingAddressPayload),
            ])
                .then(() => this.service.submitOrder({ payment }))
                .then(({ data }) => {
                    
                // window.location.href = data.getConfig().links.orderConfirmationLink;
            window.location.href = "checkout/order-confirmation";
                })
                .catch(() => this.setState({ isPlacingOrder: false }));
        }
    }
}
