import React from 'react';
import styles from './layout.scss';

export default class Layout extends React.PureComponent {
    render() {
        return (
            <div className="">
                <div className="layout optimizedCheckout-contentPrimary">
                    <div>
                        { this.props.body }
                    </div>
                </div>
            </div>
        );
    }
}
