import React from 'react';
import { formatMoney } from 'accounting';
import ItemLine from "./ItemLine/item-line";
import ItemLineTotal from "./ItemLine/item-line-totals";
import styles from './cart.scss';

export default class Cart extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
			Applied_coupon : false,
			Coupon_code:'',
			cart_item:this.props.cart_item_count,
            show:false,
            toggle_coupon_section : false
        };

		this.handleChange = this.handleChange.bind(this);
		this.show_model = this.show_model.bind(this);
		this.hide_model = this.hide_model.bind(this);
		this.coupon_apply_data = this.coupon_apply_data.bind(this);
        this.coupon_remove_data = this.coupon_remove_data.bind(this);
        this.coupon_toggle = this.coupon_toggle.bind(this);
    }

    componentDidCatch(error, info) {
		////console.log("error");
		////console.log(error);
	    logErrorToMyService(error, info);
	}
  							
    componentDidMount(){
        if(this.props.checkout.coupons.length > 0 ){
            ////console.log(this.state.Applied_coupon);
            this.setState({Applied_coupon:true,Coupon_code:this.props.checkout.coupons[0].code});
        }
        //const cart_items = localStorage.getItem('cart-quantity');
        //////console.log("cart-quantity",cart_items);
        //this.setState({cart_item:cart_items});
	}

    render() {
        return (
            <article className={`${ styles.container } cart optimizedCheckout-orderSummary desktop_cart`} data-test="cart">
                <div className={(this.props.model_popup ? 'modal optimizedCheckout-contentPrimary modal--afterOpen' : '' )}>
                    {!this.props.model_popup ?
                        <header className="cart-header">
                            <h3 className="cart-title optimizedCheckout-headingSecondary">Order Summary</h3>
                            <a className="cart-header-link" data-test="cart-edit-link" href={ this.props.cartLink } id="cart-edit-link" target="_top">Edit Cart</a>
                        </header>
                        // <div className={ styles.cartHeaderContainer }>
                        //     <div className={ styles.cartHeader }>
                        //         Your Order
                        //     </div>

                        //     <a href={ this.props.cartLink } className={ styles.cartAction }>
                        //         Return to cart
                        //     </a>
                        // </div>
                        :
                        <div className="modal-header cart-modal-header optimizedCheckout-orderSummary">
                            <a className="cart-modal-close" onClick={this.props.closeModel}>
                                <span className="is-srOnly">Close</span>
                                <div className="icon">
                                    <svg height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg>
                                </div>
                            </a>
                            <h2 className="modal-header-title optimizedCheckout-headingSecondary cart-modal-title" data-test="modal-heading">Order Summary</h2>
                            <a className="modal-header-link cart-modal-link" data-test="cart-edit-link" href={ this.props.cartLink } id="cart-edit-link" target="_top">Edit Cart</a>
                        </div>
                        // <div className={ styles.cartHeaderContainer }>
                        //     <button onClick={this.props.closeModel}>x</button>
                        //     <div className={`${ styles.cartHeader } cart_header`}>
                        //         Order Summary
                        //     </div>

                        //     <a href={ this.props.cartLink } className={ styles.cartAction }>
                        //         Edit cart
                        //     </a>
                        // </div>
                    }

                    <div className={(this.props.model_popup ? 'modal-body cart-modal-body optimizedCheckout-orderSummary' : ' ')} data-test={(this.props.model_popup ? 'modal-body' : ' ')}>
                        <section className="cart-section optimizedCheckout-orderSummary-cartSection">
                            <h3 className="cart-section-heading optimizedCheckout-contentPrimary" data-test="cart-count-total">{this.state.cart_item} Items</h3> 
                            <ul aria-live="polite" className="productList">
                                { ['physicalItems', 'digitalItems'].map((keyType) => (
                                    (this.props.checkout.cart.lineItems[keyType] || []).map((item) => (
                                        <ItemLine
                                            key={ item.id }
                                            label={ `${ item.quantity } x ${ item.name }` }
                                            amount={ formatMoney(item.extendedSalePrice) }
                                            imageUrl={ item.imageUrl }
                                            options = {item.options}/>
                                    ))
                                )) }
                                { ['giftCertificates'].map((keyType) => (
                                    (this.props.checkout.cart.lineItems[keyType] || []).map((item) => (
                                        <ItemLine
                                            key={ item.id }
                                            label={ `${ 1 } x ${ item.name }` }
                                            amount={ formatMoney(item.amount) }
                                            imageUrl={ item.imageUrl }/>
                                    ))
                                )) }
                            </ul>
                        </section>
                        <section className="cart-section optimizedCheckout-orderSummary-cartSection">
                            <div data-test="cart-subtotal">
                                <ItemLineTotal
                                    label={ 'Subtotal' }
                                    amount={ formatMoney(this.props.checkout.subtotal) } 
                                    />
                            </div>
                            {/* <div className="coupon_price">
                                {this.props.checkout.coupons.length > 0 && 
                                    <div className="coupon_price">
                                        <p className="coupon_display">{this.props.checkout.coupons[0].displayName}	<button className="remove_coupon_button" onClick={ this.coupon_remove_data }>remove</button>
                                        </p>
                                        <p className="coupon_amount">-{formatMoney(this.props.checkout.coupons[0].discountedAmount)}</p>
                                        <p className="coupon_code">{this.props.checkout.coupons[0].code}</p>
                                    </div>
                                }
                            </div> */}
                            {this.props.checkout.coupons.length > 0 &&
                                <div data-test="cart-coupon">
                                    <div aria-live="polite" className="cart-priceItem optimizedCheckout-contentPrimary">
                                        <span className="cart-priceItem-label">
                                            <span data-test="cart-price-label"> {this.props.checkout.coupons[0].displayName}
                                            </span>
                                            <span className="cart-priceItem-link">
                                                <a data-test="cart-price-callback" onClick={ this.coupon_remove_data }> remove</a>
                                            </span>
                                        </span>
                                        <span className="cart-priceItem-value">
                                            <span data-test="cart-price-value">-{formatMoney(this.props.checkout.coupons[0].discountedAmount)}</span>
                                        </span>
                                        <span className="cart-priceItem-postFix optimizedCheckout-contentSecondary" data-test="cart-price-code">{this.props.checkout.coupons[0].code}</span>
                                    </div>
                                </div>
                            }   
                            <div data-test="cart-shipping">
                                <ItemLineTotal
                                    label={ 'Shipping' }
                                    amount={ formatMoney(this.props.checkout.shippingCostTotal) } />
                            </div>
                            <div data-test="cart-taxes">
                                <ItemLineTotal
                                    label={ 'Tax' }
                                    amount={ formatMoney(this.props.checkout.taxTotal) } />
                            </div>
                            { this.props.isCouponCodeCollapsed ? 
                                <div className="coupon_code_container">
                                    <a className='coupon_button redeemable-label' data-test="redeemable-label" onClick={ this.coupon_toggle } >Coupon/Gift Certificate</a>
                                    {this.state.toggle_coupon_section && 
                                        // <div className={"" + (this.state.toggle_coupon_section ? 'show_coupon_section' : 'hide_coupon_section')}>
                                        //     <input type="text" className="coupon_code_input" value={this.state.Coupon_code} onChange={this.handleChange}/>
                                        //     <button className="coupon_apply_button" onClick={ this.coupon_apply_data }>APPLY<div className="loader_for_coupon"></div></button>
                                        //     <div className="error_message_coupon">{this.props.error}</div>
                                        // </div>
                                        <div data-test="redeemable-collapsable" className={"" + (this.state.toggle_coupon_section ? 'show_coupon_section' : 'hide_coupon_section')}>
                                            <fieldset className="form-fieldset redeemable-entry">
                                                <div className="form-field">
                                                    <label htmlFor="redeemableCode" className="form-label is-srOnly optimizedCheckout-form-label">Gift Certificate or Coupon Code</label>
                                                    {this.props.error && 
                                                        <div className="alertBox alertBox--error">
                                                            <div className="alertBox-column alertBox-icon">
                                                                <div className="icon">
                                                                    <svg height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                                                                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"></path>
                                                                    </svg>
                                                                </div>
                                                            </div>
                                                            <div className="alertBox-column alertBox-message">{this.props.error}</div>
                                                        </div>
                                                    }
                                                    <div className="form-prefixPostfix">
                                                        <input name="redeemableCode" className="form-input optimizedCheckout-form-input" type="text" data-test="redeemableEntry-input" value={this.state.Coupon_code} onChange={this.handleChange} />
                                                        <button id="applyRedeemableButton" className="button form-prefixPostfix-button--postfix button--tertiary optimizedCheckout-buttonSecondary" data-test="redeemableEntry-submit" type="button" onClick={ this.coupon_apply_data }>Apply</button>
                                                    </div>
                                                </div>
                                            </fieldset>
                                        </div>
                                    }
                                </div>
                                :
                                <div className="coupon_code_container">
                                    <button className='coupon_button' >Coupon/Gift Certificate</button>
                                    <div className="show">
                                        <input type="text" className="coupon_code_input" value={this.state.Coupon_code} onChange={this.handleChange}/>
                                        <button className="coupon_apply_button" onClick={ this.coupon_apply_data }>APPLY<div className="loader_for_coupon"></div></button>
                                        <div className="error_message_coupon">{this.props.error}</div>
                                    </div>
                                </div>
                            }
                        </section>
                        <section className="cart-section optimizedCheckout-orderSummary-cartSection">
                            <div data-test="cart-total">
                                <div aria-live="polite" className="cart-priceItem optimizedCheckout-contentPrimary cart-priceItem--total">
                                    <span className="cart-priceItem-label">
                                        <span data-test="cart-price-label">Total </span>
                                    </span>
                                    <span className="cart-priceItem-value">
                                        <span data-test="cart-price-value">
                                            { formatMoney(this.props.checkout.grandTotal) }
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </article>
        );
    }

    coupon_toggle(){
        //Toggle Show/Hide Coupon Section
        this.setState ( (prevState) => ({toggle_coupon_section : !prevState.toggle_coupon_section}));
	}

	coupon_apply_data(){
        //Apply Coupon Code
		this.props.onchange(this.state.Coupon_code);
	}
	coupon_remove_data(){
        //Remove Coupon Code
		this.props.ondelete(this.props.checkout.coupons[0].code);
	}
	componentDidMount(){
		if(this.props.checkout.coupons.length > 0 && this.props.checkout.coupons[0].code){
			this.setState({Applied_coupon:true,Coupon_code : this.props.checkout.coupons[0].code});
		}
	}
	handleChange (e) {
	  //Update Coupon Code State Data
	  this.setState({Coupon_code: e.target.value});
	}
	show_model(){
		this.setState({show: true});
	}
	hide_model(){
		this.setState({show: false});
	}
}
