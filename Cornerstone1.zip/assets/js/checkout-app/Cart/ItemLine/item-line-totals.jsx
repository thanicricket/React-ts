import React from 'react';
import styles from './item-line.scss';

export default class ItemLineTotal extends React.PureComponent {
    render() {
        return (
            //  <div className={ styles.container }>
            //      <div className={ styles.labelContainer }>
            //          { this.props.imageUrl &&
            //              <img
            //                  src={ this.props.imageUrl }
            //                  className={ styles.image }/>
            //          }

            //          <div className={ styles.label }>
            //              <div> { this.props.label } </div>
            //          </div>
            //      </div>

            //      <div className={ styles.amount }>
            //          { this.props.amount }
            //      </div>
            //  </div>
             <div aria-live="polite" className="cart-priceItem optimizedCheckout-contentPrimary">
                <span className="cart-priceItem-label">
                    <span data-test="cart-price-label">{ this.props.label } </span>
                </span>
                <span className="cart-priceItem-value">
                    <span data-test="cart-price-value">{ this.props.amount }</span>
                </span>
            </div>
        );
    }
}
