import React from 'react';
import styles from './item-line.scss';

export default class ItemLine extends React.PureComponent {
    render() {
       // console.log(this.props.options);
        return (
            <li className="productList-item is-visible">
                <div className="product" data-test="cart-item">
                    { this.props.imageUrl &&
                        <figure className="product-column product-figure">
                            <img data-test="cart-item-image" src={ this.props.imageUrl } />
                        </figure>
                    }
                    <div className="product-column product-body">
                        <h5 className="product-title optimizedCheckout-contentPrimary" data-test="cart-item-product-title">{ this.props.label }</h5>
                        { this.props.options && this.props.options.length > 0 &&
                            <ul className="product-options optimizedCheckout-contentSecondary" data-test="cart-item-product-options">
                                { this.props.options.map((option) => (
                                    <li key={`${ option.name }  ${ option.value }`} className="product-option" data-test="cart-item-product-option">{ option.name }  { option.value }</li>
                                ))
                                }
                            </ul>
                        } 
                    </div>
                    <div className="product-column product-actions">
                        <div className="product-price optimizedCheckout-contentPrimary" data-test="cart-item-product-price">{ this.props.amount }</div>
                    </div>
                </div>
            </li>
        );
    }
}
