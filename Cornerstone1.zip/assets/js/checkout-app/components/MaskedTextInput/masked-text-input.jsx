import React from 'react';
import InputContainer from '../InputContainer/input-container'
import InputContainerPayment from '../InputContainer/input-container-payment'
import MaskedInput from 'react-text-mask';
import styles from './masked-text-input.scss';

export default class MaskedTextInput extends React.PureComponent {
    render() {
        return (
            <InputContainerPayment
                id={ this.props.id }
                label={ this.props.label }
                helpText={ this.props.id.includes('paymentExpiry') ? 'MM/YY' : '' }
                width={ this.props.width }
                header_container = {this.props.header_container}
                body={
                    <MaskedInput
                        id={ this.props.id }
                        value={ this.props.value }
                        mask={ this.props.mask }
                        onChange={ this.props.onChange }
                        required={ !this.props.optional }
                        placeholderChar={ '\u2000' }
                        className="form-input optimizedCheckout-form-input has-icon" 
                    />
                    // <input 
                    //     name="ccNumber" 
                    //     autoComplete="cc-number" 
                    //     id="ccNumber" 
                    //     class="form-input optimizedCheckout-form-input has-icon" 
                    //     type="tel" 
                    //     value="" 
                    // />
                } />
        );
    }
}
