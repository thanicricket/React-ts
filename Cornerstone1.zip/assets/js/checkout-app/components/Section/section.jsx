import React from 'react';
import styles from './section.scss';
import Button from '../Button/button';

export default class Section extends React.PureComponent {

    /*componentWillMount() {
        //console.log('*****************Address Section******************');
        //console.log(this.props.populate_address_section);
        //console.log(this.props.cart_item_details);
        //console.log('Section Component Did Mount Section');
    }*/

    render() {
        ////console.log(this.props.populate_billing_address);
        ////console.log(this.props.is_address_same_as_shipping);
        ////console.log(this.props.shipping_adderess);
        ////console.log(this.props.billing_countries);
        ///const shippingAddress = find(this.props.billing_countries, { code: 'AF' });
        ////console.log(shippingAddress);
        ////console.log(this.props.populate_address_section);
        return (
            
            <div className={`${ styles.section } checkout-step optimizedCheckout-checkoutStep Section_Container checkout-step--${ this.props.header_container }`}>
                {/* <div className={`${ styles.header } Section_header stepHeader-figure stepHeader-column checkout-view-header`}>
                    <div className="icon optimizedCheckout-step">{this.props.count}</div>
                    <h2 className="stepHeader-title optimizedCheckout-headingPrimary">{ this.props.header }</h2>
                </div> */}
                <div className="checkout-view-header">
                    <a className="stepHeader is-readonly">
                        <div className="stepHeader-figure stepHeader-column">
                            <div className="icon stepHeader-counter optimizedCheckout-step">
                                <svg height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"></path>
                                </svg>
                            </div>
                            <h2 className="stepHeader-title optimizedCheckout-headingPrimary">{ this.props.header }</h2>
                        </div>
                        <div className="stepHeader-body stepHeader-column optimizedCheckout-contentPrimary" data-test="step-info">
                            { !this.props.edit_data == true && this.props.customer_email && 
                                <div className="customerView" data-test="checkout-customer-info">
                                    <div className="customerView-body optimizedCheckout-contentPrimary" data-test="customer-info">{this.props.customer_email}</div>
                                    <div className="customerView-actions">
                                        <button className="button button--tertiary button--tiny optimizedCheckout-buttonSecondary" data-test="sign-out-link" type="button" onClick={this.props.onChange}>{this.props.sign_out_data}</button>
                                    </div>
                                </div>
                            }
                            { this.props.edit_button_show && this.props.edit_data == true && this.props.customer_details!='' && 
                                <div className="customerView" data-test="checkout-customer-info"><div className="customerView-body optimizedCheckout-contentPrimary" data-test="customer-info">{this.props.customer_details}</div><div className="customerView-actions"></div></div>
                            }
                            { this.props.edit_button_show && this.props.data_shipping && 
                                <div className="staticConsignmentContainer">
                                    { this.props.populate_address_section.map( (address) =>(    
                                        <div className="staticConsignment" key={address.id}>
                                            <div className="vcard checkout-address--static">
                                                <p className="fn address-entry"><span className="first-name">{address.shippingAddress.firstName} </span><span className="family-name">{address.shippingAddress.lastName}</span></p>
                                                <p className="address-entry"><span className="company-name">{address.shippingAddress.company} </span><span className="tel">{address.shippingAddress.phone}</span></p>
                                                <div className="adr">
                                                    <p className="street-address address-entry"><span className="address-line-1">{address.shippingAddress.address1} </span><span className="address-line-2"> / {address.shippingAddress.address2}</span></p>
                                                    <p className="address-entry"><span className="locality">{address.shippingAddress.city}, </span><span className="region">{address.shippingAddress.stateOrProvince}, </span><span className="postal-code">{address.shippingAddress.postalCode} / </span><span className="country-name">{address.shippingAddress.countryCode} </span></p>
                                                </div>
                                            </div>
                                            {
                                                this.props.cart_item_details &&
                                                this.props.cart_item_details.map( (itemDetails)=> (
                                                    <div key={itemDetails.id}>
                                                        {address.lineItemIds.indexOf(itemDetails.id) > -1 && <span>{itemDetails.quantity} x {itemDetails.name}</span>}
                                                    </div>
                                                ))
                                            }
                                            <div>
                                                <div className="shippingOption shippingOption--alt">
                                                    <div className="shippingOption shippingOption--alt"><span className="shippingOption-desc">{address.selectedShippingOption.description}</span><span className="shippingOption-price">${address.selectedShippingOption.cost}</span></div>
                                                </div>
                                            </div>
                                        </div>
                                    )) 
                                    }
                                </div>
                            }
                            { this.props.edit_button_show && this.props.data_billing && 
                                <div>
                                    { this.props.is_address_same_as_shipping ?
                                        <div className="vcard checkout-address--static">
                                            <p className="fn address-entry"><span className="first-name">{this.props.shipping_adderess.firstName} </span><span className="family-name">{this.props.shipping_adderess.lastName}</span></p>
                                            <p className="address-entry"><span className="company-name">{this.props.shipping_adderess.company != '' && this.props.shipping_adderess.company} </span><span className="tel">{this.props.shipping_adderess.phone}</span></p>
                                            <div className="adr">
                                                <p className="street-address address-entry"><span className="address-line-1">{this.props.shipping_adderess.address1} </span><span className="address-line-2"> / {this.props.shipping_adderess.address2}</span></p>
                                                <p className="address-entry"><span className="locality">{this.props.shipping_adderess.city}, </span><span className="region">{this.props.shipping_adderess.stateOrProvince}, </span><span className="postal-code">{this.props.shipping_adderess.postalCode} / </span><span className="country-name">{this.props.shipping_adderess.countryCode} </span></p>
                                            </div>
                                        </div>
                                    :
                                        <div className="vcard checkout-address--static">
                                            <p className="fn address-entry"><span className="first-name">{this.props.populate_billing_address.firstName} </span><span className="family-name">{this.props.populate_billing_address.lastName}</span></p>
                                            <p className="address-entry"><span className="company-name">{this.props.populate_billing_address.company} </span><span className="tel">{this.props.populate_billing_address.phone}</span></p>
                                            <div className="adr">
                                                <p className="street-address address-entry"><span className="address-line-1">{this.props.populate_billing_address.address1} </span><span className="address-line-2"> / {this.props.populate_billing_address.address2}</span></p>
                                                <p className="address-entry"><span className="locality">{this.props.populate_billing_address.city}, </span><span className="region">{this.props.populate_billing_address.stateOrProvince}, </span><span className="postal-code">{this.props.populate_billing_address.postalCode} / </span><span className="country-name">{this.props.populate_billing_address.countryCode} </span></p>
                                            </div>
                                        </div>
                                    }
                                </div>
                            }
                        </div>
                        { this.props.edit_button_show && this.props.edit_data == true && this.props.customer_details!='' && 
                            <div className="stepHeader-actions stepHeader-column">
                                <button className="button button--tertiary button--tiny optimizedCheckout-buttonSecondary" data-test="step-edit-button" type="button" onClick={this.props.edit_checkout_section}>Edit</button>
                            </div>
                        }
                        { this.props.edit_button_show && this.props.data_shipping && 
                            <div className="stepHeader-actions stepHeader-column">
                                <button className="button button--tertiary button--tiny optimizedCheckout-buttonSecondary" data-test="step-edit-button" type="button" onClick={this.props.edit_checkout_section}>Edit</button>
                            </div>
                        }
                        { this.props.edit_button_show && this.props.data_billing && 
                            <div className="stepHeader-actions stepHeader-column">
                                <button className="button button--tertiary button--tiny optimizedCheckout-buttonSecondary" data-test="step-edit-button" type="button" onClick={this.props.edit_checkout_section}>Edit</button>
                            </div>
                        }
                    </a>
                </div>

                {/* { this.props.edit_button_show && this.props.edit_data == true && this.props.customer_details!='' && 
                    <div>
                        <div className="guest_details">
                            {this.props.customer_details}
                        </div>
                        <div className="edit_button_guest">
                            <Button 
                                label='Edit'
                                onClick={this.props.edit_checkout_section}
                            />
                        </div>
                    </div>
                } */}

                {/* { this.props.edit_button_show && this.props.data_shipping && 
                    <div className="edit_button_shipping">
                    {
                        this.props.populate_address_section.map( (address) =>(
                            <div key={address.id}>
                                <div>{address.shippingAddress.firstName} {address.shippingAddress.lastName}</div>
                                <div>{address.shippingAddress.company != '' && address.shippingAddress.company}{address.shippingAddress.phone}</div>
                                <div>{address.shippingAddress.address1}, {address.shippingAddress.address2}</div>
                                <div>{address.shippingAddress.city}, {address.shippingAddress.stateOrProvince}, {address.shippingAddress.postalCode} / {address.shippingAddress.countryCode}</div>
                                {
                                    this.props.cart_item_details &&
                                    this.props.cart_item_details.map( (itemDetails)=> (
                                        <div key={itemDetails.id}>
                                            {address.lineItemIds.indexOf(itemDetails.id) > -1 && <p>{itemDetails.quantity} x {itemDetails.name}</p>}
                                        </div>
                                    ))
                                }
                                {address.selectedShippingOption.description != null &&
                                    <div>{address.selectedShippingOption.description}  ${address.selectedShippingOption.cost}</div>
                                }
                               
                            </div>
                        ))
                    }

                        <Button 
                            label='Edit'
                            onClick={this.props.edit_checkout_section}
                        />
                    </div>
                } */}

                {/* { this.props.edit_button_show && this.props.data_billing && 
                    <div className="edit_button_billing">
                        {
                            this.props.is_address_same_as_shipping 
                            ?
                                <div>
                                    <div>{this.props.shipping_adderess.firstName} {this.props.shipping_adderess.lastName}</div>
                                    <div>{this.props.shipping_adderess.company != '' && this.props.shipping_adderess.company}{this.props.shipping_adderess.phone}</div>
                                    <div>{this.props.shipping_adderess.address1}, {this.props.shipping_adderess.address2}</div>
                                    <div>{this.props.shipping_adderess.city}, {this.props.shipping_adderess.stateOrProvince}, {this.props.shipping_adderess.postalCode} / {this.props.shipping_adderess.countryCode}</div>
                                </div>
                            :
                            <div>
                                <div>{this.props.populate_billing_address.firstName} {this.props.populate_billing_address.lastName}</div>
                                <div>{this.props.populate_billing_address.company != '' && this.props.populate_billing_address.company}{this.props.populate_billing_address.phone}</div>
                                <div>{this.props.populate_billing_address.address1}, {this.props.populate_billing_address.address2}</div>
                                <div>{this.props.populate_billing_address.city}, {this.props.populate_billing_address.stateOrProvince}, {this.props.populate_billing_address.postalCode} / {this.props.populate_billing_address.countryCode}</div>
                            </div>
                        }
                        <Button 
                            label='Edit'
                            onClick={this.props.edit_checkout_section}
                        />
                    </div>
                } */}

                {this.props.data_show &&
                    <div className={`${ styles.body } Section_body checkout-view-content`}>
                        { this.props.body }
                    </div>
                }
            </div>
        );
    }
}
