import React from 'react';
import classNames from 'classnames';
import styles from './input-container.scss';

export default class InputContainerForm extends React.PureComponent {
    render() {
        return (
            <div className={( (this.props.guest_email_error || this.props.customer_password_err) ? 'form-field form-field--error' : 'form-field')}>
                <label htmlFor={ this.props.id } className={`${ styles.label } form-label optimizedCheckout-form-label`}>{ this.props.label } { this.props.helpText && <span className={ styles.helpText }>({ this.props.helpText })</span> }</label>
                { this.props.body }
                { (this.props.guest_email_error || this.props.customer_password_err) && 
                    <ul className="form-field-errors" data-test="email-field-error-message">
                        <li className="form-field-error">
                            <label className="form-inlineMessage" htmlFor={ this.props.id }>{this.props.guest_email_error && this.props.guest_email_error}{this.props.customer_password_err && this.props.customer_password_err}</label>
                        </li>
                    </ul>
                }
                { this.props.password_input && 
                    <a data-test="forgot-password-link" href="/login.php?action=reset_password" rel="noopener noreferrer" target="_blank">Forgot password?</a>
                }
            </div>
        );
    }
}
