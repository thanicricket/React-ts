import React from 'react';
import classNames from 'classnames';
import styles from './input-container.scss';

export default class InputContainerText extends React.PureComponent {
    render() {
        return (
            <div className= {`dynamic-form-field dynamic-form-field--${ this.props.header_label }`}>
                <div className= {( this.props.error_shown ? 'form-field form-field--error' : 'form-field')}>
                    <label
                        htmlFor={ this.props.id }
                        className={`${ styles.label } form-label optimizedCheckout-form-label`}>
                        { this.props.label } { this.props.helpText && <span className={ styles.helpText }>({ this.props.helpText })</span> }
                    </label>

                    { this.props.body }

                    {this.props.error_shown && 
                        <ul className="form-field-errors" 
                        data-test="shipping-address-first-name-field-error-message">
                            <li className="form-field-error">
                                <label className="form-inlineMessage" htmlFor="shippingAddress.firstName">{this.props.error_shown}</label>
                            </li>
                        </ul>
                    }
                </div>
            </div>
        );
    }
}
