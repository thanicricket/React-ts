import React from 'react';
import classNames from 'classnames';
import styles from './input-container.scss';

export default class InputContainerPayment extends React.PureComponent {
    render() {
        return (
            // <div className={ classNames(styles.container, styles[this.props.width ? this.props.width + 'Width' : 'fullWidth']) }>
            //     <label
            //         htmlFor={ this.props.id }
            //         className={`${ styles.label } form-label optimizedCheckout-form-label`}>
            //         { this.props.label } { this.props.helpText && <span className={ styles.helpText }>({ this.props.helpText })</span> }
            //     </label>

            //     { this.props.body }
            // </div>
            <div className={this.props.header_container}>
                <label 
                    htmlFor={ this.props.id }
                    className="form-label optimizedCheckout-form-label">
                        {this.props.label}
                </label>
                {/* <input 
                    name="ccNumber" 
                    autoComplete="cc-number" 
                    id="ccNumber" 
                    className="form-input optimizedCheckout-form-input has-icon" 
                    type="tel" 
                    value="" 
                /> */}
                { this.props.body }
            </div>
        );
    }
}
