import React from 'react';
import InputContainerText from '../InputContainer/input-container-text'
import styles from './text-input.scss';

export default class TextInputAddress extends React.PureComponent {
    render() {
        return (
            <InputContainerText
                id={ this.props.id }
                label={ this.props.label }
                helpText={ this.props.optional ? 'Optional' : '' }
                width={ this.props.width }
                error_shown = {this.props.error_shown}
                header_label = {this.props.header_label}
                body={
                    <input
                        type="text"
                        id={ this.props.id }
                        value={ this.props.value || '' }
                        name = { this.props.name }
                        //required={ !this.props.optional }
                        onChange={ this.props.onChange }
                        placeholder={ this.props.placeholder }
                        className="form-input optimizedCheckout-form-input has-icon"  />
                } />
        );
    }
}
