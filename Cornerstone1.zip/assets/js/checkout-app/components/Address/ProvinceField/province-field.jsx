import React, { Fragment } from 'react';
import { isEmpty } from 'lodash';
import Dropdown from '../../Dropdown/dropdown';
import TextInput from '../../TextInput/text-input';
import DropdownAddress from '../../Dropdown/dropdown-address';
import TextInputAddress from '../../TextInput/text-input-address';

export default class ProvinceInput extends React.PureComponent {
    render() {
        return (
            <Fragment>
                { this.props.country && !isEmpty(this.props.country.subdivisions) ?
                    <DropdownAddress
                        id={ `${ this.props.name }State` }
                        label={ 'State' }
                        value={ this.props.stateOrProvinceCode }
                        onChange={ this.props.onCodeChange }
                        options={ this.props.country.subdivisions }
                        width={ 'half' } 
                        header_label = { this.props.header_label }
                        error_shown = { this.props.error_shown }/>
                    :
                    <TextInputAddress
                        id={ `${ this.props.name }State` }
                        label={ 'State' }
                        value={ this.props.stateOrProvince }
                        onChange={ this.props.onChange }
                        width={ 'half' } 
                        header_label = { this.props.header_label }
                        error_shown = { this.props.error_shown }/>
                }
            </Fragment>
        );
    }
}
