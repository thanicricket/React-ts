import React, { Fragment } from 'react';
import { find } from 'lodash';
import Dropdown from '../Dropdown/dropdown';
import DropdownAddress from '../Dropdown/dropdown-address';
import TextInput from '../TextInput/text-input';
import TextInputAddress from '../TextInput/text-input-address';
import ProvinceInput from './ProvinceField/province-field';

export default class Address extends React.PureComponent {
    render() {
        return (
            <Fragment>
                <div className="checkout-address">
                    <TextInputAddress
                        id={ `${ this.props.name }FirstName` }
                        label={ 'First Name' }
                        header_label = { 'firstName' }
                        value={ this.props.address.firstName }
                        onChange={ ({ target }) => this.props.onChange('firstName', target.value) }
                        width={ 'half' } 
                        error_shown = { this.props.firstname_err }/>
                    {/* <div className='address_fields_error'>{ this.props.firstname_err }</div> */}

                    <TextInputAddress
                        id={ `${ this.props.name }LastName` }
                        label={ 'Last Name' }
                        header_label = { 'lastName' }
                        value={ this.props.address.lastName }
                        onChange={ ({ target }) => this.props.onChange('lastName', target.value) }
                        width={ 'half' } 
                        error_shown = { this.props.lastname_err }/>
                    {/* <div className='address_fields_error'>{ this.props.lastname_err }</div> */}

                    
                    <TextInputAddress
                        id={ `${ this.props.name }Company` }
                        label={ 'Company' }
                        header_label = { 'company' }
                        value={ this.props.address.company }
                        onChange={ ({ target }) => this.props.onChange('company', target.value) }
                        optional={ true }
                        width={ 'full' } />
                        
                    <TextInputAddress
                        id={ `${ this.props.name }Phone` }
                        label={ 'Phone' }
                        header_label = { 'phone' }
                        value={ this.props.address.phone }
                        onChange={ ({ target }) => this.props.onChange('phone', target.value) }
                        width={ 'twoThird' } 
                        error_shown = { this.props.phone_err }/>
                    {/* <div className='address_fields_error'>{ this.props.phone_err }</div> */}

                    <TextInputAddress
                        id={ `${ this.props.name }AddressLine1` }
                        label={ 'Address Line 1' }
                        value={ this.props.address.address1 }
                        header_label = { 'address1' }
                        onChange={ ({ target }) => this.props.onChange('address1', target.value) }
                        width={ 'full' }
                        error_shown = { this.props.addressline1_err } />
                    {/* <div className='address_fields_error'>{ this.props.addressline1_err }</div> */}

                    <TextInputAddress
                        id={ `${ this.props.name }AddressLine2` }
                        label={ 'Address Line 2' }
                        header_label = { 'address2' }
                        value={ this.props.address.address2 }
                        onChange={ ({ target }) => this.props.onChange('address2', target.value) }
                        optional={ true }
                        width={ 'full' } />

                    <TextInputAddress
                        id={ `${ this.props.name }City` }
                        label={ 'City' }
                        header_label = { 'city' }
                        value={ this.props.address.city }
                        onChange={ ({ target }) => this.props.onChange('city', target.value) }
                        width={ 'half' } 
                        error_shown = { this.props.city_err }/>
                    {/* <div className='address_fields_error'>{ this.props.city_err }</div> */}

                    
                    <DropdownAddress
                        id={ `${ this.props.name }Country` }
                        label={ 'Country' }
                        header_label = { 'countryCode' }
                        value={ this.props.address.countryCode }
                        onChange={ ({ target }) => this.props.onChange('countryCode', target.value) }
                        options={ this.props.countries }
                        width={ 'full' }
                        error_shown = { this.props.country_err } />
                    {/* <div className='address_fields_error'>{ this.props.country_err }</div> */}

                    <ProvinceInput
                        name={ this.props.name }
                        header_label = { 'province' }
                        country={ find(this.props.countries, ({ code }) => code === this.props.address.countryCode) }
                        stateOrProvince={ this.props.address.stateOrProvince }
                        stateOrProvinceCode={ this.props.address.stateOrProvinceCode }
                        onChange={ ({ target }) => this.props.onChange('stateOrProvince', target.value) }
                        onCodeChange={ ({ target }) => this.props.onChange('stateOrProvinceCode', target.value) } 
                        error_shown = { this.props.state_err } />
                    {/* <div className='address_fields_error'>{ this.props.state_err }</div> */}

                    <TextInputAddress
                        id={ `${ this.props.name }PostalCode` }
                        label={ 'Postal Code' }
                        header_label = { 'postCode' }
                        value={ this.props.address.postalCode }
                        onChange={ ({ target }) => this.props.onChange('postalCode', target.value) }
                        width={ 'oneThird' } 
                        error_shown = { this.props.postalcode_err }/>
                    {/* <div className='address_fields_error'>{ this.props.postalcode_err }</div> */}

                    {/* <TextInputAddress
                        id={ `${ this.props.name }Landmark` }
                        label={ 'Landmark' }
                        value={ this.props.address.landmark }
                    optional={ true }
                        onChange={ ({ target }) => this.props.onChange('landmark', target.value) }
                        width={ 'full' } />
                    <div className='address_fields_error'>{ this.props.landmark_err }</div> */}
                </div>
            </Fragment>
        );
    }
}
