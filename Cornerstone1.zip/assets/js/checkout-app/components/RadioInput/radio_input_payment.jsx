import React from 'react';
import styles from './radio-input.scss';

export default class RadioInputPayment extends React.PureComponent {

    componentWillMount(){
        if(this.props.is_payment_method_selected == null && !this.props.checked){
            this.props.onChange();
        }
    }
    
    render() {
        return (
            // <li className="form-checklist-item optimizedCheckout-form-checklist-item">
            //     <div className="form-checklist-header">
            //         <div className="form-field">
            //             <input 
            //                 className="form-checklist-checkbox optimizedCheckout-form-checklist-checkbox" 
            //                 type="radio"
            //                 id = { this.props.value }
            //                 name={ this.props.name }
            //                 value={ this.props.value }
            //                 checked={ this.props.checked == this.props.value }
            //                 disabled={ this.props.isLoading }
            //                 onChange={ this.props.onChange }
            //                 className={ styles.input }
            //             />
            //             <label className={ this.props.isLoading ? `${styles.container} ${styles.loadingState} form-label optimizedCheckout-form-label` : `${styles.container} form-label optimizedCheckout-form-label`}  htmlFor={this.props.value}>
            //                 <div className="shippingOptionLabel">
            //                     <div className="shippingOption shippingOption--alt">
            //                         <span className="shippingOption-desc">{this.props.description}</span>
            //                         <span className="shippingOption-price">{this.props.cost}</span>
            //                     </div>
            //                 </div>
            //             </label>
            //         </div>
            //     </div>
            // </li>
            <div className= {( this.props.checked == this.props.value  ? "form-checklist-header form-checklist-header--selected" : "form-checklist-header" )}>
                <div className="form-field">
                    <input 
                        className="form-checklist-checkbox optimizedCheckout-form-checklist-checkbox" 
                        id={ this.props.value }
                        type="radio" 
                        name={ this.props.name }
                        value={ this.props.value } 
                        checked={ this.props.checked == this.props.value }
                        disabled={ this.props.isLoading }
                        onChange={ this.props.onChange }
                    />
                    <label htmlFor={this.props.value} className="form-label optimizedCheckout-form-label">
                        <span className="paymentProviderHeader-name" data-test="payment-method-name">{this.props.label}</span>
                        <div className="paymentProviderHeader-cc"></div>
                    </label>
                </div>
            </div>
        );
    }
}
