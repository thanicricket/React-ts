import React from 'react';
import styles from './radio-input.scss';

export default class RadioInputOption extends React.PureComponent {

    componentWillMount() {
        /*if(this.props.is_shipping_option_selected == '' && !this.props.checked){
            
            setTimeout(() => {
                this.props.onChange();
            }, 2000);
        }*/
        ////console.log('Selected Shipping Id ->');
        ////console.log(this.props.is_shipping_option_selected);
        ////console.log('drop down');
        ////console.log(this.props.is_shipping_option_selected);
        ////console.log(this.props.value);
        ////console.log(this.props.value);
        ////console.log(this.props.checked);
    }
    
    render() {
        return (
            <li className={(this.props.checked ? "form-checklist-item optimizedCheckout-form-checklist-item form-checklist-item--selected optimizedCheckout-form-checklist-item--selected" : "form-checklist-item optimizedCheckout-form-checklist-item")}>
                <div className={(this.props.checked ? "form-checklist-header form-checklist-header--selected" : "form-checklist-header")}>
                    <div className="form-field">
                        <input 
                            className="form-checklist-checkbox optimizedCheckout-form-checklist-checkbox" 
                            type="radio" 
                            id = {this.props.id}
                            value={ this.props.value } 
                            checked={ this.props.checked } 
                            name={ this.props.name } 
                            disabled={ this.props.isLoading } 
                            onChange={ this.props.onChange } 
                        />
                        <label className={ this.props.isLoading ? `${styles.container} ${styles.loadingState} form-label optimizedCheckout-form-label` : `${styles.container} form-label optimizedCheckout-form-label`}  htmlFor={this.props.id}>
                            <div className="shippingOptionLabel">
                                <div className="shippingOption shippingOption--alt">
                                    <span className="shippingOption-desc">{this.props.description}</span>
                                    <span className="shippingOption-price">{this.props.cost}</span>
                                </div>
                            </div>
                        </label>
                    </div>
                </div>
            </li>
        );
    }
}
