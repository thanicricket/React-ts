import React from 'react';
import InputContainer from '../InputContainer/input-container'
import InputContainerSelect from '../InputContainer/input-container-select'
import styles from './dropdown.scss';

export default class DropdownAddress extends React.PureComponent {
    render() {
        return (
            <InputContainerSelect
                id={ this.props.id }
                inline={ this.props.inline }
                label={ this.props.label }
                width={ this.props.width }
                error_shown = {this.props.error_shown}
                header_label = {this.props.header_label}
                body={
                    <select
                        id={ this.props.id }
                        value={ this.props.value || '' }
                        onChange={ this.props.onChange }
                        className=  {`${styles.select}  ${this.props.className} form-select optimizedCheckout-form-select`}
                        >
                        <option value="" />
                        { this.props.options.map((option) => (
                            <option
                                key={ option.code }
                                value={ option.code }>
                                { option.name }
                            </option>
                        ))}
                    </select>
                } />
        );
    }
}
