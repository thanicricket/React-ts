import React from 'react';
import InputContainer from '../InputContainer/input-container'
import styles from './dropdown.scss';

export default class DropdownSelect extends React.PureComponent {

    componentWillMount(){
		/*if(this.props.is_address_id_selected == '' && this.props.options[0]){
            //console.log("true");
            setTimeout(() => {
                this.props.onChange({target:this.props.options[0]});
            }, 500);
			
			//this.props.first_onChange(15);
        }*/
        /*if((this.props.value == '' || this.props.value==undefined) && this.props.options[0]){
            this.props.onChange({target:this.props.options[0]});
        }
        //console.log('value');
        //console.log(this.props.value);*/
        ////console.log('Selected Address Id ->');
        ////console.log(this.props.is_address_id_selected);
    }
    
    render() {
        return (
            <div>
                <InputContainer
                    id={ this.props.id }
                    inline={ this.props.inline }
                    label={ this.props.label }
                    width={ this.props.width }
                    body={
                        <div className="dropdown--select">
                            <select
                                id={ this.props.id }
                                value={ this.props.value || '' }
                                onChange={ this.props.onChange }
                                className=  {`${styles.select}  ${this.props.className} dropdown-toggle--select`}
                                >
                                <option value="">
                                    {'Enter a new Address'}
                                </option>
                                { this.props.options.map((option) => (
                                    <option
                                        key={ option.code }
                                        value={ option.code }>
                                        { option.name }
                                    </option>
                                ))}
                            </select>
                        </div>
                    } />
                    { this.props.multi_shipping_address_err != '' && <span className='multishipping_option_error'>{ this.props.multi_shipping_address_err }</span> }
                </div>
        );
    }
}
