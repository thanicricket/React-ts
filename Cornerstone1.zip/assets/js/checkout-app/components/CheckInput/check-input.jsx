import React from 'react';
import styles from './check-input.scss';

export default class CheckInput extends React.PureComponent {
    render() {
        return (
            
            <div className="form-field">
                <input 
                    name={ this.props.name } 
                    className={`${ styles.input } form-checkbox optimizedCheckout-form-checkbox`} 
                    id={ this.props.name } 
                    type="checkbox" 
                    value={ this.props.value } 
                    checked={ this.props.checked } 
                    disabled={ this.props.isLoading } 
                    onChange={ this.props.onChange } 
                    data-payment = {this.props.className_data} />
                <label data-attr={this.props.className_data} htmlFor={this.props.name}className="form-label optimizedCheckout-form-label">{ this.props.label }</label>
            </div>
            // <label data-attr={this.props.className_data} className={ this.props.isLoading ? `${styles.container} ${styles.loadingState} form-label optimizedCheckout-form-label` : `${styles.container} form-label optimizedCheckout-form-label` } htmlFor={this.props.name}>
            //     <input
            //         type="checkbox"
            //         name={ this.props.name }
            //         id={ this.props.name }
            //         value={ this.props.value }
            //         checked={ this.props.checked }
            //         disabled={ this.props.isLoading }
            //         onChange={ this.props.onChange }
            //         className={`${ styles.input } form-checkbox optimizedCheckout-form-checkbox`} 
			// 		data-payment = {this.props.className_data}
			// 		/>
            //     { this.props.label }
            // </label>
        );
    }
}
