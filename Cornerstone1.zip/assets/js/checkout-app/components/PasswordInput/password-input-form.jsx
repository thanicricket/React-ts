import React from 'react';
import InputContainerForm from '../InputContainer/input-container-form';
import styles from './password-input.scss';

export default class PasswordInputForm extends React.PureComponent {
    render() {
        return (
            <InputContainerForm
                id={ this.props.id }
                label={ this.props.label }
                width={ this.props.width }
                customer_password_err={ this.props.customer_password_err }
                password_input = "true"
                body={
                    <input name = { this.props.name } autoComplete="password" id={ this.props.id } className="form-input optimizedCheckout-form-input" onChange={ this.props.onChange } type={ "password" } value={ this.props.value || '' } required />
                } />
        );
    }
}
