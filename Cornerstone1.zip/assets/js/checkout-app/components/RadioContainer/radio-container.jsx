import React from 'react';
import styles from './radio-container.scss';

export default class RadioContainer extends React.PureComponent {
    render() {
        return (
            <fieldset id="checkout-shipping-options" className="form-fieldset">
                <legend className="form-legend optimizedCheckout-headingSecondary">{this.props.label}</legend>
                <div className="form-body">
                    { this.props.body }
                </div>

            </fieldset>
        );
    }
}
