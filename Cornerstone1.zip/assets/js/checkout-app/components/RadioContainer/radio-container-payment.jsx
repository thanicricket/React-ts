import React from 'react';
import styles from './radio-container.scss';

export default class RadioContainerPayment extends React.PureComponent {
    render() {
        return (
            <fieldset className="form-fieldset">
                <legend className="form-legend optimizedCheckout-headingSecondary">Payment Method</legend>
                <div className="form-body">
                    <ul className="form-checklist optimizedCheckout-form-checklist">
                        { this.props.body }
                    </ul>
                </div>

            </fieldset>
        );
    }
}
