import React from 'react';
import InputContainerForm from '../InputContainer/input-container-form';
import styles from './email-input.scss';

export default class EmailInputGuest extends React.PureComponent {
    render() {
        return (
            <InputContainerForm
                id={ this.props.id }
                label={ this.props.label }
                width={ this.props.width }
                guest_email_error={ this.props.guest_email_error }
                body={
                    <input name = { this.props.name } autoComplete="email" id={ this.props.id } className="form-input optimizedCheckout-form-input" onChange={ this.props.onChange } type="email" value={ this.props.value || '' } required />
                    // <input
                    //     type={this.props.type ? this.props.type : "email"}
                    //     id={ this.props.id }
                    //     value={ this.props.value || '' }
                    //     name = { this.props.name }
                    //     required
                    //     onChange={ this.props.onChange }
                    //     className={ styles.input } />
                } />
        );
    }
}