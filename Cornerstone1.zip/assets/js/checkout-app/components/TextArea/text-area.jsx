import React from 'react';
import styles from './text-area.scss';

export default class TextArea extends React.PureComponent {
    render() {
        return (
            <textarea
                value={this.props.value}
                id = {this.props.id}
                rows= {this.props.rows} 
                cols= {this.props.cols}
                name = {this.props.name}
                readOnly
             />
        );
    }
}
