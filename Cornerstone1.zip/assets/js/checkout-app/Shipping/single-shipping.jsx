import React, { Fragment } from 'react';
import { debounce } from 'lodash';
import { find } from 'lodash';
import Address from '../components/Address/address';
import MultiShippingDropdown from '../components/Dropdown/multishippingdropdown';
import DropdownSelect from '../components/Dropdown/dropdown-select';
import ShippingOptions from './shipping-options';
import TextInput from '../components/TextInput/text-input';
import CheckInput from '../components/CheckInput/check-input';


export default class SingleShipping extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            addressId : (this._getAddress() || {}).id,
            display_single_shipping_address : false,
            address: {},
            order_comment_value : this.props.order_comments ? this.props.order_comments : '',
        };

        this._debouncedOnAddressChange = debounce(() => this.props.onAddressChange(this.state.address), 1000);
        this.update_comment_text=this.update_comment_text.bind(this);
    }

    componentDidMount() {
        this.props.onAddressChange(this.props.address);
        this.setState({ address: this.props.address || {} });
    }

    componentWillMount(){
        if(this.props.customer.isGuest){
            this.setState( ()=> ({display_single_shipping_address : true}));
        }
        if(!this.state.display_single_shipping_address && typeof this.state.addressId === 'undefined' && !this.props.customer.isGuest){
            //console.log(this.props.customer.addresses[0].id);
            this._selectAddress(this.props.customer.addresses[0].id);
        }
        this.props.customer.addresses.map( (address_lines) => {
            if(address_lines.firstName == this.props.address.firstName && address_lines.lastName == this.props.address.lastName && address_lines.company == this.props.address.company &&address_lines.address1 == this.props.address.address1 && address_lines.address2 == this.props.address.address2 &&address_lines.city == this.props.address.city && address_lines.stateOrProvince == this.props.address.stateOrProvince && address_lines.stateOrProvinceCode == this.props.address.stateOrProvinceCode && address_lines.country == this.props.address.country && address_lines.countryCode == this.props.address.countryCode &&address_lines.postalCode == this.props.address.postalCode && address_lines.phone == this.props.address.phone){
                this.setState( ()=> ({
                    addressId : address_lines.id,
                }));
            }
        });
    }

    render() {
        return (
            <Fragment>
                <fieldset className="form-fieldset">
                    <div className="form-body">
                        <fieldset id="checkoutShippingAddress" className="form-fieldset">
                            <div className="form-body">
                                { this.props.customer.isGuest == false &&
                                    <fieldset id="shippingAddresses" className="form-fieldset">
                                        <div className="form-body">
                                            <div className="loadingOverlay-container">
                                                <div className="form-field">
                                                    <DropdownSelect
                                                        inline={ true }
                                                        value={ this.state.addressId }
                                                        onChange={ ({ target }) => this._selectAddress(target.value) }
                                                        label={'Shipping Address'}
                                                        id={ 'single_shipping_dropdown' }
                                                        options={ this._formatOptions(this.props.customer.addresses || []) }
                                                        className = {"single_shipping_dropdown"}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                }
                                { this.state.display_single_shipping_address &&
                                    <div>
                                        <Address
                                            name={ 'shipping' }
                                            address={ this.state.address }
                                            countries={ this.props.countries }
                                            onChange={ (fieldName, address) => this._onChange(fieldName, address) }
                                            country_err = { this.props.single_ship_country_err }
                                            firstname_err = { this.props.single_ship_firstname_err }
                                            lastname_err = { this.props.single_ship_lastname_err }
                                            addressline1_err = { this.props.single_ship_addressline1_err }
                                            city_err  = { this.props.single_ship_city_err }
                                            state_err  = { this.props.single_ship_state_err }
                                            postalcode_err = { this.props.single_ship_postalcode_err }
                                            phone_err  = { this.props.single_ship_phone_err }
                                            landmark_err  = { this.props.single_ship_landmark_err }    
                                        />
                                    </div>
                                }
                            </div>
                        </fieldset>
                        <div className="form-body">
                            <CheckInput
                                name={ 'sameasshippingaddress' }
                                label={ <span>My Billing address is the same as my Shipping address</span> }
                                value={ 'sameasshippingaddress' }
                                checked={ this.props.is_checked }
                                onChange={ this.props.onchange_sameAsShipping } 
                            />
                        </div>
                    </div>
                </fieldset>
                <ShippingOptions
                    options={ this.props.options }
                    selectedOptionId={ this.props.selectedOptionId }
                    isSelectingShippingOption={ this.props.isSelectingShippingOption() }
                    isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress() }
                    onSelect={ this.props.onSelect }
                    single_shipping_option_err = { this.props.single_shipping_option_err }
                />
                {
                    this.props.enableOrderComments && 
                    // <TextInput
                    //     id={ `order_comments` }
                    //     label={ 'Order Comments' }
                    //     name = { `order_comments` }
			        //     value = {this.state.order_comment_value}
                    //     onChange={this.update_comment_text}
                    //     width={ 'half' } 
                    // />
                    <fieldset className="form-fieldset" data-test="checkout-shipping-comments">
                        <legend className="form-legend optimizedCheckout-headingSecondary">{ 'Order Comments' }</legend>
                        <div className="form-body">
                            <div className="form-field">
                                <label htmlFor={ `order_comments` } className="form-label is-srOnly optimizedCheckout-form-label">{ 'Order Comments' }</label>
                                <input 
                                    name={ `order_comments` } 
                                    autoComplete="off" 
                                    className="form-input optimizedCheckout-form-input" 
                                    type="text" 
                                    name = { `order_comments` }
                                    onChange={this.update_comment_text}
                                    value={this.state.order_comment_value} 
                                />
                            </div>
                        </div>
                    </fieldset>
                }
            </Fragment>
        );
    }

    _getAddress() {
        const consignment = this.props.consignment;
        return consignment && consignment.shippingAddress;
    }

    _selectAddress(addressId) {
        //console.log('//////////////////////////');
        //console.log(addressId);
        //console.log(this.props.consignments);

        this.setState({addressId:addressId});
        if(addressId == ''){
            this.setState( ()=> ({display_single_shipping_address : true}));
            this.setState({address:{firstName: "",lastName: "",email: "",company: "",address1: "",address2: "",city: "",stateOrProvince: "",stateOrProvinceCode: "",country: "",countryCode: "",postalCode: "",phone: ""}});
        }
        
        if(addressId != ''){
            this.setState( ()=> ({display_single_shipping_address : false}));
            this.props.is_address_dropdown_selected(false);
            this.setState({ addressId }, () => {
                const shippingAddress = find(this.props.customer.addresses, { id: parseInt(addressId) });
                //console.log(shippingAddress);
                this.setState({address:shippingAddress});
                this.props.onAddressChange(shippingAddress);
            });
            //console.log(this.props.consignments[0].id);
        }else{
            this.props.is_address_dropdown_selected(true);
        }
    }

    //Update Order Comments Text Box
    update_comment_text(e){
        //console.log(e.target.value);
        this.setState({ order_comment_value: e.target.value});
        this.props.onchange_order_comments(e.target.value);
    }
    _onChange(fieldName, value) {
        const address = Object.assign(
            {},
            this.state.address,
            { [fieldName]: value }
        );

        this.setState({ address: address }, () => this._updateShippingAddress(fieldName));
    }

    _updateShippingAddress(fieldName) {
        if (this._shouldUpdateShippingAddress(fieldName)) {
            this._debouncedOnAddressChange();
        }
    }

    _isFormValid() {
        return this.state.address.firstName &&
            this.state.address.lastName &&
            this.state.address.address1 &&
            this.state.address.city &&
            this.state.address.postalCode &&
            (
                this.state.address.stateOrProvinceCode ||
                this.state.address.stateOrProvince
            ) &&
            this.state.address.countryCode &&
            this.state.address.phone;
    }

    _shouldUpdateShippingAddress(fieldName) {
        const shippingOptionUpdateFields = [
            'address1',
            'address2',
            'city',
            'postalCode',
            'stateOrProvince',
            'stateOrProvinceCode',
            'countryCode',
        ];

        if (!this._isFormValid()) {
            return false;
        }

        return (
            !this.props.options ||
            !this.props.options.length ||
            shippingOptionUpdateFields.includes(fieldName)
        );
    }
    _formatOptions(addresses) {
        return addresses.map(address => ({
            name: this._formatAddress(address),
            code: address.id.toString(),
            key: address.id,
            value: address.id.toString(),
        }));
    }
    _formatAddress(address) {
        return `${address.address1} ${address.address2},
            ${address.stateOrProvince}, ${address.country}`;
    }
}
