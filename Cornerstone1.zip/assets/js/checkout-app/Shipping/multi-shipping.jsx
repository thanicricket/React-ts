import React, { Fragment } from 'react';
import { find } from 'lodash';
import Consignment from './consignment';
import TextInput from '../components/TextInput/text-input';

export default class MultiShipping extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            multiple_shipping_selected : [],
            id_count : 0,
            order_comment_value : this.props.order_comments ? this.props.order_comments : '',
        };
        this.count_update = this.count_update.bind(this);
        this.update_comment_text=this.update_comment_text.bind(this);
        //this.onchange_shipping_address = this.onchange_shipping_address.bind(this);
    }

    
    count_update(){
        ////console.log("count_update");
        this.setState({id_count : this.state.id_count +1});
    }

    render() {
        return (
            <Fragment>
            { this.props.customer.id ?
                <ul className="consignmentList">
                    {
                        (this.props.cart.lineItems.physicalItems || []).map((item) => (
                            <li className="multi_shipping_consignment">
                                <Consignment
                                    key={ item.id }
                                    item={ item }
                                    item_id={ item.id }
                                    addresses={ this.props.customer.addresses || [] }
                                    isSelectingShippingOption={ () => this._isSelectingShippingOption(item.id) }
                                    isUpdatingShippingAddress={ () => this._isUpdatingShippingAddress(item.id) }
                                    onConsignmentUpdate={ this.props.onConsignmentUpdate }
                                    consignment={ this._findConsignment(item.id) || {} }
                                    product_id = { item.productId }
                                    //is_selected_data = {this.props.single_shipping_consign}
                                    consignment_array = {this.props.consignments_array}
                                    //physical_product_count ={ this.props.physical_product_count }
                                    multi_shipping_address_err = { this.props.multi_shipping_address_err }
                                    //multi_shipping_address_change = { (address_id,address_info)=>this.onchange_shipping_address(address_id,address_info)}
                                />
                            </li>
                        ))
                    }
                </ul>
                :
                <div>
                    <div className="checkout-step-info">
                        To ship your items to multiple addresses you need to 
                        <a onClick={()=> this.props.login_toggle()}> sign in to your account </a> 
                        <span> or <a target="_blank" href="/login.php?action=create_account">create an account </a> prior to proceeding.
                        </span>
                    </div>
                </div>
            }
            { this.props.customer.id!=0 &&
                this.props.enableOrderComments && 
                // <TextInput
                //     id={ `order_comments` }
                //     label={ 'Order Comments' }
                //     name = { `order_comments` }
                //     value = {this.state.order_comment_value}
                //     onChange={this.update_comment_text}
                //     width={ 'half' } 
                // />
                <fieldset className="form-fieldset" data-test="checkout-shipping-comments">
                    <legend className="form-legend optimizedCheckout-headingSecondary">{ 'Order Comments' }</legend>
                    <div className="form-body">
                        <div className="form-field">
                            <label htmlFor={ `order_comments` } className="form-label is-srOnly optimizedCheckout-form-label">{ 'Order Comments' }</label>
                            <input 
                                name={ `order_comments` } 
                                autoComplete="off" 
                                className="form-input optimizedCheckout-form-input" 
                                type="text" 
                                name = { `order_comments` }
                                onChange={this.update_comment_text}
                                value={this.state.order_comment_value} 
                            />
                        </div>
                    </div>
                </fieldset>
            }
            { this.props.customer.id!=0 &&
                <div className="form-actions">
                    <button id="checkout-shipping-continue" className="button button--primary optimizedCheckout-buttonPrimary" disabled="" type="submit">Continue</button>
                </div>
            }
            </Fragment>
        );
    }

    /*onchange_shipping_address(address_id,address_info){
        this.props.onchange_multi_shipping_address(address_id,address_info);
    }*/
    //Update Order Comments Text Box
    update_comment_text(e){
        ////console.log(e.target.value);
        this.setState({ order_comment_value: e.target.value});
        this.props.onchange_order_comments(e.target.value);
    }

    _isSelectingShippingOption(itemId) {
        const consignment = this._findConsignment(itemId);
        return consignment && this.props.isSelectingShippingOption(consignment.id);
    }

    _isUpdatingShippingAddress(itemId) {
        const consignment = this._findConsignment(itemId);

        return consignment ?
            this.props.isUpdatingConsignment(consignment.id) :
            this.props.isCreatingConsignments();
    }

    _findConsignment(itemId) {
        return find(this.props.consignments, (consignment) => {
            return consignment.lineItemIds.length === 1 &&
                consignment.lineItemIds[0] === itemId;
        });
    }
}
