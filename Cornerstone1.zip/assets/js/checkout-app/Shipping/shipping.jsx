import React, { Fragment } from 'react';
import { find } from 'lodash';
import Section from '../components/Section/section';
import ShippingToggle from './shipping-toggle';
import SingleShipping from './single-shipping'
import MultiShipping from './multi-shipping'
import Button from '../components/Button/button';
import validator from 'validator';
import TextInput from '../components/TextInput/text-input';

export default class Shipping extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            multiShipping: (this.props.consignments || []).length > 1,
            order_comments_data : '',
            single_ship_country_err : '',
            single_ship_firstname_err : '',
            single_ship_lastname_err : '',
            single_ship_addressline1_err : '',
            single_ship_city_err : '',
            single_ship_state_err : '',
            single_ship_postalcode_err : '',
            single_ship_phone_err : '',
            is_address_same_as_shipping : true,
            single_shipping_selected : "true",
            single_shipping_option_err : '',
            multi_shipping_address_err : '',
            is_single_address_validation_required : false,
            //multi_shipping_data : { address : {} }
            //multi_shipping_address_data : []
        };
        this.handleSingleShippingValidation = this.handleSingleShippingValidation.bind(this);
        this.handleMultipleShippingValidation = this.handleMultipleShippingValidation.bind(this);
        this.updateOrderComments = this.updateOrderComments.bind(this);
        this.updateCheckbox = this.updateCheckbox.bind(this);
        this.updateSingleAddressFieldValidation = this.updateSingleAddressFieldValidation.bind(this);
        //this.updateAddressInfo = this.updateAddressInfo.bind(this);
    }

    componentWillMount(){
        if(this.props.customer.isGuest){
            this.setState( ()=> ({is_single_address_validation_required : true}));
        }
    }

    componentDidMount() {
        if(this.state.multiShipping){
            this.setState( (prevState)=> { 
                this.props.sameAsShipping(false);
                return ({is_address_same_as_shipping : false})
            });
        }else{
            this.props.sameAsShipping(this.state.is_address_same_as_shipping);
        }
    }

    render() {
        return (
            <Section
                header={ 'Shipping' }
                count={'2'}
                data_show={this.props.data_show} 
                data_shipping ={'true'}
                shipping_option={this.state.multiShipping}
                edit_button_show = {this.props.edit_button_shipping}
                edit_checkout_section = {this.props.edit_shipping_section}
                populate_address_section = { this.props.consignments }
                cart_item_details = { this.props.cart.lineItems.physicalItems }
                header_container = { 'shipping'}
                body={
                    <Fragment>
                        <div className="checkout-form">
                            <div className="form-legend-container">
                                <legend className="form-legend optimizedCheckout-headingSecondary" data-test="shipping-address-heading">{this.state.multiShipping ? "Choose where to ship each item" : "Shipping Address" }</legend>
                            </div>
                            {
                                this._hasMultiplePhysicalItems() &&
                                this.props.multiple_shipping_store_setting &&
                                <ShippingToggle
                                    onChange={ (value) => this._toggleMultiShipping(value) }
                                    multiShipping={ this.state.multiShipping } />
                            }
                            {   // Check if Multiple Shipping Store Setting is Enabled
                                this.state.multiShipping && this.props.multiple_shipping_store_setting ?
                                <div>
                                    <div>
                                        <form noValidate="" onSubmit={this.handleMultipleShippingValidation}>
                                            <MultiShipping
                                                customer={ this.props.customer }
                                                enableOrderComments = { this.props.enableOrderComments }
                                                consignments={ this.props.consignments }
                                                cart={ this.props.cart }
                                                login_toggle = {this.props.login_toggle}
                                                isUpdatingConsignment={ this.props.isUpdatingConsignment }
                                                isCreatingConsignments={ this.props.isCreatingConsignments }
                                                isSelectingShippingOption={ this.props.isSelectingShippingOption }
                                                cart={ this.props.cart }
                                                onConsignmentUpdate={ this.props.onConsignmentUpdate }
                                                onchange_order_comments = { (order_comments)=>this.updateOrderComments(order_comments)}
                                                order_comments = { this.state.order_comments_data }
                                                single_shipping_consign={ this.state.single_shipping_selected }
                                                //physical_product_count ={ this.props.cart.lineItems.physicalItems.length }
                                                consignments_array = { this.props.overall_checkout_data }
                                                multi_shipping_address_err = { this.state.multi_shipping_address_err }
                                                //onchange_multi_shipping_address = { (address_id,address_info)=>this.updateAddressInfo(address_id,address_info)}
                                            /> 
                                            
                                                {/* <Button 
                                                    label='CONTINUE'
                                                    type = 'submit'
                                                /> */}
                                        </form>
                                    </div>
                                </div>
                                :
                                <div>
                                    <div>
                                        <form autoComplete="on" onSubmit={this.handleSingleShippingValidation} noValidate="">
                                            <SingleShipping
                                                countries={ this.props.countries }
                                                customer={ this.props.customer }
                                                consignments={ this.props.consignments }
                                                onConsignmentUpdate={ this.props.onConsignmentUpdate }
                                                enableOrderComments = { this.props.enableOrderComments }
                                                address={ this.props.address }
                                                cart={ this.props.cart }
                                                onAddressChange={ this.props.onAddressChange }
                                                selectedOptionId={ this.props.selectedOptionId }
                                                options={ this.props.options }
                                                isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress }
                                                isSelectingShippingOption={ this.props.isSelectingShippingOption }
                                                onSelect={ this.props.onShippingOptionChange }
                                                single_ship_country_err = { this.state.single_ship_country_err }
                                                single_ship_firstname_err = { this.state.single_ship_firstname_err }
                                                single_ship_lastname_err = { this.state.single_ship_lastname_err }
                                                single_ship_addressline1_err = { this.state.single_ship_addressline1_err }
                                                single_ship_city_err  = { this.state.single_ship_city_err }
                                                single_ship_state_err  = { this.state.single_ship_state_err }
                                                single_ship_postalcode_err = { this.state.single_ship_postalcode_err }
                                                single_ship_phone_err  = { this.state.single_ship_phone_err }
                                                single_ship_landmark_err  = { this.state.single_ship_landmark_err }
                                                onchange_order_comments = { (order_comments)=>this.updateOrderComments(order_comments)}
                                                is_address_dropdown_selected = { (is_selected)=>this.updateSingleAddressFieldValidation(is_selected)}
                                                order_comments = { this.state.order_comments_data }
                                                onchange_sameAsShipping = { this.updateCheckbox }
                                                is_checked = { this.state.is_address_same_as_shipping }
                                                single_shipping_option_err = { this.state.single_shipping_option_err }
                                            />
                                            <div className="form-actions">
                                                <button id="checkout-shipping-continue" className="button button--primary optimizedCheckout-buttonPrimary" type="submit">Continue</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                // <form onSubmit={this.handleSingleShippingValidation} >
                                //     <SingleShipping
                                //         countries={ this.props.countries }
                                //         customer={ this.props.customer }
                                //         consignments={ this.props.consignments }
                                //         onConsignmentUpdate={ this.props.onConsignmentUpdate }
                                //         enableOrderComments = { this.props.enableOrderComments }
                                //         address={ this.props.address }
                                //         cart={ this.props.cart }
                                //         onAddressChange={ this.props.onAddressChange }
                                //         selectedOptionId={ this.props.selectedOptionId }
                                //         options={ this.props.options }
                                //         isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress }
                                //         isSelectingShippingOption={ this.props.isSelectingShippingOption }
                                //         onSelect={ this.props.onShippingOptionChange }
                                //         single_ship_country_err = { this.state.single_ship_country_err }
                                //         single_ship_firstname_err = { this.state.single_ship_firstname_err }
                                //         single_ship_lastname_err = { this.state.single_ship_lastname_err }
                                //         single_ship_addressline1_err = { this.state.single_ship_addressline1_err }
                                //         single_ship_city_err  = { this.state.single_ship_city_err }
                                //         single_ship_state_err  = { this.state.single_ship_state_err }
                                //         single_ship_postalcode_err = { this.state.single_ship_postalcode_err }
                                //         single_ship_phone_err  = { this.state.single_ship_phone_err }
                                //         single_ship_landmark_err  = { this.state.single_ship_landmark_err }
                                //         onchange_order_comments = { (order_comments)=>this.updateOrderComments(order_comments)}
                                //         is_address_dropdown_selected = { (is_selected)=>this.updateSingleAddressFieldValidation(is_selected)}
                                //         order_comments = { this.state.order_comments_data }
                                //         onchange_sameAsShipping = { this.updateCheckbox }
                                //         is_checked = { this.state.is_address_same_as_shipping }
                                //         single_shipping_option_err = { this.state.single_shipping_option_err }
                                //     />
                                //     <div className="form-actions">
                                //         <button id="checkout-shipping-continue" className="button button--primary optimizedCheckout-buttonPrimary" type="submit">Continue</button>
                                //     </div>
                                //      <Button 
                                //         label='CONTINUE'
                                //         type = 'submit'
                                        
                                //     /> 
                                // </form>
                            }
                        </div>
                    </Fragment>
                } 
            />
        );
    }

    /*updateAddressInfo(address_id,address_info){
        ////console.log(address_info);
        ////console.log(address_id);

        this.setState( () => ({}));
        multi_shipping_address_data
        const shippingAddress = find(this.props.customer.addresses, { id: parseInt(15) });
        ////console.log(shippingAddress);
    }*/

    //Update the is Address Same as Shipping Address Checkbox
    updateCheckbox(){
        this.setState( (prevState)=> { 
            this.props.sameAsShipping(!prevState.is_address_same_as_shipping);
            return ({is_address_same_as_shipping : !prevState.is_address_same_as_shipping})
        });
    }

    //Handles Multiple Address Validation
    handleMultipleShippingValidation(e) {
        e.preventDefault();
        $('.shipping_option_error').css('display','none');
        $('.shipping_dropdown_error').css('display','none');
        ////console.log('***************** MULTI SHIPPING VALIDATION ****************');
        //////console.log(this.props.consignments.length);
        //////console.log(this.props.consignments);
        //////console.log(this.state.multi_shipping_data);
        if(this.props.customer.isGuest == false){
            let is_multi_shipping_validated = true;
            $('.consignment_container').each(function(){
                if($(this).find('.shipping_dropdown').find("option").filter(':selected').text() == 'Enter a new Address'){
                    $(this).find('.shipping_dropdown_error').css('display','block');
                    is_multi_shipping_validated = false;
                }

                $(this).find("input:radio").each(function(){
                    var name = $(this).attr("name");
                    if($("input:radio[name="+name+"]:checked").length == 0){
                        $(this).parents('.consignment_container').find('.shipping_option_error').css('display','block');
                        is_multi_shipping_validated = false;
                    }
                });
            });
            
            if(is_multi_shipping_validated){
                this.props.onchange(this.state.order_comments_data);
                this.props.onChange_toggle_shipping();
            }
        }
    }

    updateSingleAddressFieldValidation(is_selected){
        this.setState({is_single_address_validation_required :is_selected });
    }

    //Update the Order Comments data
    updateOrderComments(order_comments) {
        this.setState( () => ({order_comments_data: order_comments}));
        //////console.log('*****************ORDER COMMENTS ****************')
        //////console.log(order_comments , "text");
    }

    //Handles Validation for Single Shipping Address
    handleSingleShippingValidation(e) {
        e.preventDefault();
        ////console.log('***************** SINGLE SHIPPING VALIDATION ****************');
        //////console.log(this.props.consignments);
        //////console.log(this.state.order_comments_data);
        //////console.log(this.props.consignments[0].selectedShippingOption);
        if(this.state.is_single_address_validation_required == true){
            const single_ship_country = document.getElementById('shippingCountry').value.trim() ? '' : 'Please select a country';
            const single_ship_first_name = document.getElementById('shippingFirstName').value.trim() ? '' : 'Please enter First Name';
            const single_ship_last_name = document.getElementById('shippingLastName').value.trim() ? '' : 'Please enter Last Name';
            const single_ship_address_line1 = document.getElementById('shippingAddressLine1').value.trim() ? '': 'Please enter Address Line 1';
            const single_ship_city = document.getElementById('shippingCity').value.trim() ? '' : 'Please enter City';
            const single_ship_state = document.getElementById('shippingState').value.trim() ? '' : 'Please enter State' ;
            const single_ship_postal_code = document.getElementById('shippingPostalCode').value.trim() ? '' : 'Please enter Postal Code';
            const single_ship_phone = document.getElementById('shippingPhone').value.trim() ? '' : 'Please enter Phone';
            const single_shipping_option_err = this.props.consignments[0].selectedShippingOption != null ? '' : 'Please select Shipping Option';
            this.setState ( () =>  {
                return {
                    single_ship_country_err : single_ship_country,
                    single_ship_firstname_err : single_ship_first_name,
                    single_ship_lastname_err : single_ship_last_name,
                    single_ship_addressline1_err : single_ship_address_line1,
                    single_ship_city_err : single_ship_city,
                    single_ship_state_err : single_ship_state,
                    single_ship_postalcode_err : single_ship_postal_code,
                    single_ship_phone_err : single_ship_phone,
                    single_shipping_option_err : single_shipping_option_err,
                    //single_ship_landmark_err : single_ship_landmark
                }
            });
            if(single_ship_country == '' && single_ship_first_name == '' && single_ship_last_name == '' && single_ship_address_line1 == '' && single_ship_city == '' && single_ship_state == '' && single_ship_postal_code == '' && single_ship_phone == '' && single_shipping_option_err == '' ){
                this.props.onchange(this.state.order_comments_data);
                this.props.sameAsShipping(this.state.is_address_same_as_shipping);
                this.props.onChange_toggle_shipping();
            }
        }else{
            const single_shipping_option_err = this.props.consignments[0].selectedShippingOption != null ? '' : 'Please select Shipping Option';
            this.setState ( () =>  {
                return {
                    single_shipping_option_err : single_shipping_option_err
                }
            });
            if(single_shipping_option_err == ''){
                this.props.onchange(this.state.order_comments_data);
                this.props.sameAsShipping(this.state.is_address_same_as_shipping);
                this.props.onChange_toggle_shipping();
            }
        }
    }

    _toggleMultiShipping(multiShipping) {
        
        if(!this.state.multiShipping && this.props.consignments.length > 0 && this.props.consignments[0].id){
            ////console.log('Multi Shipping Selected');
			this.setState({single_shipping_selected:this.props.consignments[0].id});
			////////////console.log('single_shipping_selected',this.props.consignments[0].id);
            ////////////console.log(this.state.single_shipping_selected)
            this.setState( (prevState)=> {
                ////console.log(!prevState.is_address_same_as_shipping);
                this.props.sameAsShipping(!prevState.is_address_same_as_shipping);
                 return ({is_address_same_as_shipping : false}) 
            });
		}else{
            //this.setState({single_shipping_selected:''});
            ////console.log('Single Shipping Selected');
            this.setState( (prevState)=> { 
                ////console.log(!prevState.is_address_same_as_shipping);
                this.props.sameAsShipping(!prevState.is_address_same_as_shipping);
                return ({is_address_same_as_shipping : true})
            });
        }
        /*if(!this.state.multiShipping && this.props.consignments.length > 0){
            ////console.log("multiple data");
            ////console.log(this.state.multiShipping);
            ////console.log(this.props.consignments.length);
            ////console.log(this.props.consignments);
            this.setState({single_shipping_selected:this.props.consignments[0].id});
        }else{
            ////console.log("single data");
            ////console.log(this.state.multiShipping);
            ////console.log(this.props.consignments.length);
            ////console.log(this.props.consignments);
            this.setState({single_shipping_selected:''});
        }*/
        this.setState({ multiShipping });
    }

    _hasSavedAddresses() {
        return this.props.customer.addresses &&
            this.props.customer.addresses.length > 1;
    }

    _hasMultiplePhysicalItems() {
        return this.props.cart.lineItems.physicalItems.length > 1;
    }
}
