import React from 'react';
import styles from './empty-state.scss';

export default class EmptyState extends React.PureComponent {
    render() {
        return (
            <div className="loadingOverlay-container">
                <div className="shippingOptions-panel optimizedCheckout-overlay">
                    <p className="shippingOptions-panel-message optimizedCheckout-primaryContent">
                        { this.props.body }
                    </p>
                </div>
            </div>
        );
    }
}
