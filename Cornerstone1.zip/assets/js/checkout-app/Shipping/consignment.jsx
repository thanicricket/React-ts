import { find } from 'lodash';
import React from 'react';
import Dropdown from '../components/Dropdown/dropdown';
import MultiShippingDropdown from '../components/Dropdown/multishippingdropdown';
import ItemLine from "../Cart/ItemLine/item-line";
import ShippingOptions from './shipping-options';
import styles from './consignment.scss';

export default class Consignment extends React.PureComponent {
    constructor(props) {
        super(props);

        const address = this._getCustomerAddress(this.props.address) || {};

        this.state = {
            addressId: (this._getAddress() || {}).id,
            optionId: (this._getOptions() || {}).id,
            is_shipping_option_selected : '',
            is_address_id_selected : '',
        };
    }

    componentWillMount() {
        
        if(this.props.consignment.selectedShippingOption != null) {
            this.setState( ()=> ({
                optionId : this.props.consignment.selectedShippingOption.id,
                is_shipping_option_selected:this.props.consignment.selectedShippingOption.id,
            }));
        }
        if(this._getAddress()) {
            this.props.addresses.map( (address_lines) => {
                if(address_lines.firstName == this.props.consignment.shippingAddress.firstName && address_lines.lastName == this.props.consignment.shippingAddress.lastName && address_lines.company == this.props.consignment.shippingAddress.company &&address_lines.address1 == this.props.consignment.shippingAddress.address1 && address_lines.address2 == this.props.consignment.shippingAddress.address2 &&address_lines.city == this.props.consignment.shippingAddress.city && address_lines.stateOrProvince == this.props.consignment.shippingAddress.stateOrProvince && address_lines.stateOrProvinceCode == this.props.consignment.shippingAddress.stateOrProvinceCode && address_lines.country == this.props.consignment.shippingAddress.country && address_lines.countryCode == this.props.consignment.shippingAddress.countryCode &&address_lines.postalCode == this.props.consignment.shippingAddress.postalCode && address_lines.phone == this.props.consignment.shippingAddress.phone){
                    ////console.log(this.props.consignment.shippingAddress);
                    this.setState( ()=> ({
                        addressId : address_lines.id,
                        is_address_id_selected : address_lines.id,
                    }));
                }
            });
        }

    }

    render() {
        return (
            <div className={`${ styles.consignment } consignment_container`}  data_shipping = "multi">
                <div className="consignment">
                    <figure className="consignment-product-figure">
                        <img src={ this.props.item.imageUrl } />
                    </figure>
                    <div className="consignment-product-body">
                        <h5 className="optimizedCheckout-contentPrimary">{ this.props.item.quantity } x { this.props.item.name }</h5>
                        { this.props.item.options && this.props.item.options.length > 0 &&
                            <ul className="product-options optimizedCheckout-contentSecondary" data-test="cart-item-product-options">
                                { this.props.item.options.map((option) => (
                                    <li key={`${ option.name }  ${ option.value }`} className="product-option" data-test="cart-item-product-option">{ option.name }  { option.value }</li>
                                ))
                                }
                            </ul>
                        } 
                    </div>
                </div>
                {/* <ItemLine
                    label={ `${ this.props.item.quantity } x ${ this.props.item.name }` }
                    imageUrl={ this.props.item.imageUrl }
                /> */}
                <MultiShippingDropdown
                    inline={ true }
                    value={ this.state.addressId }
                    onChange={ ({ target }) => this._selectAddress(target.value) }
                    label='Ships&nbsp;to&nbsp;&nbsp;'
                    id={this.props.item_id}
                    options={ this._formatOptions(this.props.addresses) }
                    className = {"shipping_dropdown dropdown-button dropdown-toggle--select"}
                    is_address_id_selected = { this.state.is_address_id_selected }
                    multi_shipping_address_err = { this.props.multi_shipping_address_err }
                />
                <div className='shipping_dropdown_error'>Please Select an Shipping Address</div>
                { this.state.addressId &&
                    <div>
                        <ShippingOptions
                            consignmentId={ this.props.consignment.id }
                            options={ this._getOptions() }
                            selectedOptionId={ this.state.optionId }
                            isSelectingShippingOption={ this.props.isSelectingShippingOption() }
                            isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress() }
                            onSelect={ (optionId) => this._selectOption(optionId) }
                            is_shipping_option_selected = { this.state.is_shipping_option_selected }
                        />
                        <div className='shipping_option_error'>Please Select an Shipping Option</div>
                    </div>
                }
            </div>
        );
    }

    _getOptions() {
        const consignment = this.props.consignment;
        return consignment && consignment.availableShippingOptions;
    }

    _getAddress() {
        const consignment = this.props.consignment;
        return consignment && consignment.shippingAddress;
    }

    _getOption() {
        const consignment = this.props.consignment;
        return consignment && consignment.selectedShippingOption;
    }

    _selectAddress(addressId) {
        if(addressId == ''){
            //location.href = '/account.php?action=add_shipping_address&from=checkout';
        }
        this.setState( () => ({is_address_id_selected : addressId}));
        /*
        this.setState({ addressId }, () => {
            
            const shippingAddress = find(this.props.addresses, { id: parseInt(addressId) });
           //console.log(this.props.consignment);
            //console.log(this.props.consignment_array);
            //this.props.multi_shipping_address_change(this.props.item.id,addressId);
            this.props.onConsignmentUpdate({
                id: this.props.consignment.id,
                shippingAddress,
                lineItems: [{
                    itemId: this.props.item.id,
                    quantity: this.props.item.quantity,
                }],
            })
        });*/
        //console.log('Correct Data Only selectaddress');
        //console.log(this.props.consignment_array.length);
        //console.log(this.props.physical_product_count);
        //console.log(this.props.consignment.id);
        //console.log(this.props.consignment_array.getConsignments());
       // if(this.props.consignment_array.length == this.props.physical_product_count){
            //console.log('Correct Data Only selectaddress');
            //console.log(this.props.consignment_array.length);
            //console.log(this.props.physical_product_count);
            //console.log(this.props.consignment.id);
            //console.log(this.props.consignment_array.getConsignments());
            
            //console.log('Address Consigment Change');
            //console.log(this.props.consignment);

            this.setState({ addressId }, () => {
                const shippingAddress = find(this.props.addresses, { id: parseInt(addressId) });

                if(shippingAddress){
                    this.props.onConsignmentUpdate({
                        id: this.props.consignment.id,
                        shippingAddress,
                        lineItems: [{
                            itemId: this.props.item.id,
                            quantity: this.props.item.quantity,
                        }],
                    })
                }
            });
        //}
    }

    _selectOption(optionId) {
        //console.log('optionId');
        //console.log(this.props.consignment);
        ////console.log(Object.keys(this.props.consignment).length);
        ////console.log(this.props.consignment.id);
        ////console.log(this.props.consignment_array);
        
        //let consignment_id_props = this.props.consignment.id;
        ////console.log(this.props.consignment.id);
        ////console.log(this.props.is_selected_data);
        this.setState( () => ({is_shipping_option_selected : optionId}));
        /*if(this.props.consignment){ 
            this.props.consignment_array.map( (consignment_line_items) => {
                //console.log(consignment_line_items);
                if(consignment_line_items.id == consignment_id_props){
                    //console.log("correct");
                    this.setState({ optionId }, () => {
                        //console.log(this.props.onConsignmentUpdate({
                            id: consignment_id_props,
                            shippingOptionId: optionId
                        }));
                    });
                    //console.log
                }
            });
        }*/
        //for(let i=0;i<this.props.)
        /*if(this.props.consignment.id && this.props.is_selected_data!=this.props.consignment.id){
            this.setState({ optionId }, () => {
                this.props.onConsignmentUpdate({
                    id: this.props.consignment.id,
                    shippingOptionId: optionId
                });
            });
        }*/
      //  if(this.props.consignment_array.length == this.props.physical_product_count){
            //console.log('Correct Data Only selectoption');
            //console.log(this.props.consignment_array.length);
            //console.log(this.props.physical_product_count);
            //console.log(this.props.consignment.id);
            //console.log(this.props.consignment_array.getConsignments());
            //console.log(this.props.is_selected_data);
            //if(this.props.is_selected_data!=''){
                this.setState({ optionId }, () => {
                    this.props.onConsignmentUpdate({
                        id: this.props.consignment.id,
                        shippingOptionId: optionId
                    });
                });
            //}
      //  }
    }

    _getCustomerAddress(address) {
        return address && find(
            this.props.addresses || [],
            a => this._formatAddress(a) === this._formatAddress(address)
        );
    }

    _formatAddress(address) {
        return `${address.address1} ${address.address2},
            ${address.stateOrProvince}, ${address.country}`;
    }

    _formatOptions(addresses) {
        return addresses.map(address => ({
            name: this._formatAddress(address),
            code: address.id.toString(),
            key: address.id,
            value: address.id.toString(),
        }));
    }
}
