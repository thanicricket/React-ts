import React, { Fragment } from 'react';
import { formatMoney } from 'accounting';
import EmptyState from './EmptyState/empty-state';
import RadioContainer from '../components/RadioContainer/radio-container';
import RadioInput from '../components/RadioInput/radio-input';
import RadioInputOption from '../components/RadioInput/radio_input_option';

export default class ShippingOptions extends React.PureComponent {
    render() {
       /// //console.log('shipping');
     //   //console.log(this.props.selectedOptionId);
            //console.log(this.props.isUpdatingShippingAddress);

        return (
            <RadioContainer
                label={ 'Shipping Method' }
                body={
                    <Fragment>
                        { this.props.isUpdatingShippingAddress &&
                            <EmptyState
                                body={ 'Loading shipping options...' }
                                isLoading={ true } />
                        }
                        {
                            !this.props.isUpdatingShippingAddress &&
                            (!this.props.options || !this.props.options.length) &&
                            <EmptyState
                                body={ 'Sorry, there is no available shipping option.' }
                                isLoading={ false } />
                        }
                            {
                                !this.props.isUpdatingShippingAddress &&
                                <div className="shippingOptions-container form-fieldset">
                                    <div className="loadingOverlay-container">
                                        <ul className="form-checklist optimizedCheckout-form-checklist">
                                            { this.props.options && this.props.options.length > 0 && (this.props.options).map(option => (
                                                <RadioInputOption
                                                    key={ option.id }
                                                    id={ 'shippingOption' + this.props.consignmentId + '-' + option.id }
                                                    name={ 'shippingOption' + this.props.consignmentId}
                                                    value={ option.id }
                                                    checked={ this.props.selectedOptionId === option.id }
                                                    is_shipping_option_selected = { this.props.is_shipping_option_selected }
                                                    description = {option.description}
                                                    cost = {` ${ formatMoney(option.cost) }`}
                                                    label={ `${ option.description } - ${ formatMoney(option.cost) }` }
                                                    isLoading={ this.props.isSelectingShippingOption || this.props.isUpdatingShippingAddress }
                                                    onChange={ () => this.props.onSelect(option.id) } />
                                            )) }
                                        </ul>
                                    </div>
                                </div>
                            }   
                        {
                            this.props.single_shipping_option_err != '' && <span className = 'shipping_option_error_message'>{this.props.single_shipping_option_err}</span>
                        }
                    </Fragment>
                } />
            );
        }
    }