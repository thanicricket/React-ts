import React, { Fragment } from 'react';
import Alert from '../components/Alert/alert';
import EmailInput from '../components/EmailInput/email-input';
import Panel from '../components/Panel/panel';
import PasswordInput from '../components/PasswordInput/password-input';
import PasswordInputForm from '../components/PasswordInput/password-input-form';
import SubmitButton from '../components/SubmitButton/submit-button';
import styles from './login-panel.scss';
import Section from '../components/Section/section';
import Button from '../components/Button/button';
import validator from 'validator';
import EmailInputGuest from '../components/EmailInput/email-input-guest';



export default class LoginPanel extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            email: '',
            password: '',
            customer_email_err : '',
            customer_password_err : ''
        };
    }

    render() {
        return (
            <Section 
                header={ 'Customer' }
                data_show={this.props.data_show}
                count={'1'}
                body = {
                    // <div className={ styles.container }>
                    //     <Panel body={
                    //         <Fragment>
                    //             {/* <div className={ styles.header }>
                    //                 <div className={ styles.heading }>
                    //                     Welcome Back!
                    //                 </div>

                    //                 <a
                    //                     onClick={ this.props.onClose }
                    //                     className={ styles.closeButton }>
                    //                     &#10005;
                    //                 </a>
                    //             </div> */}

                    //             <form onSubmit={ (event) => this._signIn(event) } noValidate>
                    //                 { this.props.errors &&
                    //                     <Alert body={ this.props.errors.body.detail } />
                    //                 }

                    //                 <div>
                    //                 <p><span>Don’t have an account? <a target="_blank" href="/login.php?action=create_account">Create an account</a> to continue.</span></p>
                    //                     <EmailInput
                    //                         id={ 'customerEmail' }
                    //                         label={ 'Email Address' }
                    //                         value={ this.state.email }
                    //                         name = { 'customerEmail' }
                    //                         onChange={ ({ target }) => this.setState({ email: target.value }) } 
                    //                     />
                    //                     <div className='email_error'>{ this.state.customer_email_err }</div>

                    //                     <PasswordInput
                    //                         id={ 'customerPassword' }
                    //                         label={ 'Password' }
                    //                         name = { 'customerPassword' }
                    //                         value={ this.state.password }
                    //                         onChange={ ({ target }) => this.setState({ password: target.value }) } 
                    //                     />
                    //                     <div className='password_error'>{ this.state.customer_password_err }</div>
                    //                     <a href='/login.php?action=reset_password' target="_blank">Forgot password?</a>
                    //                 </div>

                    //                 <div className={ styles.actionContainer }>
                    //                     <SubmitButton
                    //                         label={ this.props.isSigningIn ? `Signing in as ${ this.state.email }...` : 'Sign In' }
                    //                         isLoading={ this.props.isSigningIn } />
                    //                     { this.props.check_out_settings == true &&  
                    //                         <Button 
                    //                             label='CANCEL'
                    //                             onClick={ this.props.onClose }
                    //                         />
                    //                     }
                    //                 </div>
                    //             </form>
                    //         </Fragment>
                    //     } />
                    // </div>
                    <div className="checkout-view-content ">
                        <div>
                            <form id="checkout-customer-returning" onSubmit={ (event) => this._signIn(event) } className="checkout-form" data-test="checkout-customer-returning" noValidate="">
                                { this.props.errors &&
                                    <Alert body={ this.props.errors.body.detail } />
                                }
                                <fieldset className="form-fieldset">
                                    <legend className="form-legend is-srOnly">Returning Customer</legend>
                                    <div className="form-body">
                                        <p><span>Don’t have an account? <a target="_blank" href="/login.php?action=create_account">Create an account</a> to continue.</span></p>
                                         <EmailInputGuest
                                            id={ 'customerEmail' }
                                            label={ 'Email Address' }
                                            value={ this.state.email }
                                            name = { 'customerEmail' }
                                            onChange={ ({ target }) => this.setState({ email: target.value })}
                                            guest_email_error={ this.state.customer_email_err }
                                        />
                                        <PasswordInputForm
                                             id={ 'customerPassword' }
                                             label={ 'Password' }
                                             name = { 'customerPassword' }
                                             value={ this.state.password }
                                             customer_password_err = {this.state.customer_password_err}
                                             onChange={ ({ target }) => this.setState({ password: target.value }) } 
                                        />
                                        <div className="form-actions">
                                            <button id="checkout-customer-continue" className="button button--primary optimizedCheckout-buttonPrimary" data-test="customer-continue-button" type="submit" 
                                            disabled={ this.props.isSigningIn } >{ this.props.isSigningIn ? `Signing in as ${ this.state.email }...` : 'Sign In' }</button>
                                            { this.props.check_out_settings == true && 
                                            <a className="button optimizedCheckout-buttonSecondary" data-test="customer-cancel-button" id="checkout-customer-cancel" onClick={ this.props.onClose }>Cancel</a>
                                            }
                                        </div>
                                    </div>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                }
            />
        );
    }

    _signIn(event) {
        event.preventDefault();

        const customer_email  = event.target.customerEmail.value.trim();
        const customer_password  = event.target.customerPassword.value.trim();
        
        const is_email_valid = customer_email ? validator.isEmail(customer_email) : 'Email is required' ;
        const is_password_valid = customer_password ? true : false;
        
        this.setState ( () => ({customer_email_err : typeof is_email_valid === "boolean" ? is_email_valid ? '' : 'Email address must be valid' : 'Email address is required'}));
        this.setState ( () => ({customer_password_err : is_password_valid != '' ? '' : 'Password is required'}));
         
        if (this.state.email && this.state.password) {
            return this.props.onClick(this.state).then(this.props.onClose);
        }
    }
}
