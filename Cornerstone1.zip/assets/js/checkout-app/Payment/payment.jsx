import React, { Fragment } from 'react';
import Alert from '../components/Alert/alert';
import RadioContainer from '../components/RadioContainer/radio-container';
import RadioContainerPayment from '../components/RadioContainer/radio-container-payment';
import CheckContainer from '../components/CheckContainer/check-container';
import CheckInput from '../components/CheckInput/check-input';
import Section from '../components/Section/section';
import PaymentMethod from './PaymentMethod/payment-method';
import TextArea from '../components/TextArea/text-area';


export default class Payment extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            paymentData: {},
            methodId: null,
            gatewayId: null
        };
    }

    componentDidUpdate() {
        this.props.onChange(this.state);
    }
    componentWillMount(){
        ////console.log("this.props.termsandcondition_error");
       // //console.log(this.props.termsandcondition_error);
    }

    render() {
        return (
            <Section
                header={ 'Payment' }
                count={this.props.physical_products_length?'4':'3'}
                data_show={this.props.data_show}
                header_container = { 'payment'}
                body={
                    <Fragment>
                        { this.props.errors &&
                            <Alert body={ this.props.errors.message } />
                        }

                        <RadioContainerPayment
                            label={ 'Payment Method' }
                            body={ this.props.methods.map(method => (
                                <PaymentMethod
                                    key={ method.id }
                                    method={ method }
                                    selected={ this.state.methodId }
                                    onClick={ () => this._onMethodSelect(method.id, method.gateway) }
                                    onChange={ (paymentData) => this.setState({ paymentData }) } />
                            )) } />
                        {
                            //Terms And Conditions JSX
                            this.props.enableTermsAndConditions &&
                
                                <CheckContainer
                                    label={ 'Terms and Conditions' }
                                    body={
                                        <Fragment>
                                            { this.props.orderTermsAndConditionsType == 'textarea' && 
                                                 <TextArea
                                                    id={ `Termsandconditiontextarea` }
                                                    value={ this.props.orderTermsAndConditions }
                                                    rows= {2} 
                                                    cols= {40}
                                                    isreadonly = {true}
                                                    name = {`Termsandconditiontextarea`}
                                                 />
                                            }
                                            <CheckInput
                                                name={ 'termsandconditions' }
                                                label={
                                                    this.props.orderTermsAndConditionsType == 'textarea' ?
                                                    <p>Yes, I agree with the above terms and conditions</p> :
                                                    <p>Yes, I agree with the <a href={this.props.orderTermsAndConditionsLink}>terms and conditions</a></p>
                                                    }
                                                value={ 'termsandconditions' }
                                                checked={ this.props.termsandcondition }
                                                onChange={ ({ target }) => this._onSelect(target.value) } />
                                                <div className='termsandconditions_error'>{this.props.termsandcondition_error}</div>
                                        </Fragment>
                                    }
                                />
                        }
                    </Fragment>
                } />
        );
    }

    _onSelect () {
        ////console.log('selcted');
        this.props.check_terms_and_condition();
    }

    _onMethodSelect(id, gateway) {
        this.setState({
            methodId: id,
            gatewayId: gateway,
        });

        this.props.onClick(id, gateway);
    }
}
