import PageManager from './page-manager';

export default class Errors404 extends PageManager {}
