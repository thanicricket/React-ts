import PageManager from './page-manager';

export default class Errors404 extends PageManager {
	loaded() {
		// attempt to fix BC's lack of attention to trailing slashes
		var currentUrl = $(location).attr('href');
		var lastCharacter = currentUrl.substr(-1);
		if (lastCharacter != "/") {
		   window.location.replace(currentUrl + "/");
		}
		next();
	}
}
