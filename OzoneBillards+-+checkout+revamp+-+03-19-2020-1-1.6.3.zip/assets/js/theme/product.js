/*
 Import all product specific js
 */
import $ from 'jquery';
import PageManager from './page-manager';
import Review from './product/reviews';
import collapsibleFactory from './common/collapsible';
import ProductDetails from './common/product-details';
import videoGallery from './product/video-gallery';
import { classifyForm } from './common/form-utils';
import productCues from './custom/product-cues';
import productCueballs from './custom/product-cueballs';
import productTables from './custom/product-tables';
import productCuecases from './custom/product-cuecases';
// import freqBoughtTogether from './custom/freq-bought';

export default class Product extends PageManager {
    constructor(context) {
        super(context);
        this.url = location.href;
        this.$reviewLink = $('[data-reveal-id="modal-review-form"]');
    }

    before(next) {
        // Listen for foundation modal close events to sanitize URL after review.
        $(document).on('close.fndtn.reveal', () => {
            if (this.url.indexOf('#writeReview') !== -1 && typeof window.history.replaceState === 'function') {
                window.history.replaceState(null, document.title, window.location.pathname);
            }
        });

        // move H1 // product title depending on screen width
        // initial move
        if ($(window).width() < 800) {
            $('.productView-title, .banner--custom').insertBefore('.productView-images');
        }

        // disable other wrap upgrades if one wrap upgrade is selected
        $('.leatherwrap').on('change', function() {
            if ($(this).hasClass('isSelected')) {
                $('#attribute_5095_linenwrap').attr('disabled', true);
                $('.linenwrap').css('opacity', '.5');
            } else {
                $('#attribute_5095_linenwrap').attr('disabled', false);
                $('.linenwrap').css('opacity', '1');                
            }
        });
        $('.linenwrap').on('change', function() {
            if ($(this).hasClass('isSelected')) {
                $('#attribute_5097_leatherwrap').attr('disabled', true);
                $('.leatherwrap').css('opacity', '.5');                
            } else {
                $('#attribute_5097_leatherwrap').attr('disabled', false);
                $('.leatherwrap').css('opacity', '1');                
            }
        });

        next();
    }

    loaded(next) {
        let validator;

        // Init collapsible
        collapsibleFactory();

        this.productDetails = new ProductDetails($('.productView'), this.context, window.BCData.product_attributes);

        videoGallery();

        // update shipping message with a shipping terms custom field
        const customShippingText = $('.productView-info-name.shippingterms');
        if (customShippingText.length) {
            $('.productStats .shippingTerms').text(customShippingText.text().trim());
        }
        // const shippingTerms = $('.shippingTerms');
        // for (let i = 0; i < productFields.length; i++) {
        //     const productField = productFields[i];
        //     if (productField.innerText === 'shippingTerms:') {
        //         const field = $(productField).next();
        //         console.log(shippingTerms[0].innerText('terms'));
        //         console.log(field[0].innerText('field'));
        //         shippingTerms[0].innerText = field[0].innerText;
        //     }
        // }

        const $reviewForm = classifyForm('.writeReview-form');
        const review = new Review($reviewForm);

        $('body').on('click', '[data-reveal-id="modal-review-form"]', () => {
            validator = review.registerValidation();
        });

        $reviewForm.on('submit', () => {
            if (validator) {
                validator.performCheck();
                return validator.areAll('valid');
            }
            return false;
        });

        /*
        ## load page specific scripts
        */
        // if is Cue custom template
        if ($('.productCues').length) {
            productCues();
        // if it's Cue Ball custom template
        } else if ($('.productCueballs').length) {
            productCueballs();
        // if it's pool table custom template
        } else if ($('.productTables').length) {
            productTables();
        } else if ($('.productCuecases').length) {
            productCuecases();
        }

        /*
        ## if it's any custom product page
        */
        if ($('#form-action-customAddToCart').length) {
            // wire up the custom add to cart button
            $('#form-action-customAddToCart, #form-action-TopCustomAddToCart').on('click', () => {
                // submit main product's form (we'll handle custom JS inside product-details.js)
                $('form[data-cart-item-add]').submit();
            });
            // let's use the product ID in our random string
            const thisProductID = $('.productView-options input[name="product_id"]').val();
            // get our full unique ID
            const uniqueId = `OZB-${thisProductID}-${Date.now().toString().substr(4)}`;
            // fill our main product's unique ID
            $('.productView-options .form-field.serviceid .form-input').attr('value', uniqueId);
            // fill our customizations unique ID
            $('.customizeProd-item .serviceid, #freeCase_serviceId').attr('value', uniqueId);
        } else {
        // it's not a custom product page
            // fill Unique ID field with "n/a" in case it's required
            $('.product-option-change .optionRow.serviceid .form-input').attr('value', 'n/a');
        }

        /*
        ## frequently bought together
        */
        // freqBoughtTogether();

        /*
        ## VARIOUS JS
        */
        // REMOVE THIS WHEN DONE TESTING /// BUILDING
        $('.productView .optionRow.testimageupload').hide();

        // Saved Message below price
        const num1 = $('.productView [data-price-before]').text().trim().replace('$', '').replace(',', '');
        const num2 = $('.productView [data-price-after]').text().trim().replace('$', '').replace(',', '');
        if (num1.length && num2.length) {
            const savedAmountUnFormatted = (num1 - num2);
            const formattedSavings = Number(savedAmountUnFormatted).toFixed(2);
            const savedPercent = 1 - (num2 / num1);
            const formattedPercent = (savedPercent * 100).toFixed(0);
            $('.productView .price-section--saving .savedAmount').text(`You Save: $${formattedSavings} (${formattedPercent}%)`);
        }

        // Remove thumbnail images if only 1 exists
        if ($('.productView-thumbnail').length === 1) {
            $('.productView-thumbnails').hide();
        }

        // Free Shipping or Nahhh?
        const productPrice = Number($('.productView-price .price--rrp').text().replace('$', '').replace(',', ''));
        const salePrice = Number($('.productView-price .price--withoutTax').text().replace('$', '').replace(',', ''));

        const freeShipPrice = 75;
        if ($(salePrice).length && salePrice > freeShipPrice) {
            $('.benefitbar-pv ul li:last-of-type').css("display", "inline-block");
        } else if (productPrice > freeShipPrice && !$(salePrice)) {
            $('.benefitbar-pv ul li:last-of-type').css("display", "inline-block");
        }

        next();
    }

    after(next) {
        this.productReviewHandler();

        next();
    }

    productReviewHandler() {
        if (this.url.indexOf('#write_review') !== -1) {
            this.$reviewLink.click();
        }
    }
}
