import $ from 'jquery';
import engraveEmbroider from './engrave-embroider';
// import utils from '@bigcommerce/stencil-utils';

export default function () {
    console.log('IntuitSolutions.net - Cue Cases Page'); // eslint-disable-line

    /* ==============================================
    ## hide any customizations that we don't want on this product
    ============================================== */
    // hide embroider if needed
    if ($('.productView-info-name.noembroider').length) {
        $('.customizeProd-item.embroider').hide();
    }

    /* ==============================================
    ## Engraving & Embroider
    ============================================== */
    // put if statesment so only fire this when we need it
    engraveEmbroider();
}
