import $ from 'jquery';
import engraveEmbroider from './engrave-embroider';
// import utils from '@bigcommerce/stencil-utils';

export default function () {
    console.log('IntuitSolutions.net - Cues Product Page'); // eslint-disable-line

    /* ==============================================
    ## hide any customizations that we don't want on this product
    ============================================== */
    // hide free case if needed
    if ($('.productView-info-name.nofreecase').length) {
        $('.freecase.optionRow-customization').hide();
    }

    // hide engraving if needed
    if ($('.productView-info-name.noengraving').length) {
        $('.customizeProd-item.engraving').hide();
    }

    // hide embroider if needed
    if ($('.productView-info-name.noembroider').length) {
        $('.customizeProd-item.embroider').hide();
    }

    // hide tip change if needed
    if ($('.productView-info-name.notipchange').length) {
        $('.customizeProd-item.tipchange').hide();
    }

    // hide shaft turndown if needed
    if ($('.productView-info-name.noturndown').length) {
        $('.customizeProd-item.turndown').hide();
    }

    // hide leather wrap if needed
    if ($('.productView-info-name.noleatherwrap').length) {
        $('.customizeProd-item.leatherwrap').hide();
    }

    // hide linen wrap if needed
    if ($('.productView-info-name.nolinenwrap').length) {
        $('.customizeProd-item.linenwrap').hide();
    }

    /* ==============================================
    ## UPDATE TOTAL PRICE
    ============================================== */
    function updateTotalPrice() {
        // grab base product's price
        let basePrice = Number($('.productView-price .price.price--withoutTax').attr('data-base-price').trim().replace('$', '').replace(',', ''));
        // loop over active // selected customizations to add to our total
        $('.customizeProd-item.isSelected').each((index, el) => {
            basePrice += Number($(el).attr('data-price'));
        });
        // check free case pricing
        const freeCaseprice = Number($('#freeCase-options .activeOption').attr('data-price')) || 0;
        // add free case price to base price
        basePrice = basePrice + freeCaseprice;
        // update front end to reflect total price
        $('.customizeProd-total, .productView-price .price.price--withoutTax').text(`$${basePrice.toFixed(2)}`);
    }

    /* ==============================================
    ## Cue Case Color functionality
    ============================================== */
    // product ID's for the various cue case products
    const cueCaseId = {
        ozrnd: {
            black: 2597,
            brown: 3101,
            burgundy: 5915,
            grey: 1846,
            blue: 633,
        },
        oz11: {
            black: 5007,
            brown: 3420,
            burgundy: 1931,
            grey: 1917,
            blue: 1301,
        },
        oz22: {
            black: 2489,
            brown: 5611,
            burgundy: 153,
            grey: 2006,
            blue: 2058,
        },
        oz24: {
            black: 3706,
            brown: 1276,
            burgundy: 3672,
            grey: 4857,
            blue: 759,
        },
        oz35: {
            black: 3250,
            brown: 2338,
            burgundy: 5268,
            grey: 1182,
            blue: 5398,
        },
    };

    // product ID's for the various cue case products
    const cueCaseServiceAttr = {
        ozrnd: {
            black: 5062,
            brown: 5064,
            burgundy: 5065,
            grey: 5063,
            blue: 5061,
        },
        oz11: {
            black: 5073,
            brown: 5072,
            burgundy: 5071,
            grey: 5070,
            blue: 5069,
        },
        oz22: {
            black: 5077,
            brown: 5078,
            burgundy: 5074,
            grey: 5075,
            blue: 5076,
        },
        oz24: {
            black: 5082,
            brown: 5080,
            burgundy: 5081,
            grey: 5083,
            blue: 5079,
        },
        oz35: {
            black: 5086,
            brown: 5085,
            burgundy: 5087,
            grey: 5084,
            blue: 5088,
        },
    };

    /*
    ## is cue over or under $200 ?
    */
    // get cue price
    const cuePrice = Number($('.productView-price meta[itemprop="price"]').attr('content'));
    // set up blank case attrs
    let cueCaseAttr = {};
    // change attrs depending on Cue price
    if (cuePrice < 200) {
        // hide appropriate options in our dropdown
        $('body').addClass('under200');
        // use correct attrs
        cueCaseAttr = {
            ozrnd: {
                black: 'attribute[4057]=17452',
                brown: 'attribute[4059]=17452',
                burgundy: 'attribute[4060]=17452',
                grey: 'attribute[4058]=17452',
                blue: 'attribute[4056]=17452',
            },
            oz11: {
                black: 'attribute[4091]=17454',
                brown: 'attribute[4090]=17454',
                burgundy: 'attribute[4089]=17454',
                grey: 'attribute[4088]=17454',
                blue: 'attribute[4087]=17454',
            },
            oz22: {
                black: 'attribute[4095]=17454',
                brown: 'attribute[4096]=17454',
                burgundy: 'attribute[4092]=17454',
                grey: 'attribute[4093]=17454',
                blue: 'attribute[4094]=17454',
            },
            oz24: {
                black: 'attribute[4100]=17454',
                brown: 'attribute[4098]=17454',
                burgundy: 'attribute[4099]=17454',
                grey: 'attribute[4101]=17454',
                blue: 'attribute[4097]=17454',
            },
            oz35: {
                black: 'attribute[4104]=17454',
                brown: 'attribute[4103]=17454',
                burgundy: 'attribute[4105]=17454',
                grey: 'attribute[4102]=17454',
                blue: 'attribute[4106]=17454',
            },
        };
    } else {
        // hide appropriate options in our dropdown
        $('body').addClass('over200');
        // update case options data-price since they're hard coded at lower price
        $('#freeCase-options option[data-case="oz11"]').attr('data-price', 0).text('Free Hard Case 1B/1S');
        $('#freeCase-options option[data-case="oz22"]').attr('data-price', 34).text('Upgrade Hard Case 2B/2S $34.00');
        $('#freeCase-options option[data-case="oz24"]').attr('data-price', 45).text('Upgrade Hard Case 2B/4S $45.00');
        $('#freeCase-options option[data-case="oz35"]').attr('data-price', 58).text('Upgrade Hard Case 3B/5S $58.00');
        // use correct attrs
        cueCaseAttr = {
            oz11: {
                black: 'attribute[4091]=17455',
                brown: 'attribute[4090]=17455',
                burgundy: 'attribute[4089]=17455',
                grey: 'attribute[4088]=17455',
                blue: 'attribute[4087]=17455',
            },
            oz22: {
                black: 'attribute[4095]=17455',
                brown: 'attribute[4096]=17455',
                burgundy: 'attribute[4092]=17455',
                grey: 'attribute[4093]=17455',
                blue: 'attribute[4094]=17455',
            },
            oz24: {
                black: 'attribute[4100]=17455',
                brown: 'attribute[4098]=17455',
                burgundy: 'attribute[4099]=17455',
                grey: 'attribute[4101]=17455',
                blue: 'attribute[4097]=17455',
            },
            oz35: {
                black: 'attribute[4104]=17455',
                brown: 'attribute[4103]=17455',
                burgundy: 'attribute[4105]=17455',
                grey: 'attribute[4102]=17455',
                blue: 'attribute[4106]=17455',
            },
        };
    }

    /*
    ## handle updating options with unique pricing
    */
    // main handler for "Free Case, Tip Tool or Upgrade Case:"
    $('.customizeProd-item .form-select.hasPricing').on('change', function() {
        // get this item's optionRow (we keep this div updated with all selected product data)
        const optionRow = $(this).parents('.customizeProd-item');
        // get selected option's value
        const selectedValue = $(this).val();
        // if didn't choose the blank / default option
        if (selectedValue.length !== 0) {
            // get selected option
            const selectedOption = $(this).find(`option[value=${selectedValue}]`);
            // update pricing on optionRow
            optionRow.attr('data-price', selectedOption.data('price'));
            // add class saying this customization is filled in
            optionRow.addClass('isSelected hasOptions-selected');
        } else {
            // remove classes saying this customization is filled in and if had options
            optionRow.removeClass('isSelected hasOptions-selected');
        }
        // always update total pricing
        updateTotalPrice();
    });

    /*
    ## handle updating free case row
    */
    $('.optionRow.casecolor .form-radio').on('click', function() {
        // deselect all other radio buttons
        $(this).siblings('.form-radio').prop('checked', false).change();
        // get the color selected
        const activeColor = $(this).attr('id').replace('cueCase-', '');
        // get active cases's SKU
        const activeCase = $('.optionRow-customization.freecase .activeOption').attr('data-case');
        // get our active case ID using our hard coded object
        const activeCaseId = cueCaseId[activeCase][activeColor];
        // update active option value (aka our product ID)
        $('.optionRow-customization.freecase .activeOption').val(activeCaseId);
        // get our active case attrs from hard coded object
        const activeCaseAttr = cueCaseAttr[activeCase][activeColor];
        // set our serviceID attr correctly
        const activeCaseServiceAttr = cueCaseServiceAttr[activeCase][activeColor];
        // update case service ID name
        $('#freeCase_serviceId').attr('name', `attribute[${activeCaseServiceAttr}]`);
        // update active option
        $('.optionRow-customization.freecase .activeOption').attr('data-attr', activeCaseAttr);
        // add class to freecase optionRow saying options selected
        $('.optionRow-customization.freecase').addClass('hasOptions-selected');
    });

    /*
    ## Free Case Customization
    */
    // main handler for "Free Case, Tip Tool or Upgrade Case:"
    $('.optionRow-customization.freecase .form-select').on('change', function() {
        // get this item's optionRow (we keep this div updated with all selected product data)
        const optionRow = $(this).parents('.optionRow-customization');
        // get selected option's value
        const selectedValue = $(this).val();
        // deselect any color options that were previously selected
        $('.optionRow.casecolor .form-radio').prop('checked', false).change();
        // remove hasoptions class to reset color options
        optionRow.removeClass('hasOptions-selected');
        // if didn't choose the blank / default option
        if (selectedValue.length !== 0) {
            // add class saying this customization is filled in
            optionRow.addClass('isSelected');
            // get selected option
            const selectedOption = $(this).find(`option[value=${selectedValue}]`);
            // add class to active option
            selectedOption.addClass('activeOption');
            // add class to active option
            selectedOption.siblings('option').removeClass('activeOption');
            // if is option that requires case color
            if (selectedOption.data('hasoptions')) {
                // add class saying this customization needs another option filled in
                optionRow.addClass('hasOptions');
                // show case color options
                $('.optionRow.casecolor').slideDown();
            } else {
                // remove class saying this customization needs another option filled in
                optionRow.removeClass('hasOptions');
                // hide case color options if they're showing
                $('.optionRow.casecolor').slideUp();
                // update case service ID name from option itself since there are no further options
                $('#freeCase_serviceId').attr('name', `attribute[${selectedOption.attr('data-service-attr')}]`);
            }
        } else {
            // remove classes saying this customization is filled in and if had options
            optionRow.removeClass('isSelected hasOptions');
            // remove active option class from all options
            optionRow.find('option').removeClass('activeOption');
            // hide case color options if they're showing
            $('.optionRow.casecolor').slideUp();
        }
        // always update total pricing
        updateTotalPrice();
    });

    /* ==============================================
    ## Engraving & Embroider
    ============================================== */
    // put if statesment so only fire this when we need it
    engraveEmbroider();

    // Display case color choice one thumbnail click
    $('.casecolor .form-radio').on('click', function(e) {
       let color = e.currentTarget.id.split('-');
       let firstLetter = color[1][0].toUpperCase();
       let colorWord = firstLetter + color[1].slice(1);
       $('.casecolor .form-label--inlineSmall span').text(colorWord);
    });

    // SELECT A DEFAULT FREE CASE
    // if we aren't hiding the freecases
    if ($('.productView-info-name.nofreecase').length === 0) {
        if (cuePrice < 200) {
            // click the first available option
            $('#freeCase-options option[data-case="OZSC02"]').prop('selected', true);
        } else {
            // click the first available option
            $('#freeCase-options option[data-case="oz11"]').prop('selected', true);
        }
        // update the select box changes
        $('#freeCase-options').change();
    }
}
