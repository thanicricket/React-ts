import $ from 'jquery';
import updateTotalPrice from './product-update-price';
import engraveEmbroider from'./engrave-embroider';

export default function () {
    console.log('IntuitSolutions.net - Pool Tables Product Page'); // eslint-disable-line

    engraveEmbroider();

    // hide linen wrap if needed
    if ($('.productView-info-name.nodrawer').length) {
        $('.customizeProd-item.drawer').hide();
    }

    /*
    ## handle updating options with unique pricing
    */
    $('.customizeProd-item .form-select.hasPricing').on('change', function() {
        // get this item's optionRow (we keep this div updated with all selected product data)
        const optionRow = $(this).parents('.customizeProd-item');
        // get selected option's value
        const selectedValue = $(this).val();
        // if didn't choose the blank / default option
        if (selectedValue.length !== 0) {
            // get selected option
            const selectedOption = $(this).find(`option[value=${selectedValue}]`);
            // update pricing on optionRow
            optionRow.attr('data-price', selectedOption.data('price'));
            // add class saying this customization is filled in
            optionRow.addClass('isSelected hasOptions-selected');
        } else {
            // remove classes saying this customization is filled in and if had options
            optionRow.removeClass('isSelected hasOptions-selected');
        }
        // always update total pricing
        updateTotalPrice();
    });

    /*
    ## update price when select embroider, furniture or drawer option
    */
    $('.customizeProd-item.embroider .optionRow.font .form-select, .customizeProd-item.furniture .form-select, .customizeProd-item.drawer .form-select, .customizeProd-item.furniture_md1 .form-select, .customizeProd-item.furniture_md2 .form-select').on('change', function() {
        // get this item's optionRow (we keep this div updated with all selected product data)
        const optionRow = $(this).parents('.customizeProd-item');
        // get selected option's value
        const selectedValue = $(this).val();
        // if didn't choose the blank / default option
        if (selectedValue.length !== 0) {
            // add class saying this customization is filled in
            optionRow.addClass('isSelected hasOptions-selected');
        } else {
            // remove classes saying this customization is filled in and if had options
            optionRow.removeClass('isSelected hasOptions-selected');
        }
        // always update total pricing
        updateTotalPrice();
    });

    /*
    ## handle showing felt color name
    */
    const feltOptionRow = $('.optionRow.choosefeltcolor');
    // if exists
    if (feltOptionRow.length) {
        // apply handler
        $('.form-radio', feltOptionRow).on('change', function() {
            const selectedValue = $(this).val();
            const selectedLabel = $(`[data-product-attribute-value="${selectedValue}"] span`).attr('title');
            // if first time
            if (!$('.table-felt-color').length) {
                feltOptionRow.append(`<div class="table-felt-color">${selectedLabel}</div>`);
                $('.table-felt-color').slideDown();
            } else {
                // just update text
                $('.table-felt-color').text(selectedLabel);
            }
        });
    }
}
