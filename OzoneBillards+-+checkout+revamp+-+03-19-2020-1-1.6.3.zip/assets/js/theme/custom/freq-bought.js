import $ from 'jquery';
import FreqBoughtProductDetails from '../custom/freq-bought-product-details';
import utils from '@bigcommerce/stencil-utils';
import swal from 'sweetalert2';

window.$ = $; // expose jQuery to window for testing

export default function () {
    console.log('IntuitSolutions.net - Frequently Bought Together'); // eslint-disable-line

    /* ==============================================
    ## update Total Price
    ============================================== */
    function updateTotalPrice() {
        // start with a fresh total
        let total = 0;
        // loop over all "checked" products
        $('.freqBought-item.isChecked').each((index, el) => {
            const thisPrice = $(el).find('.price.price--withoutTax').text().trim().replace('$', '').replace(',', '');
            total += Number(thisPrice);
        });
        // update total price on the front end
        $('#freqBought-totalPrice').text(`$${total.toFixed(2)}`);
    }

    /* ==============================================
    ## see if all selected products have options filled in
    ============================================== */
    function checkForOptionHelperText() {
        // make sure all products with options have options all filled in
        const productsCheckedWithOptions = $('.freqBought-item.hasOptions.isChecked').length;
        const productsCheckedWithFilledInOptions = $('.freqBought-item.hasOptions.isChecked.hasOptions-selected').length;
        // if all products with options aren't filled in
        if (productsCheckedWithOptions !== productsCheckedWithFilledInOptions) {
            $('.freqBought-helperText').show();
            // disabled add to cart
            $('#freqBought-addAll').addClass('button--disabled');
        } else {
            $('.freqBought-helperText').hide();
            // enabled add to cart
            $('#freqBought-addAll').removeClass('button--disabled');
        }
    }

    /* ==============================================
    ## applies handlers for our various interactions
    ============================================== */
    function applyHandlers() {
        console.log('Applied Handlers');

        /*
        ## THIS IS UNIQUE TO JUST OZONE!!!!
        */
        // handle all serviceID conflict stuff
        const serviceIdRow = $('.freqBought-itemOptions .optionRow.serviceid');
        // see if this is only option on the product... if so, we don't have to require options
        serviceIdRow.each((index, el) => {
            // to fix our validation... don't hold up validation because of our hidden serviceID
            $(el).addClass('option-selected');
            // fill in blank value to our serviceId field
            $(el).find('.form-input').attr('value', 'n/a');
            // if this is the only option, remoev "choose options" button since it's no longer needed
            const totalProductOptions = $(el).parents('.freqBought-itemOptions').find('.optionRow').length;
            // if there's one option total, it's our serviceID
            if (totalProductOptions === 1) {
                // grab this product's <li>
                const productItem = $(el).parents('.freqBought-item');
                // so hide our "choose options" button
                productItem.find('.freqBought-toggleOptions').hide();
                // remove "hasOptions" class from product <li>
                productItem.removeClass('hasOptions');
            }
            // see if we still need helper "option" text
            checkForOptionHelperText();
        });

        /*
        ## toggle options open / closed & load options if it's first time
        */
        $('.freqBought-toggleOptions').on('click touchstart', function(event) {
            // grab this product's <li>
            const $scope = $(this).parents('.freqBought-item');
            // toggle the options
            $('.freqBought-itemOptions', $scope).slideToggle();
            // if we haven't already loaded the options
            if (!$('.freqBought-itemOptions', $scope).hasClass('optionsWired')) {
                // fire up new Product Details for just this item's options
                new FreqBoughtProductDetails($scope);
                // add class so we don't fire again
                $('.freqBought-itemOptions', $scope).addClass('optionsWired');
            }
        });

        /*
        ## handle checking & unchecking list items
        */
        $('.freqBought-checkbox').on('change', function(event) {
            // get our entire product aka our scope
            const $scope = $(this).parents('.freqBought-item');
            // get this item's ID for targeting
            const productId = $scope.data('id');
            // grab status of checkbox
            const isChecked = $(this).prop('checked');
            // if input is now checked
            if (isChecked) {
                // add actively checked class
                $scope.addClass('isChecked');
                // add actively checked class to image as well
                $(`.freqBought-image[data-id="${productId}"]`).addClass('isChecked');
            } else {
                // remove active checked class
                $scope.removeClass('isChecked');
                // add actively checked class to image as well
                $(`.freqBought-image[data-id="${productId}"]`).removeClass('isChecked');
                // close options if they're open
                $('.freqBought-itemOptions', $scope).slideUp();
            }
            // always update "Total Price"
            updateTotalPrice();
            // see if we still need helper "option" text
            checkForOptionHelperText();
        });

        /*
        ## adding all items to the cart
        */
        // function to AJAX add each form
        function addAllToCart(productForms) {
            const forms = productForms;
            // let currentItem = 0; // for finding error item
            const runQueInOrder = () => {
                // when done all products
                if (forms.length === 0) {
                    // go to cart
                    window.location.href = '/cart.php';
                } else {
                    // currentItem++;
                    const endpoint = forms.shift();
                    utils.api.cart.itemAdd(new FormData(endpoint[1]), (err, response) => {
                        // take note of errors
                        const errorMessage = err || response.data.error;
                        // Guard statement
                        if (errorMessage) {
                            // Strip the HTML from the error message
                            const tmp = document.createElement('DIV');
                            tmp.innerHTML = errorMessage;
                            $('.freqBought .loadingOverlay').hide();
                            $('.button--addAll').val('Add All to Cart').prop('disabled', false);
                            // highlight correct item with the error
                            // $('.freqBought-item.isChecked').eq(currentItem - 1).addClass('hasOptions-error');
                            // scroll user to the error product
                            // const errorOffset = $('.freqBought-item.isChecked').eq(currentItem - 1).offset().top;
                            // $('html, body').animate({ scrollTop: (errorOffset - 30) }, 700);
                            // alert user of error
                            return swal({
                                text: tmp.textContent || tmp.innerText,
                                type: 'error',
                            });
                        }
                        // run next item
                        runQueInOrder();
                    });
                }
            };
            runQueInOrder();
        }

        /*
        ## handle adding all products to cart
        */
        $('#freqBought-addAll').on('click touchstart', () => {
            // make sure no checked options have errors
            if ($('.isChecked.hasOptions-error').length) {
                return swal({
                    text: 'Please check to see that there are no errors.',
                    type: 'error',
                });
            }
            // make sure all products with options have options all filled in
            const productsCheckedWithOptions = $('.freqBought-item.hasOptions.isChecked').length;
            const productsCheckedWithFilledInOptions = $('.freqBought-item.hasOptions.isChecked.hasOptions-selected').length;
            // if all products with options aren't filled in
            if (productsCheckedWithOptions !== productsCheckedWithFilledInOptions) {
                return swal({
                    text: 'Please make sure all options have been filled in.',
                    type: 'error',
                });
            }
            // show loading
            $('.freqBought .loadingOverlay').show();
            // set up fresh variable to store our forms to add to cart
            const productForms = [];
            // loop over each "Checked" option
            $('.freqBought-item.isChecked').each((index, el) => {
                // make sure inputs have up to date values
                $(el).find('.form-input').attr('value', $(el).find('.form-input').val());
                // push form markup to our forms array
                productForms.push($.parseHTML($(el).html()));
            });
            // add all products to cart
            addAllToCart(productForms);
        });
    }

    /* ==============================================
    ## AJAX options in if needed
    ============================================== */
    // count freq bought products with options
    const productsWithOptions = $('.freqBought-item.hasOptions').length;
    // start new counter so we can apply handlers when all are loaded
    let loadedCounter = 0;
    // if there are products that need their options loaded
    if (productsWithOptions) {
        // loop over our products with options
        $('.freqBought-item.hasOptions').each((index, el) => {
            // if didn't already load options
            if (!$(el).hasClass('optionsLoaded')) {
                // grab product ID
                const productId = $(el).data('id');
                // AJAX each product for our markup
                utils.api.product.getById(productId, { template: 'custom/freq-bought-together-list-options' }, (err, response) => {
                    // append markup to product card
                    $('.freqBought-itemOptions', el).append(response);
                    // if finished AJAX'ing
                    loadedCounter++;
                    console.log(`freqBought - loaded options for product ${loadedCounter} of ${productsWithOptions}`);
                    // are all options loaded?
                    if (loadedCounter === productsWithOptions) {
                        // update "Total Price" number
                        updateTotalPrice();
                        // see if helper text is needed
                        checkForOptionHelperText();
                        // apply handlers now all AJAX'ing is done
                        applyHandlers();
                    }
                    // add class so we only hit each product once
                    $(el).addClass('optionsLoaded');
                });
            } else {
                // if finished AJAX'ing
                loadedCounter++;
                console.log(`freqBought - loaded options for product ${loadedCounter} of ${productsWithOptions}`);
                // are all options loaded?
                if (loadedCounter === productsWithOptions) {
                    // update "Total Price" number
                    updateTotalPrice();
                    // see if helper text is needed
                    checkForOptionHelperText();
                    // apply handlers now all AJAX'ing is done
                    applyHandlers();
                }
            }
        });
    // no products have options, just get total and apply handlers
    } else {
        // update "Total Price" number
        updateTotalPrice();
        // see if helper text is needed
        checkForOptionHelperText();
        // apply handlers now all AJAX'ing is done
        applyHandlers();
    }
}
