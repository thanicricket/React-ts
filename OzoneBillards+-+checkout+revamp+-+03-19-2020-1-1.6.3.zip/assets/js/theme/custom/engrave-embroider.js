import $ from 'jquery';

export default function () {
    console.log('IntuitSolutions.net - Engraving & Embroider'); // eslint-disable-line

    /* ==============================================
    ## UPDATE TOTAL PRICE
    ============================================== */
    function updateTotalPrice() {
        // grab base product's price
        let basePrice = Number($('.productView-price .price.price--withoutTax').attr('data-base-price').trim().replace('$', '').replace(',', ''));
        // loop over active // selected customizations to add to our total
        $('.customizeProd-item.isSelected').each((index, el) => {
            basePrice += Number($(el).data('price'));
        });
        // check free case pricing
        const freeCaseprice = Number($('#freeCase-options .activeOption').data('price')) || 0;
        // add free case price to base price
        basePrice += freeCaseprice;
        // update front end to reflect total price
        $('.customizeProd-total, .productView-price .price.price--withoutTax').text(`$${basePrice.toFixed(2)}`);
    }

    /* ==============================================
    ## HANDLING FONT CHANGES
    ============================================== */
    function handleFonts(fontTarget, previewTarget) {
        fontTarget.on('change', function() {
            // if didn't select the placeholder (placeholder option has no value)
            if ($(this).val().length) {
                // grab selected font option
                const selectedFont = $(this).find(`option[value=${$(this).val()}]`);
                // grab selected option's text, make all lower case, strip out spaces
                const selectedText = selectedFont.data('font');
                // was this font already selected previously
                if (selectedFont.hasClass('fontWasLoaded')) {
                    // remove any "mgp-font-" classes already active on the preview
                    previewTarget.removeClass((index, css) => (css.match(/\bmgp-font-\S+/g) || []).join(' '));
                    // apply our new class to the preview
                    previewTarget.addClass(`mgp-font-${selectedText}`);
                } else {
                    // append style that will load this font and create class that makes it usable
                    /*
                        EXAMPLE: if option text was "Classy Font"
                        the <style></style> would be appended to the <head> with...
                            @font-face { font-family: 'classyfont';... }
                            .mgp-font-classfont { font-family: 'classyfont'; }
                        the font files should be in "content/fonts/" folder
                        for this font they should be named
                            "classyfont.woff2"
                            "classyfont.woff"
                            "classyfont.ttf"
                        you may have to add some line-height or font-size adjustments so looks consistent in the preview box
                        just add these manually to the stylesheet, ex:
                            .mgp-font-classyfont { font-size: 40px; }
                    */
                    const fontMarkup = `
                    <style type='text/css'>
                        @font-face {
                            font-family: '${selectedText}';
                            src: url('/content/fonts/${selectedText}.eot');
                            src: url('/content/fonts/${selectedText}.woff') format('woff'),
                            url('/content/fonts/${selectedText}.ttf') format('truetype');
                        }
                        .mgp-font-${selectedText} {font-family: '${selectedText}';}
                    </style>`;
                    $('head').append(fontMarkup);
                    // remove any "mgp-font-" classes already active on the preview
                    previewTarget.removeClass((index, css) => (css.match(/\bmgp-font-\S+/g) || []).join(''));
                    // apply our new class to the preview
                    previewTarget.addClass(`mgp-font-${selectedText}`);
                    // add class to this option so we don't append styles and load font files again
                    selectedFont.addClass('fontWasLoaded');
                }
                // set as active so we can get total and add to cart accurately
                fontTarget.parents('.customizeProd-item').addClass('isSelected');
            } else {
                // remove any "mgp-font-" classes already active on the preview
                previewTarget.removeClass((index, css) => (css.match(/\bmgp-font-\S+/g) || []).join(''));
                // set as injactive so we can get total and add to cart accurately
                fontTarget.parents('.customizeProd-item').removeClass('isSelected');
            }
            // always get total price of all items after
            updateTotalPrice();
        });
    }

    // grab engraving font select box
    const engravingFont = $('.customizeProd-item.engraving .font .form-select');
    // grab engraving preview target
    const engravingTarget = $('.customizeProd-item.engraving .engravingPreview');
    // apply handler
    handleFonts(engravingFont, engravingTarget);

    // grab embroider font select box
    const embroiderFont = $('.customizeProd-item.embroider .font .form-select');
    // grab embroider preview target
    const embroiderTarget = $('.customizeProd-item.embroider .embroiderPreview');
    // apply handler
    handleFonts(embroiderFont, embroiderTarget);

    //grab railEbroider font select box
    const railEmbroiderFont = $('.customizeProd-item.railEmbroider .font .form-select');
    console.log(railEmbroiderFont, 'railembfont');
    // grab railEmbroider preview target
    const railEmbroiderTarget = $('.customizeProd-item.railEmbroider .railEmbroiderPreview');
    // apply handler
    handleFonts(railEmbroiderFont, railEmbroiderTarget);


    /* ==============================================
    ## HANDLE TEXT UPDATES
    ============================================== */

    // handle updating text
    function handleText(target, action, whatToUpdate) {
        // target each option set with our given action
        target.on(action, function() {
            // grab value that was selected value
            let selectedValue = $(this).val();
            // if is a select box, have to get text, can't use value of the selected option itself
            if ($(this).is('select')) {
                // if didn't select the placeholder
                if (selectedValue.length !== 0) {
                    // grab selected option's text
                    selectedValue = $(this).find(`option[value=${selectedValue}]`).text();
                    // update target with that text
                    $(whatToUpdate).text(selectedValue);
                }
            } else {
                // if it's empty
                if (selectedValue.length === 0) {
                    // reset text and hide line since not required
                    $(whatToUpdate).text('Preview');
                    // remove class saying options are filled in for this customization product
                    target.parents('.customizeProd-item').removeClass('hasOptions-selected');
                } else {
                    // update our target with text they filled in
                    $(whatToUpdate).text(selectedValue);
                    // remove class saying options are filled in for this customization product
                    target.parents('.customizeProd-item').addClass('hasOptions-selected');
                }
            }
        });
    }

    // grab engraving input box
    const engravingInput = $('.customizeProd-item.engraving .inputField input');
    // grav engraving target (where we want to change text)
    const engravingText = $('.engravingText');
    // apply handler to this input
    handleText(engravingInput, 'keyup', engravingText);

    // grab embroider input box
    const embroiderInput = $('.customizeProd-item.embroider .inputField input');
    // grab embroider target (where we want to change text)
    const embroiderText = $('.embroiderText');
    // apply handler to this input
    handleText(embroiderInput, 'keyup', embroiderText);

    // grab railEmbroider input box
    const railEmbroiderInput = $('.customizeProd-item.railEmbroider .inputField input');
    //grab railEmbroider target (where we want to change text)
    const railEmbroiderText = $('.railEmbroiderText');
    //apply handlers to this input
    handleText(railEmbroiderInput, 'keyup', railEmbroiderText); 
}


/* ==============================================
    ## HANDLE FONT COLOR UPDATES
    ============================================== */


    function handleColor(colorTarget, previewTarget) {
        colorTarget.on('change', function() {
            // if didn't select the placeholder (placeholder option has no value)
            if ($(this).val().length) {
                // remove any "mgp-color-" classes already active on the preview
                previewTarget.removeClass((index, css) => (css.match(/\bmgp-color-\S+/g) || []).join(''));
                // grab selected font option
                const selectedColor = $(this).find(`option[value=${$(this).val()}]`);
                // grab selected option's text, make all lower case, strip out spaces
                const selectedText = selectedColor.data('color');
                // apply our new class to the preview
                previewTarget.addClass(`mgp-color-${selectedText}`);
            } else {
                // remove any "mgp-color-" classes already active on the preview
                previewTarget.removeClass((index, css) => (css.match(/\bmgp-color-\S+/g) || []).join(''));
            }
        });
    }

    //grab railEmbroider font select box
    const railEmbroiderFont = $('.customizeProd-item.railEmbroider .choosethreadcolor .form-select');
    // grab railEmbroider preview target
    const railEmbroiderTarget = $('.customizeProd-item.railEmbroider .railEmbroiderPreview');
    // apply handler
    handleColor(railEmbroiderFont, railEmbroiderTarget);
