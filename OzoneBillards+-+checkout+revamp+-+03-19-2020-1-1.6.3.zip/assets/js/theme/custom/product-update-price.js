import $ from 'jquery';

const updateTotalPrice = function() {
    // grab base product's price
    let basePrice = Number($('.productView-price .price.price--withoutTax').attr('data-base-price').trim().replace('$', '').replace(',', ''));
    // loop over active // selected customizations to add to our total
    $('.customizeProd-item.isSelected').each((index, el) => {
        basePrice += Number($(el).attr('data-price'));
    });
    // update front end to reflect total price
    $('.customizeProd-total, .productView-price .price.price--withoutTax').text(`$${basePrice.toFixed(2)}`);
}

export default updateTotalPrice;
