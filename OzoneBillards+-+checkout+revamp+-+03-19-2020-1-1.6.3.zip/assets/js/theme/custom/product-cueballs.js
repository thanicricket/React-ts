import $ from 'jquery';
import updateTotalPrice from './product-update-price';

export default function () {
    console.log('IntuitSolutions.net - Cue Ball Product Page'); // eslint-disable-line

    /* ==============================================
    ## UPDATE TOTAL PRICE
    ============================================== */
    // function updateTotalPrice() {
    //     // grab base product's price
    //     let basePrice = Number($('.productView-price .price.price--withoutTax').attr('data-base-price').trim().replace('$', '').replace(',', ''));
    //     // loop over active // selected customizations to add to our total
    //     $('.customizeProd-item.isSelected').each((index, el) => {
    //         basePrice += Number($(el).attr('data-price'));
    //     });
    //     // update front end to reflect total price
    //     $('.customizeProd-total, .productView-price .price.price--withoutTax').text(`$${basePrice.toFixed(2)}`);
    // }

    /* ==============================================
    ## IMAGE UPLOAD PREVIEW
    ============================================== */
    // grab our file upload input
    const uploadInput = $('.product-option-change .optionRow.imageupload .form-file').eq(0);

    // open input when click our button
    $('#openUploadInput').on('click touchstart', () => {
        uploadInput.trigger('click');
    });

    // function to handle the uploaded image
    function readURL(input) {
        if (input.files && input.files[0]) {
            // const preview = document.querySelector('img');
            const reader = new FileReader();
            reader.onload = (e) => {
                const fileType = e.target.result.split('/');
                const defaultImage = 'https://cdn3.bigcommerce.com/s-komfru/product_images/uploaded_images/yt-sample-logo.png';
                if (fileType[0] === 'data:application') {
                    $('#cueBallUpload').attr('src', defaultImage).css('display', 'block');
                    $('.uploadpreview-helpText').text('Your image has been succesfully uploaded but we\'re unable to show a preview. You probably used a vector based graphic which is perfect for printing but not for web display.').show();
                    $('#uploadpreview-clearImage').css('display', 'block');
                    $('.customizeProd-item.imageUpload').addClass('isSelected');
                } else {
                    const image = new Image();
                    image.src = reader.result;
                    $('#cueBallUpload').attr('src', e.target.result).css('display', 'block');
                    $('.uploadpreview-helpText').text('Your image has been succesfully uploaded and you can preview your image above.').show();
                    $('#uploadpreview-clearImage').css('display', 'block');
                    $('.customizeProd-item.imageUpload').addClass('isSelected');
                }
                // allow user to purchase since uploaded SOMETHING
                $('.button--addToCartCustomGolfBall').removeClass('button--disabled');
            };
            reader.readAsDataURL(input.files[0]);
            reader.addEventListener('load', () => {
                updateTotalPrice();
            }, false);
        } else {
            // since opened and closed upload window, the input has been empty
            // trigger all same events as if clicked "clear" button
            $('#uploadpreview-clearImage').trigger('click');
        }
    }

    // when new image is uploaded
    $(uploadInput).on('change', function() {
        readURL(this);
    });

    // clear image after one has been uploaded
    $('#uploadpreview-clearImage').on('click touchstart', () => {
        // clear the image
        $(uploadInput).val('');
        // clear image preview
        $('#cueBallUpload').attr('src', '');
        // hide helper text
        $('.uploadpreview-helpText').hide();
        // hide clear image link
        $('#uploadpreview-clearImage').hide();
        // remove our class so we don't add this item to the cart
        $('.customizeProd-item.imageUpload').removeClass('isSelected');
        // calculate total again
        updateTotalPrice();
    });
}
