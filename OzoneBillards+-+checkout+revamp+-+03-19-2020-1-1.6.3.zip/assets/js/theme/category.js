import { hooks } from '@bigcommerce/stencil-utils';
import CatalogPage from './catalog';
import $ from 'jquery';
import FacetedSearch from './common/faceted-search';

export default class Category extends CatalogPage {
    loaded(next) {
        if ($('#facetedSearch').length > 0) {
            this.initFacetedSearch();
        } else {
            this.onSortBySubmit = this.onSortBySubmit.bind(this);
            hooks.on('sortBy-submitted', this.onSortBySubmit);
        }

        // // move category description below subcategories, best sellers, or product grid
        if (!$('.container').hasClass('category--poolcues')) {
            const paragraphCount = $('.top_desc p').length;
            if (paragraphCount > 1) {
                // move
                $('.top_desc *:not(p:first):not(h1)').appendTo('.bottom_desc').show();
            }
        }

        next();
    }

    initFacetedSearch() {
        const $productListingContainer = $('#product-listing-container');
        const $facetedSearchContainer = $('#faceted-search-container');
        const productsPerPage = this.context.categoryProductsPerPage;
        let requestOptions = {
            config: {
                category: {
                    shop_by_price: true,
                    products: {
                        limit: productsPerPage,
                    },
                },
            },
            template: {
                productListing: 'category/product-listing',
                sidebar: 'category/sidebar',
            },
            showMore: 'category/show-more',
        };

        // if custom template... load the custom sidebar when refresh sidebar
        if ($('.productsWsidebarSubs').length) {
            // update templates for when faceted search is triggered
            requestOptions.template.productListing = 'category/product-listing-productsWsidebarSubs';
            requestOptions.template.sidebar = 'category/sidebar-productsWsidebarSubs';
        }

        this.facetedSearch = new FacetedSearch(requestOptions, (content) => {
            $productListingContainer.html(content.productListing);
            $facetedSearchContainer.html(content.sidebar);

            $('html, body').animate({
                scrollTop: 0,
            }, 100);
        });
    }
}
