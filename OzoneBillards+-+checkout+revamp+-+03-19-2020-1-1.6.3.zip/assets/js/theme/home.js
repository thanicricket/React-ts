import PageManager from './page-manager';

export default class Home extends PageManager {
    loaded(next) {
        // move H1 from top of page down to above
        $('.seo-bar').appendTo('.seo-bar-container');

        next();
    }
}
