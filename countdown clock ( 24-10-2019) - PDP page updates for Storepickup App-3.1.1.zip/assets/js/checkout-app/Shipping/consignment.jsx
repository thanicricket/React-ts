import { find } from 'lodash';
import React from 'react';
import Dropdown from '../components/Dropdown/dropdown';
import DropdownAddress from '../components/Dropdown/dropdown_address_shipping';
import ItemLine from "../Cart/ItemLine/item-line";
import ShippingOptions from './shipping-options';
import styles from './consignment.scss';

export default class Consignment extends React.PureComponent {
    constructor(props) {
        super(props);

        const address = this._getCustomerAddress(this.props.address) || {};

        this.state = {
            addressId: (this._getAddress() || {}).id,
            optionId: (this._getOptions() || {}).id,
	    class_name_address : 'address_ship',
	    class_name_optionId : 'option_ship',
        };
    }

    onPresonNameChange (){}
    onPickupDateChange (){}
	
	componentDidMount(){
		console.log('last_one');
	}
	
    render() {
	console.log("Consignment");
	for(let i=0;this.props.item && i<this.props.item.options.length;i++){
		if(this.props.item.options[i].name == "Selected Availability"){
			if(this.props.item.options[i].value == "INS"){
				if(this.props.addresses && this.props.addresses.length !=0){
					this.state.addressId = this.props.addresses[0].id;
					this.state.class_name_address = "address_ins";
					let optios_value = this._getOptions();
					for(let j=0;optios_value && j<optios_value.length;j++){
						if(optios_value[j].description == "Pickup In Store"){
							//this.state.optionId = optios_value[j].id;
							this.state.class_name_optionId = "option_ins";
						}
					}
				}
			}
		}
	}
        return (
            <div className={ styles.consignment + " Shipping_Sec_Products"}>
                <ItemLine
                    label={ `${ this.props.item.quantity } x ${ this.props.item.name }` }
		    qty= { this.props.item.quantity }
                    prod_options={ this.props.item.options }
                    imageUrl={ this.props.item.imageUrl }
					item_sku_value={this.props.item_sku}
						/>
		
                <DropdownAddress
                    inline={ true }
                    value={ this.state.addressId }
                    onChange={ ({ target }) => {this._selectAddress(target.value)} }
                    label='Ships&nbsp;to&nbsp;&nbsp;'
                    id='address'
                    options={ this._formatOptions(this.props.addresses) }
					class_name = {this.state.class_name_address}
                />
                { this.props.addresses[0] && this.state.addressId == this.props.addresses[0].id ? 
                    <ShippingOptions
                        consignmentId={ this.props.consignment.id }
                        options={ this._getOptions() }
                        selectedOptionId={ this.state.optionId }
                        isSelectingShippingOption={ this.props.isSelectingShippingOption() }
                        isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress() }
                        onSelect={ (optionId) => this._selectOption(optionId) }
						class_name = {this.state.class_name_optionId}
                    />
		    :
		    <ShippingOptions
                        consignmentId={ this.props.consignment.id }
                        options={ this._getOptions() }
                        selectedOptionId={ this.state.optionId }
                        isSelectingShippingOption={ this.props.isSelectingShippingOption() }
                        isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress() }
                        onSelect={ (optionId) => this._selectOption(optionId) }
						class_name = {this.state.class_name_optionId}
                    />
                }
		
            </div>
        );
    }

    _getOptions() {
        const consignment = this.props.consignment;
        return consignment && consignment.availableShippingOptions;
    }

    _getAddress() {
        const consignment = this.props.consignment;
        return consignment && consignment.shippingAddress;
    }

    _getOption() {
        const consignment = this.props.consignment;
        return consignment && consignment.selectedShippingOption;
    }

    _selectAddress(addressId) {
		console.log('addreesId');
		console.log(addressId);
        this.setState({ addressId }, () => {
            const shippingAddress = find(this.props.addresses, { id: parseInt(addressId) });

            this.props.onConsignmentUpdate({
                id: this.props.consignment.id,
                shippingAddress,
                lineItems: [{
                    itemId: this.props.item.id,
                    quantity: this.props.item.quantity,
                }],
            })
        });
    }

    _selectOption(optionId) {
        this.setState({ optionId }, () => {
            this.props.onConsignmentUpdate({
                id: this.props.consignment.id,
                shippingOptionId: optionId
            });
        });
    }

    _getCustomerAddress(address) {
        return address && find(
            this.props.addresses || [],
            a => this._formatAddress(a) === this._formatAddress(address)
        );
    }

    _formatAddress(address) {
        return `${address.address1} ${address.address2},
            ${address.stateOrProvince}, ${address.country}`;
    }

    _formatOptions(addresses) {
        return addresses.map(address => ({
            name: this._formatAddress(address),
            code: address.id.toString(),
            key: address.id,
            value: address.id.toString(),
        }));
    }
}
