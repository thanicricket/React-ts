import React, { Fragment } from 'react';
import { debounce } from 'lodash';
import Address from '../components/Address/address';
import ShippingOptions from './shipping-options';

export default class SingleShipping extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            address: {},
			ins_products:false,
			ship_products:false,
        };

        this._debouncedOnAddressChange = debounce(() => this.props.onAddressChange(this.state.address), 1000);
    }

    componentDidMount() {
        this.props.onAddressChange(this.props.address);
        this.setState({ address: this.props.address || {} });
    }

    render() {
		this.props.cart.lineItems.physicalItems.map((item) => {
			for(let i=0;item && i<item.options.length;i++){
				if(item.options[i].name == "Selected Availability"){
					if(item.options[i].value == "INS"){
						this.state.ins_products = true;
					}else if(item.options[i].value == "SHIP"){
						this.state.ship_products = true;
					}
				}
			}
		});

        return (
            <Fragment>
                <Address
                    name={ 'shipping' }
                    address={ this.state.address }
                    countries={ this.props.countries }
                    onChange={ (fieldName, address) => this._onChange(fieldName, address) } />
                <ShippingOptions
                    options={ this.props.options }
                    selectedOptionId={ this.props.selectedOptionId }
                    isSelectingShippingOption={ this.props.isSelectingShippingOption() }
                    isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress() }
                    onSelect={ this.props.onSelect }
					shipping_option_methods = "Single"
					class_name = {this.state.class_name_optionId}
				    shipping_method_of = "single"
					ins_products = {this.state.ins_products}
					ship_products = {this.state.ship_products}
                />
            </Fragment>
        );
    }

    _onChange(fieldName, value) {
        const address = Object.assign(
            {},
            this.state.address,
            { [fieldName]: value }
        );

        this.setState({ address: address }, () => this._updateShippingAddress(fieldName));
    }

    _updateShippingAddress(fieldName) {
        if (this._shouldUpdateShippingAddress(fieldName)) {
            this._debouncedOnAddressChange();
        }
    }

    _isFormValid() {
        return this.state.address.firstName &&
            this.state.address.lastName &&
            this.state.address.address1 &&
            this.state.address.city &&
            this.state.address.postalCode &&
            (
                this.state.address.stateOrProvinceCode ||
                this.state.address.stateOrProvince
            ) &&
            this.state.address.countryCode &&
            this.state.address.phone;
    }

    _shouldUpdateShippingAddress(fieldName) {
        const shippingOptionUpdateFields = [
            'address1',
            'address2',
            'city',
            'postalCode',
            'stateOrProvince',
            'stateOrProvinceCode',
            'countryCode',
        ];

        if (!this._isFormValid()) {
            return false;
        }

        return (
            !this.props.options ||
            !this.props.options.length ||
            shippingOptionUpdateFields.includes(fieldName)
        );
    }
}
