import React, { Fragment } from 'react';
import { formatMoney } from 'accounting';
import EmptyState from './EmptyState/empty-state';
import RadioContainer from '../components/RadioContainer/radio-container';
import RadioInput from '../components/RadioInput/radio-input';
import RadioInputOption from '../components/RadioInput/radio-input_option';

export default class ShippingOptions extends React.PureComponent {
    render() {
		console.log('shipping_option');
        return (
            <RadioContainer
                label={ 'Shipping Method' }
		data_value = "Shipping_option"
                body={
                    <Fragment>
                        { this.props.isUpdatingShippingAddress &&
                            <EmptyState
                                body={ 'Loading shipping options...' }
                                isLoading={ true } />
                        }
                        {
                            !this.props.isUpdatingShippingAddress &&
                            (!this.props.options || !this.props.options.length) &&
                            <EmptyState
                                body={ 'Sorry, there is no available shipping option.' }
                                isLoading={ false } />
                        }
                        {
                            !this.props.isUpdatingShippingAddress &&
                            this.props.options && this.props.options.length && (this.props.options).map(option => (
                            <RadioInputOption
                                key={ option.id }
                                name={ 'shippingOption' + this.props.consignmentId }
                                value={ option.id }
                                checked={ this.props.selectedOptionId === option.id }
                                label={ `${ option.description } - ${ formatMoney(option.cost) }` }
                                isLoading={ this.props.isSelectingShippingOption || this.props.isUpdatingShippingAddress }
                                onChange={ () => this.props.onSelect(option.id) } 
								class_name_value = {this.props.class_name}
								data_value_option = "Option_param"
								shipping_option_method = {this.props.shipping_option_methods}
								shipping_method_value = {this.props.shipping_method_of}
								ins_products = {this.props.ins_products}
								ship_products = {this.props.ship_products}
				/>
                        )) }
                    </Fragment>
                } />
            );
        }
    }