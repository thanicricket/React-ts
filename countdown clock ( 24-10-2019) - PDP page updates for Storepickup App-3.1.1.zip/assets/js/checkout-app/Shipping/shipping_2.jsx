import React, { Fragment } from 'react';
import { find } from 'lodash';
import Section from '../components/Section/section';
import ShippingToggle from './shipping-toggle';
import SingleShipping from './single-shipping'
import MultiShipping from './multi-shipping'
import Button from '../components/Button/button';
import styles from './shipping.scss';

export default class Shipping_2 extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            multiShipping: (this.props.consignments || []).length > 1,
			ins_products:false,
			ship_products:false,
			hidden_data:false,
        };
    }

    check_Shipping() {

	    if($("input:radio[name='shippingToggle']").length == 0 ||$("input:radio[name='shippingToggle']:checked").val() == 'multi'){

		var check_address_selected = true;
		$(".Shipping_Sec_Products").each(function(){
			if($(this).find('#address').find("option").filter(':selected').text() == ''){
				check_address_selected = false;
			}
		});
			
		if(check_address_selected){
			var check = true;
			if($(".Shipping_Sec_Products").length > 0){
				$(".Shipping_Sec_Products").find("input:radio").each(function(){
					var name = $(this).attr("name");
					if($("input:radio[name="+name+"]:checked").length == 0){
					check = false;
					}
				});
			}
			if($('[data-attr-value="Shipping_option"]').length > 0){
				$('[data-attr-value="Shipping_option"]').find("input:radio").each(function(){
					var name = $(this).attr("name");
					console.log("name");
					console.log(name);
					if($("input:radio[name="+name+"]:checked").length == 0){
						check = false;
					}
				});
			}

			if(check){
				var check_value_pickup_person = true;
				$('.ins_pickup .pickup_person').each(function(){
					console.log($(this).find('input').val());
					if($(this).find('input').val()==''){
						check_value_pickup_person=false;
					}
				});

				if(check_value_pickup_person){
					var check_value_pickup_date = true;
					$('.ins_pickup .pickup_date').each(function(){
						if($(this).find('select').val()==''){
							check_value_pickup_date=false;
						}
					});
					if(check_value_pickup_date){
						/*$(".collapse").each(function(){
							$(this).removeClass("show");
						    });
						    $("#Billing").addClass("show");

						    $(".Shipping_Edit").css("display","block");
						    localStorage.setItem('current_location', "Billing");*/
							$(".collapse").removeClass('show');
							$(".place_order_btn").css("display","none");
							$("#Shipping").slideUp(1000);
							$("#Billing").slideDown(1000);
							var sku_value='';
							var person_name='';
							var person_Date='';
							var ordered_data = '' ;
							$('.Shipping_Sec_Products').each(function(){
								sku_value = $(this).find('[data-sku="sku_value"]').text();
								person_name = $(this).find('.ins_pickup .pickup_person input[type="text"]').val();
								person_Date = $(this).find('.ins_pickup .pickup_date select.selectoption_date').val();
								if(sku_value != ''){
									ordered_data = ordered_data + "SKU : " + sku_value +" | Pickup person : " + person_name + " | Pickup Date : " + person_Date + ";"
								}
								console.log('ordered_data');
								console.log(ordered_data);
								let current_location = localStorage.getItem('OrderedData');
								if(current_location  === 'undefined' || current_location  === null ){
									localStorage.setItem('OrderedData', ordered_data );
								}else{
									localStorage.setItem('OrderedData', ordered_data );
								}
							});

					}else{
						alert('Please Select Pickup Date');
					}
				}else{
					alert('Please Enter Pickup Person');
				}
			}else{
			    alert('Shipping Option Not selected');
			}
		}else{
			alert('Shipping Address Not selected');
		}
	    }else{
		var all_data_set = true;
		var Missing_fields = '';
		$("#Shipping").find("input").each(function(){
			var check_required = $(this).attr('required');
			var field_id = $(this).attr('id');
			var field_value = $(this).val();
			if(check_required == 'required' && field_value==''){
				all_data_set= false;
				Missing_fields += "\n"+field_id;
			}
		});

		$("#Shipping").find("select").each(function(){
			var field_id = $(this).attr('id');
			var field_value = $(this).val();
			if(field_value==''){
				all_data_set= false;
				Missing_fields += "\n"+field_id;
			}
		});
		
		$('[data-attr-value="Shipping_option"]').find("input:radio").each(function(){
		    var name = $(this).attr("name");
			console.log("name");
			console.log(name);
		    if($("input:radio[name='"+name+"']:checked").length == 0){
			all_data_set = false;
			Missing_fields += "\n"+ "Shipping Option Not selected";
		    }
		});

		if($("#Shipping").find(".ins_pickup .pickup_person input[type='text']").length > 0 && $("#Shipping").find(".ins_pickup .pickup_person input[type='text']").val()==""){
			all_data_set= false;
			Missing_fields += "\n"+ "Missing pickup person";
		}
		if($("#Shipping").find(".ins_pickup select.selectoption_date").length > 0 && $("#Shipping").find(".ins_pickup select.selectoption_date").val()==""){
			all_data_set= false;
			Missing_fields += "\n"+ "Missing pickup Date";
		}
		if(all_data_set == true){
			//alert("All required Data provided");
			/*$(".collapse").each(function(){
				$(this).removeClass("show");
			});
			$("#Billing").addClass("show");
			$(".Shipping_Edit").css("display","block");
			localStorage.setItem('current_location', "Billing");*/
			$(".collapse").removeClass('show');
			$(".place_order_btn").css("display","none");
			$("#Shipping").slideUp(1000);
			$("#Billing").slideDown(1000);
		}else{
			alert("Some required Data not Provided \n"+Missing_fields);
		}
	    }
    }

    render() {
		console.log("shipping");
		this.props.cart.lineItems.physicalItems.map((item) => {
			for(let i=0;item && i<item.options.length;i++){
				if(item.options[i].name == "Selected Availability"){
					if(item.options[i].value == "INS"){
						this.state.ins_products = true;
					}else if(item.options[i].value == "SHIP"){
						this.state.ship_products = true;
					}

					if(this.state.ins_products==true && this.state.ship_products==true){
						this._toggleMultiShipping("multi");
						this.state.hidden_data=true;
					}
				}
			}
		});
        return (
            <Section header={ 'Shipping' }
	    count={'2'}
	    body={
		<Fragment>
                    {
                        this._hasSavedAddresses() &&
                        this._hasMultiplePhysicalItems() &&
						!this.state.hidden_data &&
							<ShippingToggle
								onChange={ (value) => this._toggleMultiShipping(value) }
								multiShipping={ this.state.multiShipping } />
                    }
                    {
                        this.state.multiShipping ?
                        <MultiShipping
                            customer={ this.props.customer }
                            consignments={ this.props.consignments }
                            cart={ this.props.cart }
                            isUpdatingConsignment={ this.props.isUpdatingConsignment }
                            isCreatingConsignments={ this.props.isCreatingConsignments }
                            isSelectingShippingOption={ this.props.isSelectingShippingOption }
                            cart={ this.props.cart }
                            onConsignmentUpdate={ this.props.onConsignmentUpdate }
                        /> :
                        <SingleShipping
                            countries={ this.props.countries }
                            address={ this.props.address }
							addresses={ this.props.customer.addresses || [] }
                            onAddressChange={ this.props.onAddressChange }
                            selectedOptionId={ this.props.selectedOptionId }
                            options={ this.props.options }
                            isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress }
                            isSelectingShippingOption={ this.props.isSelectingShippingOption }
                            onSelect={ this.props.onShippingOptionChange }
							cart={ this.props.cart }
                        />
                    }
		    {
			<div className={ styles.shippingContinue }>
				<Button label='CONTINUE' onClick={ this.check_Shipping } />
			</div>
		    }
                </Fragment>
            } />
        );
    }

    _toggleMultiShipping(multiShipping) {
        this.setState({ multiShipping });
    }

    _hasSavedAddresses() {
        return this.props.customer.addresses &&
            this.props.customer.addresses.length > 1;
    }

    _hasMultiplePhysicalItems() {
        return this.props.cart.lineItems.physicalItems.length > 1;
    }
}
