import React, { Fragment } from 'react';
import Button from '../components/Button/button';
import EmailInput from '../components/EmailInput/email-input';
import Section from '../components/Section/section';
import styles from './customer.scss';

export default class Customer extends React.PureComponent {

    constructor(props) {
        super(props);

        this.state = {
            email: '',
        };
	  this.checkout_step_array=['Customer','Shipping','Billing','Payment'];

    }
 

    validate_Customer() {
	var guestEmail = $("#guestEmail").val();

	var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(!regex.test(guestEmail)) {
	     $("#guestEmail").css("border","1px solid red");
        }else{
	     /*$(".collapse").each(function(){
		$(this).removeClass("show");
	     });
	     $("#Shipping").addClass("show");
		*/
//    	     $('[data-target="#Customer"]').click();
//	     $('[data-target="#Shipping"]').click();
//	     $(".Customer_Edit").addClass("show_edit_btn");
        }
    }

    Customer_continue(){
	/*$(".collapse").each(function(){
		$(this).removeClass("show");
	});
	$("#Shipping").addClass("show");*/
    }

    componentDidMount() {
	/*if (window.performance) {
	  if (performance.navigation.type == 1) {
	    if(this.props.customer.isGuest == false){
		localStorage.setItem('current_location', "Shipping");
	    }else{
		localStorage.setItem('current_location', "Customer");
	    }
	  } else {
	    localStorage.setItem('current_location', "Customer");
	  }
	}
	var hide_index = 0;
	this.checkout_step_array.map((step_name,index) => {
		if(localStorage.getItem('current_location') == step_name){
			console.log(step_name);
			console.log(index);
			hide_index = index;
		}
	});

	this.checkout_step_array.map((step_name,index) => {
		if(index >= hide_index){
			$("."+step_name+"_Edit").css("display","none");
		}
	});*/

        let email = this.props.customer.isGuest ?
            this.props.customer.email :
            this.props.billingAddress.email;

        if (email && email !== this.state.email) {
            this.setState({ email });
        }
    }

    componentDidUpdate() {
        this.props.onChange(this.state);
    }

    render() {
		
        return (
            <Section
                header={ 'Customer' }
		count={'1'}
                body={
                    <Fragment>
			<div className="guest_Customer_container">
                        { this.props.customer.isGuest &&
                            <Fragment>
			    <p className={ styles.guest_customer_msg }>Checking out as a Guest? You'll be able to save your details to create an account with us later.</p>
                                <EmailInput
                                    id={ 'guestEmail' }
                                    label={ 'Email Address' }
                                    value={ this.state.email }
                                    onChange={ ({ target }) => this.setState({ email: target.value }) } />

                                <div className={ styles.actionContainer }>
                                    Already have an account? <a className={ styles.existing_customer_login } onClick={ this.props.onSignIn }>Sign in now</a>
                                </div>
				<div className={ styles.customerContinue } data-location="Customer" data-attr-button="Continue_button">
					<Button label='CONTINUE AS GUEST' className='customerContinueBtn' onClick={ this.validate_Customer } />
				</div>
                            </Fragment>
                        }

                        { !this.props.customer.isGuest &&
			    <div>
				    <div className={ styles.customerContainer }>
					<div className={ styles.customerLabel }>
					    You are signed in as { this.props.customer.email }
					</div>

					<Button
					    label={ this.props.isSigningOut ? `Signing out...` : 'Sign Out' }
					    onClick={ this.props.onClick } />
				    </div>
				    <div className={ styles.customerContinue } data-location="Customer" data-attr-button="Continue_button">
					<Button label='CONTINUE' className='customerContinueBtn' onClick={ this.Customer_continue } />
				    </div>
			    </div>
                        }
			</div>
                    </Fragment>
                } />
        );
    }
}
