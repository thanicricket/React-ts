import React, { Fragment } from 'react';
import Address from '../components/Address/address';
import RadioContainer from '../components/RadioContainer/radio-container';
import RadioInput from '../components/RadioInput/radio-input';
import Section from '../components/Section/section';
import Button from '../components/Button/button';
import styles from './billing.scss';

export default class Billing extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            address: {},
            sameAsShippingAddress: true,
        };
    }

    check_Billing() {

	if($("input:radio[name='sameAsShippingAddress']:checked").val() == 'true'){
		alert("same as shipping address");
		/*$(".collapse").each(function(){
		    $(this).removeClass("show");
		});
		$("#Payment").addClass("show");
		$(".Billing_Edit").css("display","block");
		$(".place_order_btn").css("display","block");
		localStorage.setItem('current_location', "Payment");*/
		$(".collapse").removeClass('show');
		$(".place_order_btn").css("display","block");
		$("#Billing").slideUp(1000);
		$("#Payment").slideDown(1000);
		$(".place_order_btn").slideDown(1000);
	}else{
		var all_data_set = true;
		var Missing_fields = '';
		$("#Billing").find("input").each(function(){
			var check_required = $(this).attr('required');
			var field_id = $(this).attr('id');
			var field_value = $(this).val();
			if(check_required == 'required' && field_value==''){
				all_data_set= false;
				Missing_fields += "\n"+field_id;
			}
		});

		$("#Billing").find("select").each(function(){
			var field_id = $(this).attr('id');
			var field_value = $(this).val();
			if(field_value==''){
				all_data_set= false;
				Missing_fields += "\n"+field_id;
			}
		});

		if(all_data_set == true){
			alert("All required Data provided");
			/*$(".collapse").each(function(){
			    $(this).removeClass("show");
			});
			$("#Payment").addClass("show");
			$(".Billing_Edit").css("display","block");
			$(".place_order_btn").css("display","block");
			localStorage.setItem('current_location', "Payment");*/
			$(".collapse").removeClass('show');
			$(".place_order_btn").css("display","block");
			$("#Billing").slideUp(1000);
			$("#Payment").slideDown(1000);
		}else{
			alert("Some required Data not Provided \n"+Missing_fields);
		}

	}       
    }

    componentDidMount() {
        this.setState({ address: this.props.address || {} });
        this.setState({ sameAsShippingAddress: this.props.sameAsShippingAddress });
		if(this.props.multishipping){
			this.setState({ sameAsShippingAddress: false });
		}
    }

    componentDidUpdate() {
        this.props.onChange(this.state.address);
        this.props.onSelect(this.state.sameAsShippingAddress);
    }

    render() {
		if(this.props.multishipping){
			this.setState({ sameAsShippingAddress: false });
		}

        return (
            <Section
                header={ 'Billing' }
		count={'3'}
                body={
                    <Fragment>
                        { !this.props.multishipping &&
                        <RadioContainer
                            label={ 'Billing Address' }
                            body={
                                <Fragment>
                                    <RadioInput
                                        name={ 'sameAsShippingAddress' }
                                        label={ 'Same as shipping address' }
                                        value={ 'true' }
                                        checked={ this.state.sameAsShippingAddress }
                                        onChange={ ({ target }) => this._onSelect(target.value) } />

                                    <RadioInput
                                        name={ 'sameAsShippingAddress' }
                                        label={ 'Use a different billing address' }
                                        value={ 'false' }
                                        checked={ !this.state.sameAsShippingAddress }
                                        onChange={ ({ target }) => this._onSelect(target.value) } />
                                </Fragment>
                            } />
                        }
                        { (
                            this.state.sameAsShippingAddress === false ||
                            this.props.multishipping
                        ) &&
                            <Address
                                name={ 'billing' }
                                address={ this.state.address }
                                countries={ this.props.countries }
                                onChange={ (fieldName, address) => this._onChange(fieldName, address) } />
                        }
			{
				<div className={ styles.billingContinue }>
					<Button label='CONTINUE' onClick={ this.check_Billing } />
				</div>
			}
                    </Fragment>
                } />
        );
    }

    _onChange(fieldName, value) {
        const address = Object.assign(
            {},
            this.state.address,
            { [fieldName]: value }
        );

        this.setState({ address: address });
    }

    _onSelect(value) {
        const actualValue = (value === 'true');

        this.setState({ sameAsShippingAddress: actualValue });
    }
}
