import React, { Fragment } from 'react';
import { formatMoney } from 'accounting';
import { createCheckoutService } from '@bigcommerce/checkout-sdk';
import Panel from '../components/Panel/panel';
import SubmitButton from '../components/SubmitButton/submit-button';
import Billing from '../Billing/billing';
import Cart from '../Cart/cart';
import Customer from '../Customer/customer';
import LoginPanel from '../LoginPanel/login-panel';
import Payment from '../Payment/payment';
import Shipping from '../Shipping/shipping';
import Shipping_2 from '../Shipping/shipping_2';
import Layout from './Layout/layout';
import LoadingState from './LoadingState/loading-state';
import styles from './checkout.scss';

export default class Checkout extends React.PureComponent {
    constructor(props) {
        super(props);

        this.service = createCheckoutService();

        this.state = {
            isPlacingOrder: false,
            showSignInPanel: false,
	    ins_value:false,
	    ship_value:false,
	    all_value:false,
	    checkout_cart:[],
        };
    }

	

    componentDidMount() {

        Promise.all([
            this.service.loadCheckout(),
            this.service.loadShippingCountries(),
            this.service.loadShippingOptions(),
            this.service.loadBillingCountries(),
            this.service.loadPaymentMethods(),
        ]).then(() => {
            this.unsubscribe = this.service.subscribe((state) => {
                this.setState(state);
            });
        });
    }

    componentWillUnmount() {
        this.unsubscribe();
    }
	
	customer_open(){
		console.log('customer click');
		$(".place_order_btn").css("display","none");
		$(".collapse").removeClass('show');
		$("#Shipping").css("display","none");
		$("#Customer").slideDown(1000);
	}

    render() {
	$('[data-attr-button="Continue_button"]').unbind().click(function(e){
		$(".collapse").removeClass('show');
		$(".place_order_btn").css("display","none");
		$("#Customer").slideUp(1000);
		$("#Shipping").slideDown(1000);
	});
	$(".Customer_Edit").unbind().click(function(e){
		e.preventDefault();
		/*$(".collapse").each(function(){
			$(this).removeClass("show");
		});*/
		$(".collapse").removeClass('show');
		$(".place_order_btn").css("display","none");
		if($("#Customer").css("display") == "none"){
			$(".collapse").css('display',"none");
			$("#Customer").slideDown(1000);
		}else{
			$("#Customer").slideUp(1000);
		}
	});
	$(".Shipping_Edit").unbind().click(function(e){
		e.preventDefault();
		/*$(".collapse").each(function(){
			$(this).removeClass("show");
		});*/
		$(".collapse").removeClass('show');
		$(".place_order_btn").css("display","none");
		if($("#Shipping").css("display") == "none"){
			$(".collapse").css('display',"none");
			$("#Shipping").slideDown(1000);
		}else{
			$("#Shipping").slideUp(1000);
		}
	});
	$(".Billing_Edit").unbind().click(function(e){
		e.preventDefault();
		/*$(".collapse").each(function(){
			$(this).removeClass("show");
		});*/
		$(".collapse").removeClass('show');
		$(".place_order_btn").css("display","none");
		if($("#Billing").css("display") == "none"){
			$(".collapse").css('display',"none");
			$("#Billing").slideDown(1000);
		}else{
			$("#Billing").slideUp(1000);
		}
	});
	$(".Payment_Edit").unbind().click(function(e){
		e.preventDefault();
		/*$(".collapse").each(function(){
			$(this).removeClass("show");
		});*/
		$(".collapse").removeClass('show');
		if($("#Payment").css("display") == "none"){
			$(".collapse").css('display',"none");
			$("#Payment").slideDown(1000);
			$(".place_order_btn").slideDown(1000);
		}else{
			$("#Payment").slideUp(1000);
			$(".place_order_btn").slideUp(1000);
		}
	});
	
        const { data, errors, statuses } = this.state;
	
		if(this.state.customer && (this.state.customer.isGuest || this.state.customer.email)){
			$(".collapse").removeClass('show');
			$(".place_order_btn").css("display","none");
			$("#Customer").slideUp(1000);
			$("#Shipping").slideDown(1000);
		}else{
			$(".collapse").removeClass('show');
			$(".place_order_btn").css("display","none");
			$("#Customer").slideDown(1000);
		}
	
        if (!data) {
            return (
                <Layout body={
                    <LoadingState />
                } />
            );
        }
	console.log("this.state");
	console.log(this.state);
	this.state.checkout_cart = data.getCheckout();
	for(let i=0;i<this.state.checkout_cart.cart.lineItems.physicalItems.length;i++){
		for(let j=0;j<this.state.checkout_cart.cart.lineItems.physicalItems[i].options.length;j++){
			if(this.state.checkout_cart.cart.lineItems.physicalItems[i].options[j].name == "Selected Availability"){
				if(this.state.checkout_cart.cart.lineItems.physicalItems[i].options[j].value == "INS"){
					this.state.ins_value = true;
				}
				if(this.state.checkout_cart.cart.lineItems.physicalItems[i].options[j].value == "SHIP"){
					this.state.ship_value = true;
				}
				if(this.state.ins_value == true && this.state.ship_value == true){
					this.state.all_value = true;
				}
			}
		}
	}
	
        return (
            <Layout body={
                <Fragment>
                    <div className={ styles.body }>
                        <Panel body={
                            <form onSubmit={ (event) => this._submitOrder(event, data.getCustomer().isGuest) }>
		      {this.state.showSignInPanel || (this.state.ship_value && data.getCustomer().isGuest) ? 
			<LoginPanel
			    errors={ errors.getSignInError() }
			    isSigningIn={ statuses.isSigningIn() }
			    onClick={ (customer) => this.service.signInCustomer(customer)
			        .then(() => this.service.loadShippingOptions())
			    }
			    onClose={ () => this.setState({ showSignInPanel: false }) } />
			:
			<Customer
                                    customer={ data.getCustomer() }
                                    billingAddress={ data.getBillingAddress() }
                                    isSigningOut={ statuses.isSigningOut() }
                                    onClick={ () => this.service.signOutCustomer()
                                         .then(() => this.service.loadShippingOptions())}
                                    onChange={ (customer) => this.setState({ customer }) }
                                    onSignIn={ () => this.setState({ showSignInPanel: true })
										}
				    checkout={ data.getCheckout() }
				    />
		      }
					{ this.state.showSignInPanel || (this.state.ship_value && data.getCustomer().isGuest) ?
                                <Shipping
                                    customer={ data.getCustomer() }
                                    consignments={ data.getConsignments() }
                                    cart={ data.getCart() }
                                    isUpdatingConsignment={ statuses.isUpdatingConsignment }
                                    isCreatingConsignments={ statuses.isCreatingConsignments }
                                    isUpdatingShippingAddress={ statuses.isUpdatingShippingAddress }
                                    address={ data.getShippingAddress() }
                                    countries={ data.getShippingCountries() }
                                    options={ data.getShippingOptions() }
                                    selectedOptionId={ data.getSelectedShippingOption() ? data.getSelectedShippingOption().id : '' }
                                    isSelectingShippingOption ={ statuses.isSelectingShippingOption }
                                    onShippingOptionChange={ (optionId) => this.service.selectShippingOption(optionId) }
                                    onConsignmentUpdate={ (consignment) => (
                                        consignment.id ?
                                            this.service.updateConsignment(consignment) :
                                            this.service.createConsignments([consignment])
                                        )
                                    }
                                    onAddressChange={ (shippingAddress) => {
                                        this.setState({ shippingAddress })
                                        this.service.updateShippingAddress(shippingAddress)
                                    }} />
								:
									<Shipping_2
                                    customer={ data.getCustomer() }
                                    consignments={ data.getConsignments() }
                                    cart={ data.getCart() }
                                    isUpdatingConsignment={ statuses.isUpdatingConsignment }
                                    isCreatingConsignments={ statuses.isCreatingConsignments }
                                    isUpdatingShippingAddress={ statuses.isUpdatingShippingAddress }
                                    address={ data.getShippingAddress() }
                                    countries={ data.getShippingCountries() }
                                    options={ data.getShippingOptions() }
                                    selectedOptionId={ data.getSelectedShippingOption() ? data.getSelectedShippingOption().id : '' }
                                    isSelectingShippingOption ={ statuses.isSelectingShippingOption }
                                    onShippingOptionChange={ (optionId) => this.service.selectShippingOption(optionId) }
                                    onConsignmentUpdate={ (consignment) => (
                                        consignment.id ?
                                            this.service.updateConsignment(consignment) :
                                            this.service.createConsignments([consignment])
                                        )
                                    }
                                    onAddressChange={ (shippingAddress) => {
                                        this.setState({ shippingAddress })
                                        this.service.updateShippingAddress(shippingAddress)
                                    }} />
					}
                                <Billing
                                    multishipping={ (data.getConsignments() || []).length > 1 }
                                    address={ data.getBillingAddress() }
                                    countries={ data.getBillingCountries() }
                                    sameAsShippingAddress={
                                        (this.state.billingAddressSameAsShippingAddress === undefined) ||
                                        this.state.billingAddressSameAsShippingAddress
                                    }
                                    onChange ={ (billingAddress) => this.setState({ billingAddress }) }
                                    onSelect ={ (billingAddressSameAsShippingAddress) => this.setState({ billingAddressSameAsShippingAddress })  } />

				<Payment
                                    errors={ errors.getSubmitOrderError() }
                                    methods={ data.getPaymentMethods() }
                                    onClick={ (name, gateway) => this.service.initializePayment({ methodId: name, gatewayId: gateway }) }
                                    onChange={ (payment) => this.setState({ payment }) } />

                                <div className={ styles.actionContainer + ' place_order_btn' }>
                                    <SubmitButton
                                        label={ this._isPlacingOrder() ?
                                            'Placing your order...' :
                                            `Pay ${ formatMoney((data.getCheckout()).grandTotal) }`
                                        }
                                        isLoading={ this._isPlacingOrder() } />
                                </div>
                            </form>
                        } />
                    </div>

                    <div className={ styles.side }>
                        <Cart
                            checkout={ data.getCheckout() }
                            cartLink={ (data.getConfig()).links.cartLink } />
                    </div>
                </Fragment>
            } />
        );
    }

    _isPlacingOrder() {
        const { statuses } = this.state;
	
        return this.state.isPlacingOrder && (
            statuses.isSigningIn() ||
            statuses.isUpdatingShippingAddress() ||
            statuses.isUpdatingBillingAddress() ||
            statuses.isSubmittingOrder()
        );
    }

    _submitOrder(event, isGuest) {
		console.log('this.state.billingAddress');
		console.log(this.state.billingAddress);
		console.log('this.state.billingAddressSameAsShippingAddress');
		console.log(this.state.billingAddressSameAsShippingAddress);
        let billingAddressPayload = this.state.billingAddressSameAsShippingAddress ?
            this.state.shippingAddress :
            this.state.billingAddress;

        let { payment } = this.state;

        this.setState({ isPlacingOrder: true });
        event.preventDefault();

        Promise.all([
            isGuest ? this.service.continueAsGuest(this.state.customer) : Promise.resolve(),
            this.service.updateBillingAddress(billingAddressPayload),
        ])
            .then(() => this.service.submitOrder({ payment }))
            .then(({ data }) => {
                   
               // window.location.href = data.getConfig().links.orderConfirmationLink;
	       window.location.href = "checkout/order-confirmation";
            })
            .catch(() => this.setState({ isPlacingOrder: false }));
    }
}
