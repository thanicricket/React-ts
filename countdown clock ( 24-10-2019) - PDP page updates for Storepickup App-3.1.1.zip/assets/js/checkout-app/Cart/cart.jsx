import React from 'react';
import { formatMoney } from 'accounting';
import ItemLine from "./ItemLine/item-line";
import styles from './cart.scss';

export default class Cart extends React.PureComponent {
    render() {
	let ship_count = 0;
	let ins_count = 0;
        return (
            <div className={ styles.container }>
                <div className={ styles.cartContainer }>
                    <div className={ styles.cartHeaderContainer }>
                        <div className={ styles.cartHeader }>
                            Order Summary
                        </div>

                        <a href={ this.props.cartLink } className={ styles.cartAction }>
                            Edit Cart
                        </a>
                    </div>

		{ ['physicalItems', 'digitalItems', 'giftCertificates'].map((keyType) => (
                        (this.props.checkout.cart.lineItems[keyType] || []).map((item) => (
			item.options.map((product_opt) => (
                            product_opt.name=="Selected Availability" && product_opt.value=="INS" && <ItemLine
                                key={ item.id }
                                label={ item.name }
                                amount={ formatMoney(item.extendedSalePrice) }
				qty= { item.quantity }
                                prod_options={ item.options }
				ship_Class = 'ins_products'
				count={ins_count++}
                                imageUrl={ item.imageUrl }/>
			))
                        ))
                    )) }

		{ ['physicalItems', 'digitalItems', 'giftCertificates'].map((keyType) => (
                        (this.props.checkout.cart.lineItems[keyType] || []).map((item) => (
			item.options.map((product_opt) => (
                            product_opt.name=="Selected Availability" && product_opt.value=="SHIP" && <ItemLine
                                key={ item.id }
                                label={ item.name }
                                amount={ formatMoney(item.extendedSalePrice) }
				qty= { item.quantity }
                                prod_options={ item.options }
				ship_Class = 'ship_products'
				count={ship_count++}
                                imageUrl={ item.imageUrl }/>
			))
                        ))
                    )) }
                   
                </div>

                <div className={ styles.orderSummaryContainer }>
                    <ItemLine
                        label={ 'Subtotal' }
                        amount={ formatMoney(this.props.checkout.subtotal) } />

                    <ItemLine
                        label={ 'Shipping' }
                        amount={ formatMoney(this.props.checkout.shippingCostTotal) } />

                    <ItemLine
                        label={ 'Tax' }
                        amount={ formatMoney(this.props.checkout.taxTotal) } />

                    <div className={ styles.grandTotalContainer }>
                        <div className={ styles.grandTotalLabel }>
                            Total
                        </div>

                        <div className={ styles.grandTotalAmount }>
                            { formatMoney(this.props.checkout.grandTotal) }
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}