import React from 'react';
import styles from './item-line.scss';

export default class ItemLine extends React.PureComponent {
        render() {
	        console.log(this.props.count);
        return (
	        <>
	        <>
	        { this.props.ship_Class == 'ship_products' && this.props.count == 0 &&
		<div className={ styles.cartShipSubHeader }>
			Shipping
		</div>
	        }

	        { this.props.ship_Class == 'ins_products' && this.props.count == 0 &&
		<div className={ styles.cartInsSubHeader }>
			Store Pickup
		</div>
	        }
	        </>

            <div className={ styles.container } >
                <div className={ styles.labelContainer }>
			{ this.props.item_sku_value &&
				<div data-sku="sku_value" className={ styles.hidden_sku }> { this.props.item_sku_value } </div>
			}

			{ this.props.imageUrl &&
				<img
				    src={ this.props.imageUrl }
				    className={ styles.image }/>
			}
			<div className='lineitem_name_container'>
				<div className={ styles.label }>
					<div> { this.props.label } </div>
				</div>
				{this.props.prod_options && this.props.prod_options.map(individual_option => 
					individual_option.name != "Availability Method" &&
					(<div key={individual_option.nameId} className='test'>
						<div>{individual_option.name} : {individual_option.value}</div>
					</div>)	
				)}
			</div>
		
                </div>

                <div className={ styles.amount }>
                    <b>{ this.props.amount }</b>
		    {this.props.label !='Subtotal' && this.props.label !='Shipping' && this.props.label !='Tax' &&
			<p>Qty { this.props.qty }</p>
		    }
                </div>
            </div>
		</>
        );
    }
}
