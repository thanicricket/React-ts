import React from 'react';
import styles from './section.scss';

export default class Section extends React.PureComponent {
    render() {
	/*let current_location = localStorage.getItem('current_location');
	if(current_location  === 'undefined' || current_location  === null ){
		localStorage.setItem('current_location', "Customer");
		current_location = "Customer";
	}*/

        return (
            <div className={ styles.section }>
                <div className={ styles.header }>
		    <span className={ styles.checkout_step_number }>{this.props.count}</span>
                    { this.props.header }
		    <span className={this.props.header + "_Edit Checkout_Edit_Btn"} data-toggle="collapse" data-target={'#' + this.props.header}>Edit</span>
                </div>
	
		{/*<div className={ styles.body + ' collapse'+ (this.props.header == current_location?" show":"") } id={this.props.header}>
                    { this.props.body }
                </div>*/}
				<div className={ styles.body + ' collapse' } id={this.props.header}>
                    { this.props.body }
                </div>
            </div>
        );
    }
}
