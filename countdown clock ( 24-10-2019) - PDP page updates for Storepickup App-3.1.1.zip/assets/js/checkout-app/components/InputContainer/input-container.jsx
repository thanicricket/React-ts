import React from 'react';
import classNames from 'classnames';
import styles from './input-container.scss';

export default class InputContainer extends React.PureComponent {
    render() {
        return (
            <div data-class-name={ this.props.data_class } data_container_name = {this.props.data_attr_value} className={ classNames(styles.container, styles[this.props.width ? this.props.width + 'Width' : 'fullWidth']) }>
                <label
                    htmlFor={ this.props.id }
                    className={ styles.label } data_label_name = {this.props.data_attr_value}>
                    { this.props.label } { this.props.helpText && <span className={ styles.helpText }>({ this.props.helpText })</span> }
                </label>

                { this.props.body }
            </div>
        );
    }
}
