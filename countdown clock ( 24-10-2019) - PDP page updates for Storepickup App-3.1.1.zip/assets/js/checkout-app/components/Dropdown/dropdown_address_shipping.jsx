import React from 'react';
import InputContainer from '../InputContainer/input-container'
import styles from './dropdown.scss';

export default class DropdownAddress extends React.PureComponent {



	/*componentWillReceiveProps (newProps) {
		console.log("code");
		if(this.props.class_name == 'address_ins' && this.props.options[0].code && newProps.options[0].code !=this.props.options[0].code){
			this.props.onChange({target:newProps.options[0]});
		}
	}*/

	componentDidMount(){
		console.log('address_ins');
		if(this.props.class_name == 'address_ins' && this.props.options[0]){
			this.props.onChange({target:this.props.options[0]});
		}
	}
    render() {
		console.log('dropdown');
        return (
		<div className={ styles.div_container } >
		{ this.props.class_name == 'address_ship' ?
		    <InputContainer
			id={ this.props.id }
			inline={ this.props.inline }
			label={ this.props.label }
			width={ this.props.width }
			body={
			    <select
				id={ this.props.id }
				value={ this.props.value || '' }
				onChange={ this.props.onChange }
				className={ styles.select }>
				<option value="" />
				{ this.props.options.map((option) => (
				    <option
					key={ option.code }
					value={ option.code }>
					{ option.name }
				    </option>
				))}
			    </select>
			} />
			:
			<div className={ styles.hidden_conatainer }>
				<InputContainer
				id={ this.props.id }
				inline={ this.props.inline }
				label={ this.props.label }
				width={ this.props.width }
				body={
				    <select
					id={ this.props.id }
					value={ this.props.value || '' }
					onChange={ this.props.onChange }
					className={ styles.select } 
					data-attr-select-box="selectdata"
					>
					<option value="" />
					{ this.props.options.map((option) => (
					    <option
						key={ option.code }
						value={ option.code }>
						{ option.name }
					    </option>
					))}
				    </select>
				} />
			</div>
		}
		 </div>
        );
    }
}
