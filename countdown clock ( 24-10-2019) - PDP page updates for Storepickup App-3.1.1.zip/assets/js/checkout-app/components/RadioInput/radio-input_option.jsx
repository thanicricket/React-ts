import React from 'react';
import styles from './radio-input_option.scss';

export default class RadioInputOption extends React.PureComponent {
	componentDidMount(){
	//console.log(this.props.shipping_method_value!="single",this.props.class_name_value == 'option_ins',this.props.label == 'Pickup In Store - $0.00');
		if(this.props.shipping_method_value!="single" && this.props.class_name_value == 'option_ins' && this.props.label == 'Pickup In Store - $0.00'){
			//console.log("In");
			this.getDateOptions();
		}else if(this.props.ins_products == true && this.props.label == 'Pickup In Store - $0.00'){
			//console.log("In");
			$('[data-options-value="Pickup In Store - $0.00"]').attr('selected','selected');
			this.getDateOptions();
		}
	}
	getDateOptions(event) {
		event && event.preventDefault();
		fetch('http://192.168.2.29/BigCommerce/Sandbox/GreenTop/App/Store_Pickup_App/get-pickup-dates')
		      .then(data => data.json())
		      .then((data) => { $('select.selectoption_date').html(data); $('select.selectoption_date').attr("data-changed","true");}); 
	    }
    render() {
		$(document).on('change', 'select.selectoption_date',function() {
			var data = $(this).attr("data-changed");
			var value = $(this).val();
			if(data=="true" && $('select.selectoption_date').length > 1){
			console.log('condition satisfy');
				var answer = window.confirm("Do you want to update the same date for all the Store Pickup Products?")
				if (answer) {
				    $('select.selectoption_date option[value="'+ value +'"]').attr('selected','selected');
				}
				else {
				    console.log('no need');
				}
				$('select.selectoption_date').attr("data-changed","false");
			}
		});
        return (
		<div className="radio_button">
		{ this.props.shipping_method_value!="single" ? 
			<div>
				{ this.props.class_name_value == 'option_ins' ?
					<div>
						{ this.props.label == 'Pickup In Store - $0.00' &&
						
						<div className={ styles.div_container }  data-value-option={ this.props.class_name_value } data-options-value = {this.props.label} >
							<label data-option-value = {this.props.data_value_option} className={ this.props.isLoading ? `${styles.container} ${styles.loadingState}` : styles.container }>
								
								<input
									type="radio"
									name={ this.props.name }
									value={ this.props.value }
									checked={ this.props.checked }
									disabled={ this.props.isLoading }
									onChange={ this.props.onChange }
									className={ styles.input } />
								  
								<label className="method_option_label">{ this.props.label == 'Pickup In Store - $0.00' && this.props.label }</label>
							</label>
							<div className="ins_pickup">
								<div className="pickup_person">
									<label>Pickup Person</label>
									<input type="text"/>
								</div>
								<div className="pickup_date">
									<label>Pickup Date</label>
									<select className="selectoption_date" 
									>
									</select>
								</div>
							</div>
						</div>
						}
					</div>
					:
					<div>
						{ this.props.label != 'Pickup In Store - $0.00' && 
						<div className={ styles.div_container } data-value-option={ this.props.class_name_value } data-options-value = {this.props.label} >
							<label data-option-value = {this.props.data_value_option} className={ this.props.isLoading ? `${styles.container} ${styles.loadingState}` : styles.container }>
							<input
								type="radio"
								name={ this.props.name }
								value={ this.props.value }
								checked={ this.props.checked }
								disabled={ this.props.isLoading }
								onChange={ this.props.onChange }
								className={ styles.input } />
						   
							<label className="method_option_label">{ this.props.label != 'Pickup In Store - $0.00' && this.props.label }</label>
							
							</label>
						   
						</div>
						}
					</div>
				  }
				</div>
					:
				<div>
					{ this.props.ins_products == true ? 
						<div>
							{ this.props.label == 'Pickup In Store - $0.00' &&
							<div className={ styles.div_container }  data-value-option={ this.props.class_name_value } data-options-value = {this.props.label} >
								<label data-option-value = {this.props.data_value_option} className={ this.props.isLoading ? `${styles.container} ${styles.loadingState}` : styles.container }>
									
									<input
										type="radio"
										name={ this.props.name }
										value={ this.props.value }
										checked={ this.props.checked }
										disabled={ this.props.isLoading }
										onChange={ this.props.onChange }
										className={ styles.input } />
									  
									<label className="method_option_label">{ this.props.label == 'Pickup In Store - $0.00' && this.props.label }</label>
								</label>
								<div className="ins_pickup">
									<div className="pickup_person">
										<label>Pickup Person</label>
										<input type="text" />
									</div>
									<div className="pickup_date">
										<label>Pickup Date</label>
										<select className="selectoption_date" >
										</select>
									</div>
								</div>
							</div>
							}
						</div>
					:
						<div className={ styles.div_container } data-value-option={ this.props.class_name_value } data-options-value = {this.props.label} >
							{ this.props.label != 'Pickup In Store - $0.00' &&
								<label data-option-value = {this.props.data_value_option} className={ this.props.isLoading ? `${styles.container} ${styles.loadingState}` : styles.container }>
								
								<input
									type="radio"
									name={ this.props.name }
									value={ this.props.value }
									checked={ this.props.checked }
									disabled={ this.props.isLoading }
									onChange={ this.props.onChange }
									className={ styles.input } />
									
								<label className="method_option_label">{ this.props.label != 'Pickup In Store - $0.00' && this.props.label }</label>
								
								</label>
							}
						</div>

					  }
				</div>
			}
		 </div>
        );
    }
}
